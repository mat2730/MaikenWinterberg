/*
 * Martin Alexander Thomsen den 18 August 2024
 */
import com.maikenwinterberg.inbox2email.linkserver.LinkServer;
import com.maikenwinterberg.inbox2email.mailsender.MailSender;
import java.io.File;
import javax.swing.filechooser.FileSystemView;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class startInboxServer {

    public static void main(String arg[]) throws Exception {
        FileSystemView view = FileSystemView.getFileSystemView();
        String configFolder = view.getHomeDirectory().getAbsolutePath();
        File KEYSTORE_FILE = new File(configFolder + "/config/inbox2Email/KeyStore.jks");
        if (!KEYSTORE_FILE.exists()) {
            KEYSTORE_FILE = new File("config/inbox2Email/KeyStore.jks");
        }
        if (KEYSTORE_FILE.exists()) {
            if (System.getProperty("javax.net.ssl.keyStore") == null) {
                System.setProperty("javax.net.ssl.keyStore", KEYSTORE_FILE.getAbsolutePath());
            }
            if (System.getProperty("javax.net.ssl.keyStorePassword") == null) {
                System.setProperty("javax.net.ssl.keyStorePassword", "123456");
            }
        }        
        LinkServer.main(arg);
        MailSender.main(arg);
    }
}
