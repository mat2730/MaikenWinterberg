/*
 * Martin Alexander Thomsen den 16 August 2024
 */
package com.maikenwinterberg.inbox2email.htmlwriter;

import com.maikenwinterberg.inbox2email.mailsender.MailSender;
import java.io.File;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class HtmlWriterImpl implements IHtmlWriter {

    @Override
    public void addPreHtml(int index, StringBuilder builder) {
        String preHtml = MailSender.getProperties(index + ".prehtml");
        builder.append(preHtml);
    }

    @Override
    public void appendLink(int index, StringBuilder builder, String link, File file) {
        String preUrl = MailSender.getProperties(index + ".preurl");
        String withPasswordAsString = MailSender.getProperties(index + ".withPassword");
        boolean withPassword = Boolean.parseBoolean(withPasswordAsString);
        builder.append("\n<br/><a href='").append(preUrl).append("/").append(link);
        if (!withPassword) {
            builder.append("?pass=.");
        }
        builder.append("'>").append(file.getParentFile().getName()).append("/").append(file.getName()).append("</a>");
    }

    @Override
    public void addPostHtml(int index, StringBuilder builder) {
        String postHtml = MailSender.getProperties(index + ".posthtml");
        builder.append("\n" + postHtml);
    }
}
