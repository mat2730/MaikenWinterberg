/*
 * Martin Alexander Thomsen den 16 August 2024
 */
package com.maikenwinterberg.inbox2email.htmlwriter;

import java.io.File;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IHtmlWriter {

    public void addPreHtml(int index, StringBuilder builder);

    public void appendLink(int index, StringBuilder builder, String link, File file);

    public void addPostHtml(int index, StringBuilder builder);
}
