/*
 * Martin Alexander Thomsen den 18 August 2024
 */
package com.maikenwinterberg.inbox2email.log;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class Link2FileObject {

    private final String link;
    private final String receiverDomainName;
    private final String fileName;
    private final boolean domainCheck;

    public Link2FileObject(String link, String receiverDomainName, String fileName, boolean domainCheck) {
        this.link = link;
        this.receiverDomainName = receiverDomainName;
        this.fileName = fileName;
        this.domainCheck = domainCheck;
    }

    public String getLink() {
        return link;
    }

    public String getReceiverDomainName() {
        return receiverDomainName;
    }

    public String getFileName() {
        return fileName;
    }

    public boolean isDomainCheck() {
        return domainCheck;
    }

    @Override
    public String toString() {
        return "Link2FileObject{" + "link=" + link + ", receiverDomainName=" + receiverDomainName + ", fileName=" + fileName + ", domainCheck=" + domainCheck + '}';
    }

}
