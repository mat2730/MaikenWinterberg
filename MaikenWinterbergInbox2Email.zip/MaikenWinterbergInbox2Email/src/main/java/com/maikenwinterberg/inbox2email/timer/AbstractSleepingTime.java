/*
 * Martin Alexander Thomsen den 23 August 2024
 */
package com.maikenwinterberg.inbox2email.timer;

import static com.maikenwinterberg.inbox2email.mailsender.MailSender.getProperties;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public abstract class AbstractSleepingTime implements IGetSleepTime {

    @Override
    public long getSleepTime(String params) {
        if (params != null) {
            long time = Long.MAX_VALUE;
            StringTokenizer tok = new StringTokenizer(params, ";");
            while (tok.hasMoreTokens()) {
                String param = tok.nextToken();
                time = Math.min(time, getASleepTime(param));
            }
            return time;
        } else {
            return getASleepTime(params);
        }
    }

    protected abstract long getASleepTime(String param);
}
