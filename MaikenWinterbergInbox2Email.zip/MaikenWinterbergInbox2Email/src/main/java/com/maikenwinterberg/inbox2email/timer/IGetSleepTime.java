/*
 * Martin Alexander Thomsen den 22 August 2024
 */
package com.maikenwinterberg.inbox2email.timer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IGetSleepTime {
    public long getSleepTime();
    public long getSleepTime(String param);
}
