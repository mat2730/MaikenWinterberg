/*
 * Martin Alexander Thomsen den 18 August 2024
 */
package com.maikenwinterberg.inbox2email.log;

import com.maikenwinterberg.fileregistry.IFileRegistry;
import com.maikenwinterberg.fileregistry.PersistenceFactory;
import com.maikenwinterberg.inbox2email.mailsender.MailSender;
import java.io.File;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class DBLink2FileLog implements ILink2FileLog {

    private IFileRegistry reg;

    public DBLink2FileLog() throws Exception {
        this.reg = PersistenceFactory.getFileRegistryDB(null,
                MailSender.getProperties("driver"),
                MailSender.getProperties("url"),
                MailSender.getProperties("username"),
                MailSender.getProperties("password")
        );
    }

    @Override
    public String log(String receiverDomainName, boolean domainCheck, String fileName) throws Exception {
        return reg.registerFile(receiverDomainName, domainCheck, new File(fileName));
    }

    @Override
    public String getFile(String ipAdress, String link) throws Exception {
        File f = reg.getFile(ipAdress, link);
        if (f == null) return null;
        return f.getAbsolutePath();
    }
}
