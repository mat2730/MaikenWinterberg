/*
 * Martin Alexander Thomsen den 16 August 2024
 */
package com.maikenwinterberg.inbox2email.log;

import com.maikenwinterberg.inbox2email.mailsender.MailSender;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class Link2FileLogFactory {

    private static final Map<Integer, ILink2FileLog> LINK2FILE_LOG = new HashMap();

    public static ILink2FileLog getInstance(int index) {
        ILink2FileLog w = LINK2FILE_LOG.get(index);
        if (w != null) {
            return w;
        }
        try {
            String classname = MailSender.getProperties(index + ".link2filelogger");
            w = (ILink2FileLog) Class.forName(classname).newInstance();
        } catch (Exception ex) {
            //ignore
        }
        if (w == null) {
            try {
                String classname = MailSender.getProperties("link2filelogger");
                w = (ILink2FileLog) Class.forName(classname).newInstance();
            } catch (Exception ex) {
                //ignore
            }
        }
        if (w == null) {
            try {
                w = new DBLink2FileLog();;
            } catch (Exception ex) {
                w = new Link2FileLog();
            }
        }
        LINK2FILE_LOG.put(index, w);
        return w;
    }
}