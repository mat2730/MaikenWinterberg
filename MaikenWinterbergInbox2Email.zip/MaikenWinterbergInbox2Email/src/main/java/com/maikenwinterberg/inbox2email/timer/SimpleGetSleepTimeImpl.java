/*
 * Martin Alexander Thomsen den 22 August 2024
 */
package com.maikenwinterberg.inbox2email.timer;

import static com.maikenwinterberg.inbox2email.mailsender.MailSender.getProperties;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class SimpleGetSleepTimeImpl extends AbstractSleepingTime {

    @Override
    public long getSleepTime() {
        return getSleepTime(getProperties("defaultsleeptime"));
    }

    @Override
    protected long getASleepTime(String param) {
        long sleepTime = Long.MAX_VALUE;
        try {
            sleepTime = Long.parseLong(param);
        } catch (Exception ex) {
            //ignore
        }
        return sleepTime;
    }
}
