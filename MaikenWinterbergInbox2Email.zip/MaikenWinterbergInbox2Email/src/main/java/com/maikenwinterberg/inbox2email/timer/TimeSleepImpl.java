/*
 * Martin Alexander Thomsen den 22 August 2024
 */
package com.maikenwinterberg.inbox2email.timer;

import static com.maikenwinterberg.inbox2email.mailsender.MailSender.getProperties;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class TimeSleepImpl extends AbstractSleepingTime {

    @Override
    public long getSleepTime() {
        return getSleepTime(getProperties("timePattern"));
    }

    @Override
    protected long getASleepTime(String timePatterns) {
        try {
            //yyyyMMdd HH:MM;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd HH:mm");
            StringTokenizer tok = new StringTokenizer(timePatterns, ";");
            List<Date> list = new LinkedList();
            while (tok.hasMoreTokens()) {
                try {
                    String timePattern = tok.nextToken();
                    Date d = sdf.parse(timePattern);
                    list.add(d);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            list.sort(null);
            long currentTime = System.currentTimeMillis();
            for (Date d : list) {
                if (d.getTime() > currentTime) {
                    return d.getTime() - currentTime;
                }
            }
        } catch (Exception ex) {
        }
        return Long.MAX_VALUE;
    }

    public static void main(String arg[]) {
        TimeSleepImpl t = new TimeSleepImpl();
        long st = t.getSleepTime("20240822 16:28;20240822 18:28;20240822 19:28;20240822 18:38;20240822 28:28;20240822 18:28;20240823 18:28");
        System.out.println("st: " + st);
    }
}
