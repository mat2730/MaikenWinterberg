/*
 * Martin Alexander Thomsen den 07 August 2024
 */
package com.maikenwinterberg.inbox2email.mailsender;

import com.maikenwinterberg.inbox2email.htmlwriter.IHtmlWriter;
import com.maikenwinterberg.inbox2email.htmlwriter.HtmlWriterFactory;
import com.maikenwinterberg.inbox2email.log.Link2FileLogFactory;
import com.maikenwinterberg.inbox2email.timer.GetSteepTimeFactory;
import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import javax.swing.filechooser.FileSystemView;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class MailSender extends Thread {

    private final static Properties PROPERTIES = new Properties();
    private static Long TIME;
    private static File INBOX2EMAIL_FILE;

    private static final boolean INFO = true;

    /*
    part1
        travaser træ
        lav html med links
        send html to email
    part2
        link server
     */
    public static String getProperties(String name) {
        try {
            if (INBOX2EMAIL_FILE == null) {
                FileSystemView view = FileSystemView.getFileSystemView();
                String configFolder = view.getHomeDirectory().getAbsolutePath();
                INBOX2EMAIL_FILE = new File(configFolder + "/config/inbox2Email/inbox2Email.properties");
                if (!INBOX2EMAIL_FILE.exists()) {
                    INBOX2EMAIL_FILE = new File("config/inbox2Email/inbox2Email.properties");
                }
            }
            BasicFileAttributes attr = Files.readAttributes(INBOX2EMAIL_FILE.toPath(), BasicFileAttributes.class);
            FileTime fileDate = attr.lastModifiedTime();
            if (TIME == null || TIME != fileDate.toMillis()) {
                PROPERTIES.clear();
                PROPERTIES.load(new FileInputStream(INBOX2EMAIL_FILE));
                TIME = fileDate.toMillis();
            }
            return PROPERTIES.getProperty(name);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public void run() {
        try {
            while (true) {
                try {
                    Thread.sleep(GetSteepTimeFactory.newInstance().getSleepTime());
                } catch (Exception exe) {
                    exe.printStackTrace();
                }
                int index = 1;
                while (true) {
                    try {
                        String inbox = getProperties(index + ".inbox");
                        if (inbox == null || inbox.isEmpty()) {
                            break;
                        }
                        String receiverDomainName = getProperties(index + ".receiverdomainname");
                        String domainCheckAsString = getProperties(index + ".domaincheck");
                        boolean domainCheck = Boolean.parseBoolean(domainCheckAsString);
                        File[] files = new File(inbox).listFiles();
                        if (files != null && files.length > 0) {
                            IHtmlWriter htmlWriter = HtmlWriterFactory.newIntance(index);
                            StringBuilder htmlBuilder = new StringBuilder();
                            htmlWriter.addPreHtml(index, htmlBuilder);
                            //traverse(receiverDomainName, domainCheck, index, htmlWriter, htmlBuilder, files);
                            List<File> list = new LinkedList();
                            traverseInbox(list, files);
                            list.sort(null);
                            for (File file : list) {
                                try {
                                    String link = Link2FileLogFactory.getInstance(index).log(receiverDomainName, domainCheck, file.getAbsolutePath());
                                    htmlWriter.appendLink(index, htmlBuilder, link, file);
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                }
                            }
                            htmlWriter.addPostHtml(index, htmlBuilder);
                            if (INFO) {
                                System.out.println("sending");
                                System.out.println(htmlBuilder.toString());
                            }
                            EmailUtil.sendEmails(index, htmlBuilder.toString());
                        }

                    } catch (Exception ex) {
                        ex.printStackTrace();
                    } finally {
                        index++;
                    }
                }
            }
        } catch (Exception exe) {
            exe.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new MailSender().start();
    }

    private static void traverseInbox(List list, File[] files) {
        if (files == null) {
            return;
        }
        for (File file : files) {
            if (file.isDirectory()) {
                traverseInbox(list, file.listFiles());
            } else {
                if (!file.getName().endsWith(".tmp")) {
                    list.add(file);
                }
            }
        }
    }
}
