/*
 * Martin Alexander Thomsen den 17 August 2024
 */
package com.maikenwinterberg.inbox2email.linkserver;

import java.io.File;
import java.io.FileInputStream;
import java.util.Date;
import java.util.Map;

import org.veryquick.embweb.EmbeddedServer;
import org.veryquick.embweb.Response;
import org.veryquick.embweb.handlers.FileBasedRequestHandler;
import org.veryquick.embweb.handlers.MimeTypeParser;
import com.maikenwinterberg.inbox2email.log.Link2FileLogFactory;

/**
 * '
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class LinkServer {

    public static void main(String[] args) throws Exception {

        try {
            EmbeddedServer.createInstance(8090, new FileBasedRequestHandler(
                    new File("www")) {
                @Override
                public Response handleRequest(Type type, String url,
                        Map<String, String> parameters) {
                    Response response = new Response();
                    String pass = parameters.get("GET_pass");
                    String ip = parameters.get("REMOTE_IP");
                    //System.out.println("pass " + pass + ", ip: " + ip + ", parameters:" + parameters);
                    if (url.startsWith("/inbox2email") && pass == null) {
                        response.addContent("<html>");
                        response.addContent("<head>");
                        response.addContent("<script type=\"text/javascript\">");
                        response.addContent("function get_action(form) {");
                        response.addContent("form.action = window.location.href/getpost;");
                        response.addContent("}");
                        response.addContent("</script>");
                        response.addContent("</head>");
                        response.addContent("<body>");
                        response.addContent("<center>");
                        response.addContent("<h2>Please type in a password</h2>");
                        response.addContent("<form onsubmit=\"get_action(this);\">");
                        response.addContent("Password: <input type=\"password\" name=\"pass\" /><input type=\"submit\" value=\"Send\" />");
                        response.addContent("</form>");
                        response.addContent("</center>");
                        response.addContent("</body></html>");
                    } else if (url.startsWith("/inbox2email/") && pass != null) {
                        boolean ok = false;
                        try {
                            //TODO get link
                            int logIndex = 1;
                            String link = null;
                            int index1 = -1;
                            int index2 = -1;
                            //init logIndex
                            try {
                                //http://localhost:8090/inbox2email/1/link1?pass=dfdf
                                //http://localhost:8090/inbox2email/link1?pass=dfdf
                                index1 = url.indexOf("/inbox2email/");
                                if (index1 != -1) {
                                    index1 += 13;
                                    String rest = url.substring(index1);
                                    index2 = rest.indexOf("/");
                                    logIndex = Integer.parseInt(rest.substring(0, index2));
                                }
                            } catch (Exception ex) {
                                logIndex = 1;
                            }
                            //init link
                            try {
                                index1 = url.lastIndexOf("/");
                                if (index1 != -1) {
                                    link = url.substring(index1 + 1);
                                }
                            } catch (Exception ex) {
                                link = null;
                            }
                            if (link != null) {
                                File f = new File(Link2FileLogFactory.getInstance(logIndex).getFile(ip, link));
                                if (f.exists()) {
                                    String ext = null;
                                    try {
                                        String name = f.getName();
                                        int dotIndex = name.indexOf(".");
                                        ext = name.substring(dotIndex + 1);
                                    } catch (Exception ex) {
                                    }
                                    if (ext == null) {
                                        ext = "txt";
                                    }
                                    response.setContentType(MimeTypeParser.getInstance().getType(ext.toLowerCase()));
                                    try {
                                        FileInputStream fis = new FileInputStream(f);//"/home/martin/Billeder/Skærmbillede fra 2024-08-14 11-23-35.png"));
                                        response.setBinaryContent(fis.readAllBytes());
                                        ok = true;
                                    } catch (Exception ex) {
                                        ex.printStackTrace();
                                    }
                                }
                            }
                        } catch (Exception ex) {
                            //ignore
                            ex.printStackTrace();
                        }
                        if (!ok) {
                            url = "linkNotFound.htm";
                            return super.handleRequest(type, url, parameters);
                        }

                    } else if (url.equalsIgnoreCase("welcome.html")) {
                        response.addContent("<html><body><h1>Welcome to the link server!</h1></body></html>");
                    } else if (url.equalsIgnoreCase("datetime")) {
                        Date dt = new Date();
                        response.addContent("<html><body>Current Date Time: "
                                + dt.toString() + "</body></html>");
                    } else if (url.equalsIgnoreCase("ping")) {
                        //TODO an ip of remote caller is missing response.addContent(type.);
                    } else {
                        if (url.trim().isEmpty() || url.equals("/")) {
                            url = "index.htm";
                        }
                        return super.handleRequest(type, url, parameters);
                    }
                    response.setOk();
                    return response;
                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
