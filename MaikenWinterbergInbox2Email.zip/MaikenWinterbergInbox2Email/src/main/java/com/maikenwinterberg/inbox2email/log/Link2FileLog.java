/*
 * Martin Alexander Thomsen den 2 August 2024
 */
package com.maikenwinterberg.inbox2email.log;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.UUID;
import javax.swing.filechooser.FileSystemView;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class Link2FileLog implements ILink2FileLog {

    private final static Map<String, Link2FileObject> LINK_CACHE = new HashMap();
    private final static Map<String, Link2FileObject> FILE_CACHE = new HashMap();

    private static BufferedWriter BUF;

    static {
        Properties TEMP_CACHE = new Properties();
        //TODO load cache
        try {
            FileSystemView view = FileSystemView.getFileSystemView();
            String configFolder = view.getHomeDirectory().getAbsolutePath();
            File link2File = new File(configFolder + "/config/inbox2Email/inboxlinks.properties");
            if (!link2File.exists()) {
                link2File = new File("/config/inbox2Email/inboxlinks.properties");
            }

            TEMP_CACHE.load(new FileInputStream(link2File));
            for (Iterator i = TEMP_CACHE.keySet().iterator(); i.hasNext();) {
                String key = (String) i.next();
                String values = (String) TEMP_CACHE.get(key);
                StringTokenizer tok = new StringTokenizer(values, "|");
                String receiverDomainName = tok.nextToken();
                String domainCheck = tok.nextToken();
                String fileName = tok.nextToken();
                Link2FileObject obj = new Link2FileObject(key, receiverDomainName, fileName, Boolean.parseBoolean(domainCheck));
                FILE_CACHE.put(fileName.trim().toLowerCase(), obj);
                LINK_CACHE.put(key, obj);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static BufferedWriter getWriter() {
        try {
            if (BUF != null) {
                return BUF;
            }
            FileSystemView view = FileSystemView.getFileSystemView();
            String configFolder = view.getHomeDirectory().getAbsolutePath();
            File link2File = new File(configFolder + "/config/inbox2Email/inboxlinks.properties");
            if (!link2File.exists()) {
                link2File = new File("config/inbox2Email/inboxlinks.properties");
            }
            FileWriter fw = new FileWriter(link2File, true);
            BUF = new BufferedWriter(fw);
            return BUF;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    protected void finalize() throws Throwable {
        BUF.close();
    }

    @Override
    public synchronized String getFile(String ipAdress, String link) {
        return LINK_CACHE.get(link).getFileName();
    }

    @Override
    public synchronized String log(String receiverDomainName, boolean domainCheck, String fileName) {
        Link2FileObject fileObj = (Link2FileObject) FILE_CACHE.get(fileName.trim().toLowerCase());
        if (fileObj != null) {
            return fileObj.getLink();
        }
        String link = UUID.randomUUID().toString();
        try {
            BufferedWriter bw = getWriter();
            if (bw != null) {
                bw.write(link + "=" + receiverDomainName + "|" + domainCheck + "|" + fileName + "\n");
                bw.flush();
            } else {
                System.out.println("buffered writer to log not created");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        Link2FileObject obj = new Link2FileObject(link, receiverDomainName, fileName, domainCheck);
        LINK_CACHE.put(link, obj);
        FILE_CACHE.put(fileName.trim().toLowerCase(), obj);
        return link;
    }
}
