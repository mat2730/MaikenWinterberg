/*
 * Martin Alexander Thomsen den 16 August 2024
 */
package com.maikenwinterberg.inbox2email.htmlwriter;

import com.maikenwinterberg.inbox2email.mailsender.MailSender;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class HtmlWriterFactory {

    private static final Map<Integer, IHtmlWriter> HTML_WRITER = new HashMap();

    public static IHtmlWriter newIntance(int index) {
        IHtmlWriter w = HTML_WRITER.get(index);
        if (w != null) {
            return w;
        }
        try {
            String classname = MailSender.getProperties(index + ".htmlwriterimpl");
            w = (IHtmlWriter) Class.forName(classname).newInstance();
        } catch (Exception ex) {
            //ignore
        }
        if (w == null) {
            try {
                String classname = MailSender.getProperties("htmlwriterimpl");
                w = (IHtmlWriter) Class.forName(classname).newInstance();
            } catch (Exception ex) {
                //ignore
            }
        }
        if (w == null) {
            w = new HtmlWriterImpl();;
        }
        HTML_WRITER.put(index, w);
        return w;
    }
}