/*
 * Martin Alexander Thomsen den 16 August 2024
 */
package com.maikenwinterberg.inbox2html.htmlwriter;

import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentNode;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class HtmlWriterImpl implements IHtmlWriter {

    private final StringBuilder builder = new StringBuilder();

    @Override
    public void addPreHtml(int index, HtmlWriterParam param) {
        String preHtml = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "prehtml", index);
        builder.append(preHtml);
    }

    @Override
    public void addLink(int index, String link, IDocumentNode documentNode, HtmlWriterParam param) {
        String linkurl = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "linkurl", index);
        String withPasswordAsString = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "withPassword", index);
        boolean withPassword = Boolean.parseBoolean(withPasswordAsString);
        builder.append("\n<br/><a href='").append(linkurl).append("/").append(link);
        if (!withPassword) {
            builder.append("?pass=.");
        }
        builder.append("'>").append(documentNode.getGroupName()).append("/").append(documentNode.getName()).append("</a>");
    }

    @Override
    public void addPostHtml(int index, HtmlWriterParam param) {
        String postHtml = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "posthtml", index);
        builder.append("\n").append(postHtml);
    }

    @Override
    public String toString() {
        return builder.toString();
    }

    @Override
    public void addAttribute(String name, String value) {
    }
}