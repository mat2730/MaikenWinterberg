/*
 * Martin Alexander Thomsen den 30 August 2024
 */
package com.maikenwinterberg.inbox2html.linkserver;

import com.maikenwinterberg.config.Config;
import java.net.InetAddress;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class IPCheck {

    public static boolean approveIP(String ip, int index) {
        if (ip.equals("127.0.0.1")) {
            //localhost is always accecpted
            return true;
        }
        List<String> l = new LinkedList();
        String domainNames = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "receiverdomainname", index);
        StringTokenizer tok = new StringTokenizer(domainNames, ";");
        while (tok.hasMoreTokens()) {
            try {
                String domainName = tok.nextToken();
                InetAddress inetAddress = null;
                String hostAddress = null;
                try {
                    inetAddress = InetAddress.getByName(domainName);
                } catch (Exception ex) {
                }
                if (inetAddress != null) {
                    hostAddress = inetAddress.getHostAddress();
                }
                if (hostAddress == null || !hostAddress.equals(ip)) {
                    //security issue
                } else {
                    return true;
                }
            } catch (Exception ex) {
                //ignore
            }
        }
        Properties p = Config.getProperties(Config.Group.inbox2HTMLConfig, Config.Property.validDomains);
        for (Object domain : p.keySet()) {
            InetAddress inetAddress = null;
            String hostAddress = null;
            try {
                inetAddress = InetAddress.getByName(domain.toString());
            } catch (Exception ex) {
            }
            if (inetAddress != null) {
                hostAddress = inetAddress.getHostAddress();
            }
            if (hostAddress == null || !hostAddress.equals(ip)) {
                //security issue
            } else {
                return true;
            }
        }
        return false;
    }
}