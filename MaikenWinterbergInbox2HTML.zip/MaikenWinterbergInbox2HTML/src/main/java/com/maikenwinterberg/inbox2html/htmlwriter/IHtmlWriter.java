/*
 * Martin Alexander Thomsen den 16 August 2024
 */
package com.maikenwinterberg.inbox2html.htmlwriter;

import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentNode;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IHtmlWriter {

    public void addPreHtml(int index, HtmlWriterParam params);

    public void addAttribute(String name, String value);

    public void addLink(int index, String link, IDocumentNode file, HtmlWriterParam params);

    public void addPostHtml(int index, HtmlWriterParam params);
}
