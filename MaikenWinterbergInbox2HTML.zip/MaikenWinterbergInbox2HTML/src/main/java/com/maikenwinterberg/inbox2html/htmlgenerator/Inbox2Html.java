/*
 * Martin Alexander Thomsen den 24 August 2024
 */
package com.maikenwinterberg.inbox2html.htmlgenerator;

import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.filedomainjumper.documentiterator.FileDocumentIterator;
import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentIterator;
import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentTouch;
import java.io.File;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class Inbox2Html extends Thread {

    @Override
    public void run() {
        while (true) {
            loop();
            try {
                String sleepTimeAsString = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "defaultHTMLGenerationSleeptime");
                long sleepTime = 60000;
                try {
                    sleepTime = Long.parseLong(sleepTimeAsString);
                } catch (Exception ex) {
                }
                Thread.sleep(sleepTime);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private static void loop() {
        int index = 1;
        while (true) {
            try {
                String di = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "IDocumentIterator", index);
                if (di == null) {
                    break;
                }
                IDocumentIterator i = (IDocumentIterator) Class.forName(di).newInstance();
                if (i == null) {
                    break;
                }
                if (i instanceof FileDocumentIterator) {
                    String sd = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "startingdir", index);
                    ((FileDocumentIterator) i).setStartingDir(new File(sd));
                }
                String tc = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "ITouch", index);
                IDocumentTouch touch = (IDocumentTouch) Class.forName(tc).newInstance();
                i.setTouch(touch);
                i.iterateDocuments();
                touch.commit(1);
                System.out.println("html generated for index " + index);
                index++;
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void main(String arg[]) throws Exception {
        //TODO use configuration
        new Inbox2Html().start();
    }
}
