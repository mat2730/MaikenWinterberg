/*
 * Martin Alexander Thomsen den 25 August 2024
 */
package com.maikenwinterberg.inbox2html.htmlwriter;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class HtmlWriterParam {

    private final Map attributes = new HashMap();

    public void add(String param, String value) {
        attributes.put(param, value);
    }

    public Object getValue(String param) {
        return attributes.get(param);
    }
}
