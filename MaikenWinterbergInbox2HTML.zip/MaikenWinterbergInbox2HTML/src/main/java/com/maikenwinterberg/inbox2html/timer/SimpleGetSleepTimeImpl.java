/*
 * Martin Alexander Thomsen den 22 August 2024
 */
package com.maikenwinterberg.inbox2html.timer;

import com.maikenwinterberg.config.Config;


/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class SimpleGetSleepTimeImpl extends AbstractSleepingTime {

    @Override
    public long getSleepTime() {
        return getSleepTime(Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "defaultMailsleeptime"));
    }

    @Override
    protected long getASleepTime(String param) {
        long sleepTime = Long.MAX_VALUE;
        try {
            sleepTime = Long.parseLong(param);
        } catch (Exception ex) {
            //ignore
        }
        return sleepTime;
    }
}
