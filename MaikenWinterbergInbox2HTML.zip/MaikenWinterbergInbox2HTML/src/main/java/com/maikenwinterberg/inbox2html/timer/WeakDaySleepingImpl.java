/*
 * Martin Alexander Thomsen den 23 August 2024
 */
package com.maikenwinterberg.inbox2html.timer;

import com.maikenwinterberg.config.Config;
import java.util.List;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class WeakDaySleepingImpl extends AbstractSleepingTime {

    @Override
    public long getSleepTime() {
        return getSleepTime(Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "weektimePattern"));
    }

    @Override
    protected long getASleepTime(String param) {
        //TODO implement this
        //MO,TU,WE,TH,FR,SA,SU HH:mm
        try {
            //inti params
            StringTokenizer tok = new StringTokenizer(param, " ");
            String weekDays = tok.nextToken();
            String time = tok.nextToken();
            List<Integer> weekListParam = new LinkedList();
            StringTokenizer tok2 = new StringTokenizer(weekDays, ",");
            while (tok2.hasMoreTokens()) {
                String weekday = tok2.nextToken();
                if (weekday.equals("MO")) {
                    weekListParam.add(0);
                } else if (weekday.equals("TU")) {
                    weekListParam.add(1);
                } else if (weekday.equals("WE")) {
                    weekListParam.add(2);
                } else if (weekday.equals("TH")) {
                    weekListParam.add(3);
                } else if (weekday.equals("FR")) {
                    weekListParam.add(4);
                } else if (weekday.equals("SA")) {
                    weekListParam.add(5);
                } else if (weekday.equals("SU")) {
                    weekListParam.add(6);
                }
            }
            weekListParam.sort(null);
            StringTokenizer tok3 = new StringTokenizer(time, ":");
            int hourParam = Integer.parseInt(tok3.nextToken());
            int minuteParam = Integer.parseInt(tok3.nextToken());

            Calendar c = Calendar.getInstance();
            c.setTime(new Date());
            int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
            if (dayOfWeek == Calendar.MONDAY) {
                dayOfWeek = 0;
            } else if (dayOfWeek == Calendar.TUESDAY) {
                dayOfWeek = 1;
            } else if (dayOfWeek == Calendar.WEDNESDAY) {
                dayOfWeek = 2;
            } else if (dayOfWeek == Calendar.THURSDAY) {
                dayOfWeek = 3;
            } else if (dayOfWeek == Calendar.FRIDAY) {
                dayOfWeek = 4;
            } else if (dayOfWeek == Calendar.SATURDAY) {
                dayOfWeek = 5;
            } else if (dayOfWeek == Calendar.SUNDAY) {
                dayOfWeek = 6;
            }
            int hour = c.get(Calendar.HOUR_OF_DAY);
            int minute = c.get(Calendar.MINUTE);
            int timeDirerence = ((hourParam - hour) * 1000 * 60 * 60) + ((minuteParam - minute) * 1000 * 60);
            for (int dayOfWeekParam : weekListParam) {
                if (dayOfWeekParam >= dayOfWeek) {
                    //calculate sleep time
                    int dayDirerence = (dayOfWeekParam - dayOfWeek) * (1000 * 60 * 60 * 24);
                    int dif = dayDirerence + timeDirerence;
                    if (dif > 0) {
                        return dif;
                    }
                }
            }
            for (int dayOfWeekParam : weekListParam) {
                if (dayOfWeekParam < dayOfWeek) {
                    int dayDirerence = (dayOfWeek - dayOfWeekParam - 1) * (1000 * 60 * 60 * 24);
                    int dif = dayDirerence + timeDirerence;
                    if (dif > 0) {
                        return dif;
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return Long.MAX_VALUE;
    }

    public static void main(String arg[]) {
        WeakDaySleepingImpl t = new WeakDaySleepingImpl();
        System.out.println(t.getSleepTime("MO,TU,SU 08:30"));
        System.out.println(t.getSleepTime("MO,TU 08:30"));
    }
}
