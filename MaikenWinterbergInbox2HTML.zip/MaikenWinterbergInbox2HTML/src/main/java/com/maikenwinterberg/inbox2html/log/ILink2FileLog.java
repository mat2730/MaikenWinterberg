/*
 * Martin Alexander Thomsen den 7 August 2024
 */
package com.maikenwinterberg.inbox2html.log;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface ILink2FileLog {

    public String log(String receiverDomainName, boolean domainCheck, String fileName) throws Exception;

    public String getFile(String ipAdress, String link) throws Exception;
}
