/*
 * Martin Alexander Thomsen den 18 August 2024
 */
package com.maikenwinterberg.inbox2html.log;

import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.fileregistry.IFileRegistry;
import com.maikenwinterberg.fileregistry.PersistenceFactory;
import com.maikenwinterberg.inbox2html.mailsender.MailSender;
import java.io.File;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class DBLink2FileLog implements ILink2FileLog {

    private IFileRegistry reg;

    public DBLink2FileLog() throws Exception {
        this.reg = PersistenceFactory.getFileRegistryDB(null,
                Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "driver"),
                Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "url"),
                Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "username"),
                Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "password"));
    }

    @Override
    public String log(String receiverDomainName, boolean domainCheck, String fileName) throws Exception {
        return reg.registerFile(receiverDomainName, domainCheck, new File(fileName));
    }

    @Override
    public String getFile(String ipAdress, String link) throws Exception {
        File f = reg.getFile(ipAdress, link);
        if (f == null) {
            return null;
        }
        return f.getAbsolutePath();
    }
}
