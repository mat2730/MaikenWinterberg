/*
 * Martin Alexander Thomsen den 27 August 2024
 */
package com.maikenwinterberg.inbox2html.htmlgenerator;

import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentNode;
import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentTouch;
import com.maikenwinterberg.filedomainjumper.documentiterator.TouchNode;
import com.maikenwinterberg.inbox2html.htmlwriter.HtmlWriterFactory;
import com.maikenwinterberg.inbox2html.htmlwriter.IHtmlWriter;
import com.maikenwinterberg.inbox2html.log.Link2FileLogFactory;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class SinglePageHTMLTouch implements IDocumentTouch, IGenerateHTML {

    private final List<IDocumentNode> documentNodes = new LinkedList();

    @Override
    public void touch(TouchNode touchNode) throws Exception {
        documentNodes.add((IDocumentNode) touchNode.getValue(IDocumentNode.class.getName()));
    }

    @Override
    public void commit(int index) throws Exception {
        generateHTML(index);
    }

    @Override
    public String generateHTML(int index) {
        String receiverDomainName = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, index + ".receiverdomainname");
        //String domainCheck = Config.getValue(Config.Group1.inbox2HTMLConfig, Config.Group2.inbox2HTML, index + ".domaincheck");
        documentNodes.sort(null);
        SimpleDateFormat f = new SimpleDateFormat("yyyy/MM");
        IHtmlWriter writer = HtmlWriterFactory.newIntance(index);
        String singlepagetemplate = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "singlepagetemplate", index);
        writer.addAttribute("template", singlepagetemplate);
        String resourceUrl = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "resourceurl", index);
        writer.addAttribute("background", resourceUrl + "/background.jpg");
        writer.addPreHtml(index, null);
        for (IDocumentNode documentNode : documentNodes) {
            try {
                String link = Link2FileLogFactory.getInstance(index).log(receiverDomainName, false, documentNode.getId());
                writer.addLink(index, link, documentNode, null);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        writer.addPostHtml(index, null);
        return writer.toString();
    }
}
