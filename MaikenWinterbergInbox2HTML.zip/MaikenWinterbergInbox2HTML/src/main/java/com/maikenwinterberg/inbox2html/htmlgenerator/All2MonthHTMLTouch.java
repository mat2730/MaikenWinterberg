/*
 * Martin Alexander Thomsen den 25 August 2024
 */
package com.maikenwinterberg.inbox2html.htmlgenerator;

import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.filedomainjumper.documentiterator.FileDocumentNode;
import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentNode;
import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentTouch;
import com.maikenwinterberg.filedomainjumper.documentiterator.TouchNode;
import com.maikenwinterberg.inbox2html.htmlwriter.HtmlWriterFactory;
import com.maikenwinterberg.inbox2html.htmlwriter.IHtmlWriter;
import com.maikenwinterberg.inbox2html.htmlwriter.TemplateHTMLWriterImpl;
import com.maikenwinterberg.inbox2html.log.Link2FileLogFactory;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class All2MonthHTMLTouch implements IDocumentTouch, IGenerateHTML {

    private final List<IDocumentNode> documentNodes = new LinkedList();

    @Override
    public void touch(TouchNode touchNode) throws Exception {
        documentNodes.add((IDocumentNode) touchNode.getValue(IDocumentNode.class.getName()));
    }

    @Override
    public void commit(int index) throws Exception {
        generateHTML(index);
    }

    @Override
    public String generateHTML(int index) {
        String wwwFolder = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, index + ".htmlbox");
        //init htmlwriters
        String receiverDomainName = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, index + ".receiverdomainname");
        //String domainCheck = Config.getValue(Config.Group1.inbox2HTMLConfig, Config.Group2.inbox2HTML, index + ".domaincheck");
        Map<String, IHtmlWriter> htmlWriters = new TreeMap();
        generateHTML(htmlWriters, receiverDomainName, index, wwwFolder, null);
        //index.html
        StringBuilder tablerows = new StringBuilder();
        for (String path : htmlWriters.keySet()) {
            //<a href="2017/12/index.html" target="_blank">DEC</a>
            tablerows.append("<tr><td class=\"table__content\" data-heading=\"Date\"><a href='").append(path).append("/index.html'>").append(path).append("</a></td> <tr>");
        }
        String resourceUrl = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "resourceurl", index);
        IHtmlWriter iw = new TemplateHTMLWriterImpl();
        iw.addAttribute("background", resourceUrl + "/background.jpg");
        iw.addAttribute("tablerows", tablerows.toString());
        String all2monthindextemplate = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "all2monthindextemplate", index);
        iw.addAttribute("template", all2monthindextemplate);
        iw.addPostHtml(index, null);
        try {
            FileWriter fw = new FileWriter(new File(wwwFolder + "/index.html"));
            fw.write(iw.toString());
            fw.flush();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return iw.toString();
    }

    private void generateHTML(Map<String, IHtmlWriter> htmlWriters, String receiverDomainName, int index, String wwwFolder, String sortcolumn) {
        SimpleDateFormat f = new SimpleDateFormat("yyyy/MM");
        for (IDocumentNode documentNode : documentNodes) {
            try {
                // doucmentNode
                Date d = documentNode.getDate();
                String path = f.format(d);
                IHtmlWriter writer = htmlWriters.get(path);
                if (writer == null) {
                    writer = HtmlWriterFactory.newIntance(index);
                    String resourceUrl = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "resourceurl", index);
                    String all2monthtemplate = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "all2monthtemplate", index);
                    writer.addAttribute("background", resourceUrl + "/background.jpg");
                    writer.addAttribute("template", all2monthtemplate);
                    writer.addAttribute("sortcolumn", sortcolumn);
                    htmlWriters.put(path, writer);
                    writer.addPreHtml(index, null);
                }
                String link = Link2FileLogFactory.getInstance(index).log(receiverDomainName, false, documentNode.getId());
                writer.addLink(index, link, documentNode, null);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        for (IHtmlWriter w : htmlWriters.values()) {
            w.addPostHtml(index, null);
        }
        //inbox htmls
        for (String path : htmlWriters.keySet()) {
            try {
                IHtmlWriter w = htmlWriters.get(path);
                new File(wwwFolder + "/" + path).mkdirs();
                if (sortcolumn != null) {
                    FileWriter fw = new FileWriter(new File(wwwFolder + "/" + path + "/index_" + sortcolumn + ".html"));
                    fw.write(w.toString());
                    fw.flush();
                } else {
                    FileWriter fw = new FileWriter(new File(wwwFolder + "/" + path + "/index.html"));
                    fw.write(w.toString());
                    fw.flush();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
