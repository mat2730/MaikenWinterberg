/*
 * Martin Alexander Thomsen den 07 August 2024
 */
package com.maikenwinterberg.inbox2html.mailsender;

import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.filedomainjumper.documentiterator.FileDocumentIterator;
import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentIterator;
import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentTouch;
import com.maikenwinterberg.inbox2html.htmlgenerator.IGenerateHTML;
import com.maikenwinterberg.inbox2html.timer.GetSteepTimeFactory;
import java.io.File;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class MailSender extends Thread {

    private static final boolean INFO = true;

    /*
    part1
        travaser træ
        lav html med links
        send html to email
    part2
        link server
     */
    public void run() {
        try {
            String sendEmailAsString = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "sendEmail");
            boolean sendEmail = Boolean.parseBoolean(sendEmailAsString);
            if (!sendEmail) {
                return;
            }
            while (true) {
                try {
                    Thread.sleep(GetSteepTimeFactory.newInstance().getSleepTime());
                } catch (Exception exe) {
                    exe.printStackTrace();
                }
                int index = 1;
                while (true) {
                    try {
                        String inbox = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, index + ".inbox");
                        if (inbox == null || inbox.isEmpty()) {
                            break;
                        }
                        String html = traverseInbox(index);
                        if (html != null) {
                            System.out.println(html);
                            EmailUtil.sendEmails(index, html);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    } finally {
                        index++;
                    }
                }
            }
        } catch (Exception exe) {
            exe.printStackTrace();
        }
    }

    private String traverseInbox(int index) throws Exception {
        //TODO implement this
        String di = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "mailDocumentIterator", index);
        if (di == null) {
            return null;
        }
        IDocumentIterator i = (IDocumentIterator) Class.forName(di).newInstance();
        if (i == null) {
            return null;
        }
        if (i instanceof FileDocumentIterator fileDocumentIterator) {
            String sd = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "inbox", index);
            fileDocumentIterator.setStartingDir(new File(sd));
        }
        String tc = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "mailITouch", index);
        IDocumentTouch touch = (IDocumentTouch) Class.forName(tc).newInstance();
        i.setTouch(touch);
        i.iterateDocuments();
        if (touch instanceof IGenerateHTML iGenerateHTML) {
            String html = iGenerateHTML.generateHTML(index);
            return html;
        } else {
            if (touch != null) {
                touch.commit(index);
            }
        }
        return null;
    }

    public static void main(String[] args) {
        new MailSender().start();
    }
}
