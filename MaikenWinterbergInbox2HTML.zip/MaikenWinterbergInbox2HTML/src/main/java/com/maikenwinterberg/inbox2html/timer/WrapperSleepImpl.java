/*
 * Martin Alexander Thomsen den 23 August 2024
 */
package com.maikenwinterberg.inbox2html.timer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class WrapperSleepImpl implements IGetSleepTime {

    @Override
    public long getSleepTime() {
        //yyyyMMdd HH:MM;
        return getSleepTime(null);
    }

    @Override
    public long getSleepTime(String param) {
        //first by clock
        try {
            long time1 = new TimeSleepImpl().getSleepTime();
            long time2 = new WeakDaySleepingImpl().getSleepTime();
            long time = Math.min(time1, time2);
            if (time != Long.MAX_VALUE) {
                return time;
            }
        } catch (Exception ex) {
        }
        //default by wait by x milliseconds
        return new SimpleGetSleepTimeImpl().getSleepTime();
    }
}