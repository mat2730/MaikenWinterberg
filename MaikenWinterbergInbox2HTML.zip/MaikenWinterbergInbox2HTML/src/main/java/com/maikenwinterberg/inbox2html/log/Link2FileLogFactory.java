/*
 * Martin Alexander Thomsen den 16 August 2024
 */
package com.maikenwinterberg.inbox2html.log;

import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.inbox2html.mailsender.MailSender;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class Link2FileLogFactory {

    private static final Map<Integer, ILink2FileLog> LINK2FILE_LOG = new HashMap();

    public static ILink2FileLog getInstance(int index) {
        ILink2FileLog w = LINK2FILE_LOG.get(index);
        if (w != null) {
            return w;
        }
        try {
            String classname = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "link2filelogger", index);
            w = (ILink2FileLog) Class.forName(classname).newInstance();
        } catch (Exception ex) {
            //ignore
        }
        if (w == null) {
            try {
                w = new DBLink2FileLog();
            } catch (Exception ex) {
                return null;
            }
        }
        LINK2FILE_LOG.put(index, w);
        return w;
    }
}
