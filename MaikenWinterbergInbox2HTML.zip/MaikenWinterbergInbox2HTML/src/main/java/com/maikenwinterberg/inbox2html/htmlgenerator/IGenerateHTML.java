/*
 * Martin Alexander Thomsen den 24 August 2024
 */
package com.maikenwinterberg.inbox2html.htmlgenerator;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IGenerateHTML {
    public String generateHTML(int index);
}
