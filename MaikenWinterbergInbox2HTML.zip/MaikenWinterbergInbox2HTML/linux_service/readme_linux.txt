This program requires that Java 1.21+ is installed on you computer.

Installation on linux in 3 stepts:
1) Install Java onto your system if not allready installed
    sudo apt-get install openjdk-21-jdk
2) replace localhost with your domainname in inbox2HTML.properties
2) Execute the installInboxServer.sh: 4 files are being created to the folder
3) Open up for port 8090 on your firewall
