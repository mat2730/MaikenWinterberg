/*
 * Martin Alexander Thomsen den 12 August 2024
 */
package com.maikenwinterberg.util;

import java.util.Arrays;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.comin
 * @see maikenwinterberg.com
 *
 * @see
 * https://dzone.com/articles/a-memory-efficient-and-fast-byte-array-builder-imp
 */
public class ByteArrayBuilder {

    private byte[] values = new byte[0];

    public ByteArrayBuilder append(byte[] _bytes) {
        int offset = values.length;
        values = Arrays.copyOf(values, offset + _bytes.length);
        System.arraycopy(_bytes, 0, values, offset, _bytes.length);
        return this;
    }

    public byte[] toBytes() {
        return values;
    }
}
