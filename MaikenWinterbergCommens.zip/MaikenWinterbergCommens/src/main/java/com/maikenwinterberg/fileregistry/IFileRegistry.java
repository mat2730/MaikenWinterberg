/*
 * Martin Alexander Thomsen den 18 Juli 2024
 */
package com.maikenwinterberg.fileregistry;

import java.io.File;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IFileRegistry {

    public String isRegistrated(String receiverDomainName, File file) throws Exception;

    public String registerFile(String receiverDomainName, boolean doDomainCheck, File file) throws Exception;

    public File getFile(String ipAdress, String link) throws Exception;
}
