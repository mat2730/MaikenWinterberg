/*
 * Martin Alexander Thomsen den 7. Januar 2025
 */
package com.maikenwinterberg.fileregistry;

import com.maikenwinterberg.domainname.DomainHandler;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.InetAddress;
import java.util.StringTokenizer;
import java.util.UUID;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileFileRegistry implements IFileRegistry {

    public static String LINK_DIRECTORY = "links";

    private String ENCODING = "ISO-8859-1";

    @Override
    public String isRegistrated(String ownerDomainName, File file) throws Exception {
        File linkFile = new File(file.getAbsoluteFile().getParent() + "/." + file.getName() + "_link.tmp");
        return isRegistrated(linkFile, ownerDomainName, file);
    }

    private String isRegistrated(File linkFile, String ownerDomainName, File file) throws Exception {
        if (linkFile.exists()) {
            try (FileInputStream fis = new FileInputStream(linkFile)) {
                byte[] d = new byte[fis.available()];
                fis.read(d);
                String content = new String(d, ENCODING);
                StringTokenizer tok = new StringTokenizer(content, "|");
                return tok.nextToken();
            } catch (Exception ex) {
            }
        }
        return null;
    }

    private String getLinkDirectory(String name) {
        StringBuilder buf = new StringBuilder();
        buf.append(LINK_DIRECTORY);
        int index = 0;
        while (true) {
            String part;
            try {
                part = name.substring(index, index + 3);
                buf.append("/").append(part);
            } catch (Exception ex) {
                part = name.substring(index);
                if (!part.trim().isEmpty()) {
                    buf.append("/").append(part);
                }
                break;
            }
            index += 3;
        }
        return buf.toString();
    }

    @Override
    public String registerFile(String ownerDomainName, boolean ownerOnly, File file) throws Exception {
        if (file.getName().startsWith(".") && file.getName().endsWith("_link.tmp")) {
            return null; //its a link file. Dont register
        }
        File linkFile = new File(file.getAbsoluteFile().getParent() + "/." + file.getName() + "_link.tmp");
        //TODO check file parents if they are a domainName, if so change, the owner
        String uuid = isRegistrated(linkFile, ownerDomainName, file);
        if (uuid == null) {
            uuid = UUID.randomUUID().toString();
        }
        try (FileOutputStream fos = new FileOutputStream(linkFile)) {
            fos.write((uuid + "|" + ownerDomainName + "|" + ownerOnly).getBytes(ENCODING));
            fos.flush();
        }
        File fileInfoFile = new File(getLinkDirectory(uuid) + "/fileinfo.txt");
        fileInfoFile.getParentFile().mkdirs();
        try (FileOutputStream fos = new FileOutputStream(fileInfoFile)) {
            fos.write((file.getAbsolutePath()).getBytes(ENCODING));
            fos.flush();
        }
        return uuid;
    }

    @Override
    public File getFile(String ipAdress, String uuid) throws Exception {
        File fileInfoFile = new File(getLinkDirectory(uuid) + "/fileinfo.txt");
        try (FileInputStream fis = new FileInputStream(fileInfoFile)) {
            byte[] d = new byte[fis.available()];
            fis.read(d);
            String fileName = new String(d, ENCODING);
            File file = new File(fileName);
            if (ipAdress != null && !ipAdress.equals("127.0.0.1") && !ipAdress.equals("localhost")) {
                //validate owner
                File linkFile = new File(file.getAbsoluteFile().getParent() + "/." + file.getName() + "_link.tmp");
                try (FileInputStream fis2 = new FileInputStream(linkFile)) {
                    byte[] d2 = new byte[fis2.available()];
                    fis.read(d2);
                    String content = new String(d2, ENCODING);
                    StringTokenizer tok = new StringTokenizer(content, "|");
                    String uuid2 = tok.nextToken();
                    String ownerDomainName = tok.nextToken();
                    String ownerOnly = tok.nextToken();
                    if (!uuid.equals(uuid2)) {
                        //old link -> no access 
                        return null;
                    }
                    if (ownerOnly != null && ownerOnly.equals("true")) {
                        try {
                            //requires static ip with a domainname pointing to the address
                            String hostAddress = DomainHandler.getHostAddress(ownerDomainName);
                            if (hostAddress == null) {
                                //the owner do not exist anymore or there is no internet connection
                                throw new IllegalAccessException("The owner of the file do not exist anymore or there is no internet connection " + ownerDomainName);
                            }
                        } catch (Exception ex) {
                            throw new IllegalAccessException("ip is not approved " + ipAdress);
                        }
                    }
                } catch (Exception ex) {
                }
            }
            return file;
        } catch (Exception ex) {
        }
        return null;
    }
}