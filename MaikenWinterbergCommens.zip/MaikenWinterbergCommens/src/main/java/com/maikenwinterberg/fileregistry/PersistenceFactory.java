/*
 * Martin Alexander Thomsen den 18 Juli 2024
 */
package com.maikenwinterberg.fileregistry;

/**
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class PersistenceFactory {
    //only one DB per domainjumper is needed
    private static IFileRegistry REGISTRY;

    public static IFileRegistry getFileRegistryDB(String className, String driver, String url, String username, String password) throws Exception {
        if (REGISTRY != null) {
            return REGISTRY;
        } else {
            IFileRegistry registryDB = null;
            try {
                if (className != null) {
                    registryDB = (IFileRegistry) Class.forName(className).newInstance();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            if (registryDB == null) {
                registryDB = new JDBCFileRegistry();
            }
            registryDB.setDriver(driver);
            registryDB.setUrl(url);
            registryDB.setusername(username);
            registryDB.setpassword(password);
            registryDB.initConnection();
            REGISTRY = registryDB;
            return registryDB;
        }
    }
}
