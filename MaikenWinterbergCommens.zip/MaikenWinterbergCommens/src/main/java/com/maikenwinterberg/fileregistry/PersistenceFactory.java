/*
 * Martin Alexander Thomsen den 18 Juli 2024
 */
package com.maikenwinterberg.fileregistry;

/**
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class PersistenceFactory {

    //only one DB per domainjumper is needed
    private static IFileRegistry REGISTRY;

    public static IFileRegistry getFileRegistryDB(String linkdatabase) throws Exception {
        if (REGISTRY != null) {
            return REGISTRY;
        } else {
            IFileRegistry r = getFileRegistryDB(null, null, null, null, null);
            if (r instanceof FileFileRegistry) {
                if (linkdatabase != null) {
                    FileFileRegistry.LINK_DIRECTORY = linkdatabase;
                }
            }
            return r;
        }
    }

    public static IFileRegistry getFileRegistryDB(String className, String driver, String url, String username, String password) throws Exception {
        if (REGISTRY != null) {
            return REGISTRY;
        } else {
            IFileRegistry registryDB = null;
            try {
                if (className != null) {
                    registryDB = (IFileRegistry) Class.forName(className).newInstance();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            if (registryDB == null) {
                registryDB = new FileFileRegistry();
            }
            if (registryDB instanceof JDBCFileRegistry) {
                ((JDBCFileRegistry) registryDB).setDriver(driver);
                ((JDBCFileRegistry) registryDB).setUrl(url);
                ((JDBCFileRegistry) registryDB).setusername(username);
                ((JDBCFileRegistry) registryDB).setpassword(password);
                ((JDBCFileRegistry) registryDB).initConnection();
            }
            REGISTRY = registryDB;
            return registryDB;
        }
    }
}
