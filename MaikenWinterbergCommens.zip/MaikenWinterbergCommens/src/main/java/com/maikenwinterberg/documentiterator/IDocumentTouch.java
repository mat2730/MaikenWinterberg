/*
 * Martin Alexander Thomsen den 8 August 2024
 */
package com.maikenwinterberg.documentiterator;

import com.maikenwinterberg.documentiterator.*;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IDocumentTouch {

    public void touch(TouchNode touchNode) throws Exception;

    public void commit(int configIndex) throws Exception;
}
