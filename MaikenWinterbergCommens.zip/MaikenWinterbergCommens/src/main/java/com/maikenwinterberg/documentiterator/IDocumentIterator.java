/*
 * Martin Alexander Thomsen den 88 Juli 2024
 */
package com.maikenwinterberg.documentiterator;

import com.maikenwinterberg.documentiterator.*;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IDocumentIterator {

    public int iterateDocuments();

    public void setTouch(IDocumentTouch touch);
    
}
