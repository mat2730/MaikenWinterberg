/*
 * Martin Alexander Thomsen den 28 August 2024
 */
package com.maikenwinterberg.documentiterator;

import com.maikenwinterberg.documentiterator.*;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class JumperTouchNode extends TouchNode {

    private final Map registriesByDomain;
    private final String domainNameOfClient;
    private final String serviceName;
    private final int configIndex;
    private final IDocumentNode documentNode;

    public JumperTouchNode(Map registriesByDomain, String domainNameOfClient, String serviceName, int configIndex, IDocumentNode documentNode) {
        this.registriesByDomain = registriesByDomain;
        this.domainNameOfClient = domainNameOfClient;
        this.serviceName = serviceName;
        this.configIndex = configIndex;
        this.documentNode = documentNode;
    }

    public Map getRegistriesByDomain() {
        return registriesByDomain;
    }

    public String getDomainNameOfClient() {
        return domainNameOfClient;
    }

    public String getServiceName() {
        return serviceName;
    }

    public int getConfigIndex() {
        return configIndex;
    }

    public IDocumentNode getDocumentNode() {
        return documentNode;
    }

}
