/*
 * Martin Alexander Thomsen den 28 Juli 2024
 */
package com.maikenwinterberg.documentiterator;

import java.io.File;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileDocumentIterator implements IDocumentIterator {

    protected IDocumentTouch touch;
    protected File startingDir;
    private int count;

    @Override
    public void setTouch(IDocumentTouch touch) {
        this.touch = touch;
    }

    public void setStartingDir(File startingDir) {
        this.startingDir = startingDir;
    }

    protected TouchNode getTouchNode(String path, File file) {
        TouchNode node = new TouchNode();
        node.addAttribute(IDocumentNode.class.getName(), new FileDocumentNode(path, file));
        return node;
    }

    @Override
    public int iterateDocuments() {
        File files[] = startingDir.listFiles();
        if (files != null && files.length > 0) {
            for (File childFile : files) {
                try {
                    if (childFile.isDirectory()) {
                        traverseTree(childFile.getName(), childFile);
                    } else if (childFile.isFile() && !childFile.getName().endsWith(".tmp")) {
                        touch.touch(getTouchNode("", childFile));
                        count++;
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
        return count;
    }

    private void traverseTree(String path, File directory) throws Exception {
        //System.out.println("traverseTree " + path + " " + directory.getAbsolutePath());
        File[] files = directory.listFiles();
        for (File childFile : files) {
            try {
                if (childFile.isDirectory()) {
                    traverseTree(path + "/" + childFile.getName(), childFile);
                } else if (childFile.isFile() && !childFile.getName().endsWith(".tmp")) {
                    touch.touch(getTouchNode(path, childFile));
                    count++;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
