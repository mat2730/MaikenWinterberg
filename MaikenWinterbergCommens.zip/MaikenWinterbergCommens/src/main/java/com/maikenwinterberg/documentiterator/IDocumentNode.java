/*
 * Martin Alexander Thomsen den 8 August 2024
 */
package com.maikenwinterberg.documentiterator;

import com.maikenwinterberg.documentiterator.*;
import java.util.Date;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IDocumentNode {
    public String getId();

    public String getGroupName();

    public String getName();

    public long getLength();
    
    public Date getDate();

    public byte[] getBytes() throws Exception;

}
