/*
 * Martin Alexander Thomsen den 12 Januar 2025
 */
package com.maikenwinterberg.json;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * This implementation is ok for small json objects, but not good for big ones
 */
public class InMemoryJsonParser implements IJsonParser {

    private final String jsonString;
    private final Object rootNode;

    public InMemoryJsonParser(String jsonString) {
        if (jsonString == null) {
            jsonString = "";
        }
        this.jsonString = jsonString.trim();
        this.rootNode = getMap();
    }

    @Override
    public String toString() {
        return jsonString;
    }

    private int appendMap(String previousKey, Map map, int i) {
        String keyInMap = null;
        StringBuilder value = new StringBuilder();
        boolean in = false;
        for (; i < jsonString.length(); i++) {
            char c = jsonString.charAt(i);
            if (c == '\"') {
                if (in && keyInMap != null) {
                    map.put(keyInMap, value.toString());
                    keyInMap = null;
                    value = new StringBuilder();
                }
                in = !in;
            } else if (c == '{') {
                if (keyInMap == null) {
                    map = new HashMap();
                } else if (map != null) {
                    Map newMap = new HashMap();
                    Object mOrl = map.get(keyInMap);
                    if (mOrl == null) {
                        map.put(keyInMap, newMap);
                    } else if (mOrl instanceof List) {
                        ((List) mOrl).add(newMap);
                    } else if (mOrl instanceof Map) {
                        //change to list
                        map.remove(keyInMap);
                        List l = new LinkedList();
                        l.add(mOrl);
                        l.add(newMap);
                        map.put(keyInMap, l);
                    }
                    i = appendMap(keyInMap, newMap, i + 1);
                    keyInMap = null;
                }
            } else if (c == '}') {
                return i;
            } else if (c == ',') {
                if (in) {
                    value.append(c);
                } else {
                    if (previousKey != null) {
                        Object mOrl = (Object) map.get(previousKey);
                        if (mOrl instanceof Map) {
                            //change to list
                            map.remove(previousKey);
                            List l = new LinkedList();
                            l.add(mOrl);
                            map.put(previousKey, l);
                        }
                    }
                }
            } else if (c == '\n') {
                if (in) {
                    value.append(c);
                }
            } else if (c == '\t') {
                if (in) {
                    value.append(c);
                }
            } else if (c == ':') {
                if (in) {
                    value.append(c);
                } else {
                    keyInMap = value.toString();
                    value = new StringBuilder();
                }
            } else {
                if (in) {
                    value.append(c);
                } else {
                    //error
                }
            }
        }
        return i;
    }

    private Map getMap() {
        Map map = null;
        boolean in = false;
        String keyInMap = null;
        StringBuilder value = new StringBuilder();
        String firstKey = null;
        for (int i = 0; i < jsonString.length(); i++) {
            char c = jsonString.charAt(i);
            if (c == '\"') {
                if ((!in || keyInMap == null) || map == null) {
                } else {
                    map.put(keyInMap, value.toString());
                    keyInMap = null;
                    value = new StringBuilder();
                }
                in = !in;
            } else if (c == '{') {
                if (keyInMap == null) {
                    map = new HashMap();
                } else if (map != null) {
                    Map newMap = new HashMap();
                    Object mOrl = map.get(keyInMap);
                    if (mOrl == null) {
                        if (firstKey == null) {
                            firstKey = keyInMap;
                        }
                        map.put(keyInMap, newMap);
                        String oldKeyInMap = keyInMap;
                        keyInMap = null;
                        i = appendMap(oldKeyInMap, newMap, i + 1);
                    } else if (mOrl instanceof List) {
                        ((List) mOrl).add(map);
                    }
                }
            } else if (c == '}') {
                return map;
            } else if (c == ',') {
                if (in) {
                    value.append(c);
                } else {
                    if (firstKey != null && map != null) {
                        Object mOrl = (Object) map.get(firstKey);
                        if (mOrl instanceof Map) {
                            map.remove(firstKey);
                            List l = new LinkedList();
                            l.add(mOrl);
                            map.put(firstKey, l);
                        }
                    }
                }
            } else if (c == '\n') {
                if (in) {
                    value.append(c);
                }
            } else if (c == '\t') {
                if (in) {
                    value.append(c);
                }
            } else if (c == ':') {
                if (in) {
                    value.append(c);
                } else {
                    keyInMap = value.toString();
                    value = new StringBuilder();
                }
            } else {
                if (in) {
                    value.append(c);
                } else {
                    //error
                }
            }
        }
        return map;
    }

    public static void main(String arg[]) {
        String r = "{\"Response\": {\n"
                + "        \"CurrentDate\": \"2024-12/24 16:59:05\",\n"
                + "        \"Account\": \"apm.dk\",\n"
                + "        \"TelegramType\": \"HistoryTelegram\",\n"
                + "        \"ResponseType\": \"Success\",\n"
                + "        \"Entry\": {\n"
                + "                \"Date\": \"2024-12/24 16:57:56\",\n"
                + "                \"TransactionId\": \"apm.dk/17350558758673/0\",\n"
                + "                \"PostingType\": \"Debit\",\n"
                + "                \"CounterAccount\": \"maikenwinterberg.com\",\n"
                + "                \"Text\": \"Money collection\",\n"
                + "                \"Amount\": \"100.0\",\n"
                + "                \"Sum\": \"197892.0\"\n"
                + "        },\n"
                + "        \"Entry\": {\n"
                + "                \"Date\": \"2024-12/24 16:49:37\",\n"
                + "                \"TransactionId\": \"apm.dk/17350553777628/0\",\n"
                + "                \"PostingType\": \"Kredit\",\n"
                + "                \"CounterAccount\": \"maikenwinterberg.com\",\n"
                + "                \"Text\": \"Money transfer\",\n"
                + "                \"Amount\": \"-2208.0\",\n"
                + "                \"Sum\": \"197792.0\"\n"
                + "        },\n"
                + "        \"Entry\": {\n"
                + "                \"Date\": \"2024-12/24 16:37:55\",\n"
                + "                \"TransactionId\": \"danskebank.dk/17350546743982/0\",\n"
                + "                \"PostingType\": \"Debit\",\n"
                + "                \"CounterAccount\": \"danskebank.dk\",\n"
                + "                \"Text\": \"Loan 2024-12/24 16:37:54\",\n"
                + "                \"Amount\": \"200000.0\",\n"
                + "                \"Sum\": \"200000.0\"\n"
                + "        }\n"
                + "}}";
        InMemoryJsonParser json = new InMemoryJsonParser(r);
        System.out.println(r);
        System.out.println(json.getValue("Response/CurrentDate/text()"));
        System.out.println(json.getValue("Response/Entry"));
        System.out.println(json.getValue("Response/Entry/size()"));
        System.out.println(json.getValue("Response/Entry[0]/TransactionId/text()"));
        System.out.println(json.getValue("Response/Entry[1]/TransactionId/text()"));
        System.out.println(json.getValue("Response/Entry[2]/TransactionId/text()"));
        for (Object entry: (List)json.getValue("Response/Entry")) {
            System.out.println("TransactionId: " + json.getValue(entry, "TransactionId/text()"));
        }
    }

    @Override
    public Object getValue(String xpath) {
        return getValue(rootNode, xpath);
    }

    @Override
    public Object getValue(Object jsonNode, String xpath) {
        StringTokenizer tok = new StringTokenizer(xpath, "/[]");
        while (tok.hasMoreTokens()) {
            String token = tok.nextToken();
            if (token.endsWith("size()")) {
                if (jsonNode instanceof Collection) {
                    Object oldJson = jsonNode;
                    return ((Collection) oldJson).size();
                }
                if (jsonNode != null) {
                    return 1;
                }
                return 0;
            } else if (token.endsWith("text()")) {
                Object oldJson = jsonNode;
                return oldJson;
            } else {
                if (jsonNode instanceof Map) {
                    Object obj = ((Map) jsonNode).get(token);
                    jsonNode = obj;
                } else if (jsonNode instanceof List) {
                    if (token.endsWith("size()")) {
                        Object oldJson = jsonNode;
                        return ((Collection) oldJson).size();
                    }
                    try {
                        int index = Integer.parseInt(token);
                        if (index != -1) {
                            jsonNode = ((List) jsonNode).get(index);
                        }
                    } catch (Exception ex) {
                    }
                }
            }
        }
        return jsonNode;
    }
}
