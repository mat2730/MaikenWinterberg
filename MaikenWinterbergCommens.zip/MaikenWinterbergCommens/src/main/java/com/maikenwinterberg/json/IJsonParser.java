/*
 * Martin Alexander Thomsen den 12 Januar 2025
 */
package com.maikenwinterberg.json;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IJsonParser {
    public Object getValue (String xpath);
    public Object getValue(Object jsonNode, String xpath);
}
