/*
 * Martin Alexander Thomsen den 12 Januar 2025
 */
package com.maikenwinterberg.json;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class JsonParserFactory {

    public static IJsonParser newInstance(String jsonString) {
        return new InMemoryJsonParser(jsonString);
    }
}
