/*
 * Martin Alexander Thomsen den 24 August 2024
 */
package com.maikenwinterberg.config;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.swing.filechooser.FileSystemView;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class Config {

    public static Map<String, File> FILES = new HashMap();
    public static Map<String, Properties> PROPERTIES = new HashMap();
    public static Map<String, Long> LAST_MODIFIED_TIME = new HashMap();

    public enum Group1 {
        registryConfig, fileDomainJumperConfig, inbox2HTMLConfig
    }

    public enum Group2 {
        registry, fileSender, fileReceiver, inbox2HTML
    }

    public static String getValue(Group1 group1, Group2 group2, String name) {
        return getValue(group1, group2, name, -1);
    }

    public static String loadConfigResource(Group1 group1, String resourceName) throws Exception {
        FileSystemView view = FileSystemView.getFileSystemView();
        String configFolder = view.getHomeDirectory().getAbsolutePath();
        File file = new File(configFolder + "/config/" + group1.name() + "/" + resourceName);
        if (!file.exists()) {
            //RELATIV
            file = new File("config/" + resourceName);
        }
        if (file.exists()) {
            StringBuilder builder = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = br.readLine()) != null) {
                    builder.append(line).append("\n");
                }
            }
            return builder.toString().trim();
        }
        throw new IllegalStateException("resource not found " + resourceName);
    }

    public static String getValue(Group1 group1, Group2 group2, String name, int index) {
        Properties properties = PROPERTIES.get(group2.toString());
        try {
            if (properties == null) {
                properties = new Properties();
                PROPERTIES.put(group2.toString(), properties);
            }
            File registryFile = FILES.get(group2.toString());
            if (registryFile == null || !registryFile.exists()) {
                FileSystemView view = FileSystemView.getFileSystemView();
                String configFolder = view.getHomeDirectory().getAbsolutePath();
                registryFile = new File(configFolder + "/config/" + group1.toString() + "/" + group2.toString() + ".properties");
                if (!registryFile.exists()) {
                    //RELATIV
                    registryFile = new File("/config/" + group1.toString() + "/" + group2.toString() + ".properties");
                }
                if (registryFile.exists()) {
                    FILES.put(group2.toString(), registryFile);
                } else {
                    return null;

                }
            }
            BasicFileAttributes attr = Files.readAttributes(registryFile.toPath(), BasicFileAttributes.class
            );
            FileTime fileDate = attr.lastModifiedTime();
            Long lastModified = LAST_MODIFIED_TIME.get(group2.toString());
            if (lastModified == null || lastModified != fileDate.toMillis()) {
                LAST_MODIFIED_TIME.put(group2.toString(), fileDate.toMillis());
                properties.clear();
                properties.load(new FileInputStream(registryFile));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        if (properties == null) {
            return null;
        }
        if (index == -1) {
            return (String) properties.get(name);
        } else {
            String v = (String) properties.get(index + "." + name);
            if (v == null) {
                v = (String) properties.get(name);
            }
            return v;
        }
    }
}
