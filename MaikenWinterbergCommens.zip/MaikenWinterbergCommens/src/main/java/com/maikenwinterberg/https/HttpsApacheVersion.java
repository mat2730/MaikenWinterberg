/*
 * Martin Alexander Thomsen den 12 Januar 2025
 */
package com.maikenwinterberg.https;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.SecureRandom;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 * 
 * This version can be used if you have access to the private key of the server. However, it has a problem with a man in the midtle attack. 
 *  If you use it anyway, check original ip and creation timestamp and compare it with the first request to the service. The requires that the service provides you with the information.
 */
public class HttpsApacheVersion implements IGetRequest {

    public static void main(String[] args) {
        //String response = new HttpsApacheVersion().request(Environment.production, "https://34.41.57.110:8443/json/create?Account_name=test3&Secret_key=password");
        //String response = new HttpsApacheVersion().request(Environment.production, "https://maikenwinterberg.com:8443/json/create?Account_name=test3&Secret_key=password");
        String response = new HttpsApacheVersion().request(Environment.production, "https://documentnetwork.com:8443/json/create?Account_name=test3&Secret_key=password");
        //String response = new HttpsApacheVersion().request(Environment.development, "https://localhost:8443/json/create?Account_name=test3&Secret_key=password");
        System.out.println(response);
    }

    @Override
    public String request(Environment environment, String url) {
        try {
            KeyStore clientStore = KeyStore.getInstance("PKCS12");
            File keyStoreFile = new File(HttpsApacheVersion.class.getClassLoader().getResource("KeyStore_" + environment + ".p12").getFile());
            clientStore.load(new FileInputStream(keyStoreFile.getAbsoluteFile()), "123456".toCharArray());

            KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            kmf.init(clientStore, "123456".toCharArray());

            KeyManager[] keyManagers = kmf.getKeyManagers();

            KeyStore trustStore = KeyStore.getInstance("JKS");
            keyStoreFile = new File(HttpsApacheVersion.class.getClassLoader().getResource("KeyStore_" + environment + ".jks").getFile());
            trustStore.load(new FileInputStream(keyStoreFile.getAbsoluteFile()), "123456".toCharArray());

            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init(trustStore);
            TrustManager[] tms = tmf.getTrustManagers();

            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(keyManagers, tms, new SecureRandom());
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, new MartinAlexanderThomsenHostnameVerifier());
            BasicCredentialsProvider cp = new BasicCredentialsProvider();
            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(1000)
                    .setConnectionRequestTimeout(1000)
                    .setSocketTimeout(1000)
                    .build();
            CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).setDefaultCredentialsProvider(cp).setDefaultRequestConfig(requestConfig).build();
            HttpGet httpget = new HttpGet(url);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            CloseableHttpResponse r = httpclient.execute(httpget);
            r.getEntity().writeTo(baos);
            return baos.toString();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
}
