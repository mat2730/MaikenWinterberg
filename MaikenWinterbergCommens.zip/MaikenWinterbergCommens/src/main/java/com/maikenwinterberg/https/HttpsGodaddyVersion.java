/*
 * Martin Alexander Thomsen den 12 Januar 2025
 */
package com.maikenwinterberg.https;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * @see
 * https://stackoverflow.com/questions/19997344/how-can-i-connect-to-an-https-url-with-java
 *
 * This implementation can be use if Godaddy and Java want to play.
 */
public class HttpsGodaddyVersion implements IGetRequest {

    public static void main(String[] args) {
        String response = new HttpsGodaddyVersion().request(null, "https://maikenwinterberg.com:8443/json/create?Account_name=test3&Secret_key=password");
        System.out.println(response);
    }

    @Override
    public String request(Environment environment, String url) {
        try {
            URL hp = new URL(url);
            HttpsURLConnection hpCon = (HttpsURLConnection) hp.openConnection();
            //int responseCode = hpCon.getResponseCode();
            //boolean isProxy = hpCon.usingProxy();
            InputStream obj = hpCon.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(obj));
            String s;
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            boolean first = true;
            while ((s = br.readLine()) != null) {
                if (first) {
                    first = false;
                } else {
                    baos.write("\n".getBytes("ISO-8859-1"));
                }
                baos.write(s.getBytes("ISO-8859-1"));
            }
            return baos.toString("ISO-8859-1");

        } catch (Exception ex) {
            //ex.printStackTrace();
        }
        return null;
    }
}