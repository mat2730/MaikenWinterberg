/*
 * Martin Alexander Thomsen den 12 Januar 2025
 */
package com.maikenwinterberg.https;
/*
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
*/
/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * JavaNetHttpsVersion do not work with java version 9-21. Mabey one day it will work.
 */
/*
public class JavaNetHttpsVersion implements IGetRequest {

    public static void main(String arg[]) throws Exception {
        String response = new JavaNetHttpsVersion().request(null, "https://maikenwinterberg.com:8443/json/create?Account_name=test3&Secret_key=password");
        System.out.println(response);
   }

    @Override
    public String request(Environment environment, String url) {
        try {
            SSLContext sslContext = SSLContext.getInstance("TLS");
            X509TrustManager trustManager = new X509TrustManager() {
                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[]{};
                }

                @Override
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }

                @Override
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            };
            sslContext.init(null, new TrustManager[]{trustManager}, new SecureRandom());

            HttpClient client = HttpClient.newBuilder()
                    .sslContext(sslContext)
                    .build();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .build();
            HttpResponse response = client.send(request, BodyHandlers.discarding());
            return (response.body() == null ? null : response.body().toString());
        } catch (Exception ex) {
        }
        return null;
    }
}*/