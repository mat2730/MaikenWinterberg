/*
 * Martin Alexander Thomsen den 12 Januar 2025
 */
package com.maikenwinterberg.https;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * This version tries all versions in order: 1) godaddy 2) apache 3) javanet
 */
public class WrapperHttpsVersion implements IGetRequest {

    private static WrapperHttpsVersion HTTPSGetter = new WrapperHttpsVersion();

    public static IGetRequest newIntance() {
        return HTTPSGetter;
    }

    @Override
    public String request(Environment environment, String url) {
        if (environment == null) {
            environment = Environment.development;
        }
        String response = new HttpsGodaddyVersion().request(environment, url);
        if (response == null && url.contains("localhost")) {
            //for test only until ip and time check has been implemented
            response = new HttpsApacheVersion().request(environment, url);
        }
        if (response == null) {
           // response = new JavaNetHttpsVersion().request(environment, url);
        }
        return response;
    }

    public static void main(String[] args) {
        //String response = new WrapperHttpsVersion().request(Environment.production,, "https://maikenwinterberg.com:8443/json/create?Account_name=test3&Secret_key=password");
        String response = new WrapperHttpsVersion().request(Environment.production, "https://documentnetwork.com:8443/json/create?Account_name=test3&Secret_key=password");
        System.out.println(response);
    }
}