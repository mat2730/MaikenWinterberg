/*
 * Martin Alexander Thomsen den 12 Januar 2025
 */
package com.maikenwinterberg.https;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.util.HashMap;
import java.util.Map;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class MartinAlexanderThomsenHostnameVerifier implements HostnameVerifier {

    public static Map<Integer, PublicKey> PUBLIC_KEYS = new HashMap();

    @Override
    public boolean verify(String hostname, SSLSession session) {
        if (session.toString().contains("TLS_AES_256_GCM_SHA384)")) {
            try {
                Certificate[] certificates = session.getPeerCertificates();
                for (int i = 0; i < certificates.length; i++) {
                    Certificate certificate = certificates[i];
                    int pi = -1;
                    while (true) {
                        pi++;
                        PublicKey p = PUBLIC_KEYS.get(pi);
                        if (p == null) {
                            File file = null;
                            String keyName = hostname + ".publicKey_" + pi + ".key";
                            try {
                                file = new File(MartinAlexanderThomsenHostnameVerifier.class.getClassLoader().getResource(hostname +"."+ keyName).getFile());
                            } catch (Exception ex) {
                            }
                            if (file == null || !file.exists()) {
                                if (pi == 0) {
                                    //create public key
                                    p = certificate.getPublicKey();
                                    if (file == null) {
                                        String dir = new File(MartinAlexanderThomsenHostnameVerifier.class.getClassLoader().getResource(".").getFile()).getAbsolutePath();
                                        file = new File(dir+"/"+keyName);
                                    }
                                    file.getParentFile().mkdirs();
                                    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                                        oos.writeObject(p);
                                        oos.flush();
                                        return true;
                                    } catch (Exception ex) {
                                        ex.printStackTrace();
                                    }
                                }
                                break;
                            }
                            System.out.println(file.getAbsoluteFile());
                            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                                p = (PublicKey) ois.readObject();
                                if (p != null) {
                                    PUBLIC_KEYS.put(pi, p);
                                }
                            } catch (Exception ex) {
                            } 
                        }
                        if (p != null) {
                            try {
                                certificate.verify(p);
                                return true;
                            } catch (Exception ex) {
                            }
                        }
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return false;
    }
}