/*
 * Martin Alexander Thomsen den 12 Januar 2025
 */
package com.maikenwinterberg.https;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IGetRequest {
    public enum Environment {
        development, production
    }
    public String request(Environment environment, String url);
}
