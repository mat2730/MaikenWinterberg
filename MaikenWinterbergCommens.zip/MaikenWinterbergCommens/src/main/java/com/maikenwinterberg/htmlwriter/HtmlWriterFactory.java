/*
 * Martin Alexander Thomsen den 16 August 2024
 */
package com.maikenwinterberg.htmlwriter;

import com.maikenwinterberg.config.Config;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class HtmlWriterFactory {

    //private static final Map<Integer, IHtmlWriter> HTML_WRITER = new HashMap();

    public static IHtmlWriter newIntance(int index) {
        IHtmlWriter w = null;//HTML_WRITER.get(index);
        if (w != null) {
            return w;
        }
        try {
            String classname = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "htmlwriterimpl", index);
            w = (IHtmlWriter) Class.forName(classname).newInstance();
        } catch (Exception ex) {
            //ignore
        }
        if (w == null) {
            w = new TemplateHTMLWriterImpl();
        }
        //HTML_WRITER.put(index, w);
        return w;
    }
}
