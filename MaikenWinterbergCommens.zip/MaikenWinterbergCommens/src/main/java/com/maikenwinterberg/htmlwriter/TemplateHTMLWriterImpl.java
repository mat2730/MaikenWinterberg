/*
 * Martin Alexander Thomsen den 25 August 2024
 */
package com.maikenwinterberg.htmlwriter;

import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.documentiterator.IDocumentNode;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class TemplateHTMLWriterImpl implements IHtmlWriter, Comparator<IDocumentNode> {

    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM YYYY");

    private final Map attributes = new HashMap();
    private final Map<IDocumentNode, String> tableRows = new TreeMap(this);
    private String html;

    public TemplateHTMLWriterImpl() {
    }

    private static String replaceAll(Map<String, String> attribute, String text) {
        int i = text.indexOf("${");
        int currentIndex = 0;
        StringBuilder builder = new StringBuilder();
        while (i != -1) {
            String part = text.substring(currentIndex, i);
            builder.append(part);
            currentIndex = text.indexOf("}", i);
            String attributeName = text.substring(i + 2, currentIndex);
            currentIndex++;
            String value = (String) attribute.get(attributeName);
            builder.append(value);
            i = text.indexOf("${", i + 1);
        }
        builder.append(text.substring(currentIndex, text.length()));
        return builder.toString();
    }

    private static String createHTML(Map attributes, String template) {
        try {
            template = replaceAll(attributes, template);
            //change permisions of sh file
            return template;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    public void addPreHtml(int index, HtmlWriterParam params) {
    }

    @Override
    public void addAttribute(String name, String value) {
        attributes.put(name, value);
    }

    @Override
    public void addLink(int index, String link, IDocumentNode file, HtmlWriterParam params) {
        //TODO config via param
        String linkurl = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "linkurl");
        String withPasswordAsString = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "withPassword", index);
        boolean withPassword = Boolean.parseBoolean(withPasswordAsString);
        StringBuilder tableBuilder = new StringBuilder();
        tableBuilder.append("<tr class=\"table__row\">");
        tableBuilder.append("<td class=\"table__content\" data-heading=\"Date\">").append(sdf.format(file.getDate())).append("</td>");
        tableBuilder.append("<td class=\"table__content\" data-heading=\"Path\">").append(file.getGroupName()).append("</td>");
        tableBuilder.append("<td class=\"table__content\" data-heading=\"Filename\">");
        tableBuilder.append("<a href='").append(linkurl).append("/").append(link);
        if (!withPassword) {
            tableBuilder.append("?pass=.");
        }
        tableBuilder.append("'>").append(file.getName()).append("</a>").append("</td>");;
        tableBuilder.append("<td class=\"table__content\" data-heading=\"Size\">").append((file.getLength())).append("</td>");
        tableBuilder.append("</tr>");
        tableRows.put(file, tableBuilder.toString());
    }

    @Override
    public void addPostHtml(int index, String template) {
        if (attributes.get("header") == null) {
            attributes.put("header", "Inbox");
        }
        if (attributes.get("tablerows") == null) {
            StringBuilder tablerowsBuilder = new StringBuilder();
            for (String thtml : tableRows.values()) {
                tablerowsBuilder.append(thtml);
            }
            attributes.put("tablerows", tablerowsBuilder.toString());
        }
        html = createHTML(attributes, template);
    }

    @Override
    public String toString() {
        return html;
    }

    @Override
    public int compare(IDocumentNode o1, IDocumentNode o2) {
        String sc = (String) attributes.get("sortcolumn");
        if (sc != null && sc.equalsIgnoreCase("path")) {
            return (o1.getGroupName().compareTo(o2.getGroupName()));
        } else if (sc != null && sc.equalsIgnoreCase("filename")) {
            return (o1.getName().compareTo(o2.getName()));
        } else if (sc != null && sc.equalsIgnoreCase("size")) {
            return Long.valueOf(o1.getLength()).compareTo(o2.getLength());
        } else {
            return o1.getDate().compareTo(o2.getDate());
        }
    }
}
