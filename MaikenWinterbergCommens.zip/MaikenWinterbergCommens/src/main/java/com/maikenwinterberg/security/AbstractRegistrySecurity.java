/*
 * Martin Alexander Thomsen den 12 August 2024
 */
package com.maikenwinterberg.security;

import org.apache.commons.codec.binary.Base64;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public abstract class AbstractRegistrySecurity implements IRegistrySecurity {

    @Override
    public String toBase64(byte[] bytes) throws Exception {
        if (bytes == null || bytes.length == 0) {
            return "";
        }
        return Base64.encodeBase64String(bytes);
    }

    @Override
    public byte[] fromBase64(String base64) throws Exception {
        if (base64 == null || base64.length() == 0) {
            return new byte[0];
        }
        return Base64.decodeBase64(base64);
    }
}