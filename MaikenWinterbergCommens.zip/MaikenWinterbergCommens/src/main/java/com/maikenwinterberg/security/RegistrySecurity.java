/*
 * Martin Alexander Thomsen den 12 Juli 2024
 */
package com.maikenwinterberg.security;

import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import javax.crypto.SecretKey;
import java.util.Map;
import java.util.HashMap;

/**
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class RegistrySecurity {

    public static IRegistrySecurity DEFAULT_SECURITY_IMPL = new StaticRegistrySecurity();

    private static final Map<Object, IRegistrySecurity> SECURITY_IMPLEMENTATIONS = new HashMap();

    public static void setSecurityImplemetation(Object key2SecurityImpl, IRegistrySecurity securityImpl) throws Exception {
        if (securityImpl != null && key2SecurityImpl != null) {
            SECURITY_IMPLEMENTATIONS.put(key2SecurityImpl, securityImpl);
        }
    }

    private static IRegistrySecurity getRegistrySecurityImpl(Object key2SecurityImpl) {
        IRegistrySecurity rs = null;
        try {
            rs = SECURITY_IMPLEMENTATIONS.get(key2SecurityImpl);
        } catch (Exception ex) {
            //ignore
        }
        if (rs == null) {
            try {
                rs = (IRegistrySecurity) Class.forName(key2SecurityImpl.toString()).newInstance();
                SECURITY_IMPLEMENTATIONS.put(key2SecurityImpl, rs);
            } catch (Exception ex) {
                //ignore
            }
        }
        if (rs == null) {
            return DEFAULT_SECURITY_IMPL;
        } else {
            return rs;
        }
    }

    public static void setSecretKey(Object key2SecurityImpl, Object key2SecretKey, SecretKey secretKey) throws Exception {
        getRegistrySecurityImpl(key2SecurityImpl).setSecretKey(key2SecretKey, secretKey);
    }

    public static SecretKey getSecretKey(Object key2SecurityImpl, Object key2SecretKey) throws Exception {
        return getRegistrySecurityImpl(key2SecurityImpl).getSecretKey(key2SecretKey);
    }

    public static String textEncrypt(Object key2SecurityImpl, Object key2SecretKey, String text) throws Exception {
        return getRegistrySecurityImpl(key2SecurityImpl).textEncrypt(key2SecretKey, text);
    }

    public static String textDecrypt(Object key2SecurityImpl, Object key2SecretKey, String text) throws Exception {
        return getRegistrySecurityImpl(key2SecurityImpl).textDecrypt(key2SecretKey, text);
    }

    public static byte[] byteEncrypt(Object key2SecurityImpl, Object key2SecretKey, byte[] bytes) throws Exception {
        return getRegistrySecurityImpl(key2SecurityImpl).byteEncrypt(key2SecretKey, bytes);
    }

    public static byte[] byteDecrypt(Object key2SecurityImpl, Object key2SecretKey, byte[] bytes) throws Exception {
        return getRegistrySecurityImpl(key2SecurityImpl).byteDecrypt(key2SecretKey, bytes);
    }

    public static SecretKey toSecretKey(Object key2SecurityImpl, byte[] seretKeyAsBytes) throws Exception {
        return getRegistrySecurityImpl(key2SecurityImpl).toSecretKey(seretKeyAsBytes);
    }

    public static KeyPair getKeyPair(Object key2SecurityImp, Object key, boolean renew) throws Exception {
        return getRegistrySecurityImpl(key2SecurityImp).getKeyPair(key, renew);
    }

    public static byte[] privateKeyDecrypt(Object key2SecurityImpl, PrivateKey privateKey, byte[] data) throws Exception {
        return getRegistrySecurityImpl(key2SecurityImpl).privateKeyDecrypt(privateKey, data);
    }

    public static byte[] publicKeyEncrypt(Object key2SecurityImpl, PublicKey publicKey, byte[] data) throws Exception {
        return getRegistrySecurityImpl(key2SecurityImpl).publicKeyEncrypt(publicKey, data);
    }

    public static byte[] publicKeyEncryptSecretKey(Object key2SecurityImpl, PublicKey publicKey, SecretKey secretKey) throws Exception {
        return getRegistrySecurityImpl(key2SecurityImpl).publicKeyEncryptSecretKey(publicKey, secretKey);
    }

    public static String toBase64(Object key2SecurityImpl, PublicKey key) throws Exception {
        return getRegistrySecurityImpl(key2SecurityImpl).toBase64(key);
    }

    public static String toBase64(Object key2SecurityImpl, byte[] bytes) throws Exception {
        return getRegistrySecurityImpl(key2SecurityImpl).toBase64(bytes);
    }

    public static byte[] fromBase64(Object key2SecurityImpl, String base64) throws Exception {
        return getRegistrySecurityImpl(key2SecurityImpl).fromBase64(base64);
    }

    public static PublicKey fromBase642SPublicKey(Object key2SecurityImpl, String base64PublicKey) throws Exception {
        return getRegistrySecurityImpl(key2SecurityImpl).fromBase642SPublicKey(base64PublicKey);
    }
}
