/*
 * Martin Alexander Thomsen den 12 Juli 2024
 */
package com.maikenwinterberg.security;

import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Map;
import javax.crypto.SecretKey;

/**
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class StaticRegistrySecurity extends AbstractRegistrySecurity {

    @Override
    public void registerPublicKey(String clientSocketIp, Map<String, String> attributes) throws Exception {
        //do nothing
    }

    @Override
    public void setSecretKey(Object key2SecretKey, SecretKey secretKey) throws Exception {
        AESUtil.setProjectKey(key2SecretKey, secretKey);
    }

    @Override
    public SecretKey getSecretKey(Object key2SecretKey) throws Exception {
        return AESUtil.getProjectKey(key2SecretKey);
    }

    @Override
    public String textEncrypt(Object key2SecretKey, String text) throws Exception {
        return AESUtil.simpleEncrypt(key2SecretKey, text);
    }

    @Override
    public String textDecrypt(Object key2SecretKey, String text) throws Exception {
        return AESUtil.simpleDecrypt(key2SecretKey, text);
    }

    @Override
    public byte[] byteEncrypt(Object key2SecretKey, byte[] bytes) throws Exception {
        return AESUtil.simpleEncrypt(key2SecretKey, bytes);
    }

    @Override
    public byte[] byteDecrypt(Object key2SecretKey, byte[] bytes) throws Exception {
        return AESUtil.simpleDecrypt(key2SecretKey, bytes);
    }

    @Override
    public SecretKey toSecretKey(byte[] seretKeyAsBytes) throws Exception {
        return AESUtil.fromBytes(seretKeyAsBytes);
    }

    @Override
    public SecretKey getKeyFromPassword(String password, String salt) throws Exception {
        return AESUtil.getKeyFromPassword(password, salt);
    }

    @Override
    public KeyPair getKeyPair(Object key, boolean renew) throws Exception {
        return RSAUtil.getRSAKeyPar(key, renew);
    }

    @Override
    public byte[] privateKeyDecrypt(PrivateKey privateKey, byte[] data) throws Exception {
        return RSAUtil.decrypt(privateKey, data);
    }

    @Override
    public byte[] publicKeyEncrypt(PublicKey publicKey, byte[] data) throws Exception {
        return RSAUtil.encrypt2Bytes(publicKey, data);
    }

    @Override
    public byte[] publicKeyEncryptSecretKey(PublicKey publicKey, SecretKey secretKey) throws Exception {
        return RSAUtil.encrypt2Bytes(publicKey, secretKey.getEncoded());
    }

    @Override
    public String toBase64(PublicKey key) throws Exception {
        return RSAUtil.toBase64(key);
    }

    /*
    @Override
    public String toBase64(byte[] bytes) throws Exception {
        return Base64.getMimeEncoder().encodeToString(bytes);
    }

    @Override
    public byte[] fromBase64(String base64) throws Exception {
        return Base64.getMimeDecoder().decode(base64);
    }
     */
    @Override
    public PublicKey fromBase642SPublicKey(String base64PublicKey) throws Exception {
        return RSAUtil.fromBase64(base64PublicKey);
    }
}
