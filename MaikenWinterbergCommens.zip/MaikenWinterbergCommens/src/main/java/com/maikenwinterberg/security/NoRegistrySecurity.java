/*
 * Martin Alexander Thomsen den 12 August 2024
 */
package com.maikenwinterberg.security;

import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Map;
import javax.crypto.SecretKey;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class NoRegistrySecurity extends AbstractRegistrySecurity {

    @Override
    public void registerPublicKey(String clientSocketIp, Map<String, String> attributes) throws Exception {
    }

    @Override
    public void setSecretKey(Object key2SecretKey, SecretKey secretKey) throws Exception {
    }

    @Override
    public SecretKey getSecretKey(Object key2SecretKey) throws Exception {
        //dummy key
        return new SecretKey() {
            @Override
            public String getAlgorithm() {
                return "noSecurity";
            }

            @Override
            public String getFormat() {
                return "noFormat";
            }

            @Override
            public byte[] getEncoded() {
                return new byte[0];
            }

        };
    }

    @Override
    public SecretKey getKeyFromPassword(String password, String salt) throws Exception {
        //dummy key
        return new SecretKey() {
            @Override
            public String getAlgorithm() {
                return "noSecurity";
            }

            @Override
            public String getFormat() {
                return "noFormat";
            }

            @Override
            public byte[] getEncoded() {
                return new byte[0];
            }

        };
    }

    @Override
    public String textEncrypt(Object key2SecretKey, String text) throws Exception {
        return text;
    }

    @Override
    public String textDecrypt(Object key2SecretKey, String text) throws Exception {
        return text;
    }

    @Override
    public byte[] byteEncrypt(Object key2SecretKey, byte[] bytes) throws Exception {
        return bytes;
    }

    @Override
    public byte[] byteDecrypt(Object key2SecretKey, byte[] bytes) throws Exception {
        return bytes;
    }

    @Override
    public SecretKey toSecretKey(byte[] seretKeyAsBytes) throws Exception {
        return getSecretKey(null);
    }

    @Override
    public KeyPair getKeyPair(Object key, boolean renew) throws Exception {
        key = "dummyKey";
        return RSAUtil.getRSAKeyPar(key, renew);
    }

    @Override
    public byte[] privateKeyDecrypt(PrivateKey privateKey, byte[] data) throws Exception {
        return data;
    }

    @Override
    public byte[] publicKeyEncrypt(PublicKey publicKey, byte[] data) throws Exception {
        return data;
    }

    @Override
    public byte[] publicKeyEncryptSecretKey(PublicKey publicKey, SecretKey secretKey) throws Exception {
        return new byte[0];
    }

    @Override
    public String toBase64(PublicKey key) throws Exception {
        return "";
    }

    @Override
    public PublicKey fromBase642SPublicKey(String base64PublicKey) throws Exception {
        return getKeyPair(null, false).getPublic();
    }
}
