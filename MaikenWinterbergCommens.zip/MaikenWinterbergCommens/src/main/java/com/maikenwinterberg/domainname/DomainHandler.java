/*
 * Martin Alexander Thomsen den 10 Januar 2025
 */
package com.maikenwinterberg.domainname;

import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.https.IGetRequest;
import com.maikenwinterberg.https.WrapperHttpsVersion;
import com.maikenwinterberg.json.JsonParserFactory;
import java.net.InetAddress;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class DomainHandler {

    public static String getLocalIp() {
        try {
            InetAddress localhost = InetAddress.getLocalHost();
            return localhost.getHostAddress();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "localhost";
    }

    public static String getHostAddress(String domainName_Or_AccountNameWithHost) {
        try {
            try {
                //format: ${accountName}.pay.${hostName}
                int index = domainName_Or_AccountNameWithHost.indexOf(".pay.");
                if (index != -1) {
                    //its an account name with host
                    String domainNameOrAccountName = domainName_Or_AccountNameWithHost.substring(0, index);
                    try {
                        //return if its a domainName
                        return InetAddress.getByName(domainNameOrAccountName).getHostAddress();
                    } catch (Exception ex) {
                    }
                    //its not a domainname, check if its an accountname
                    String payHost = domainName_Or_AccountNameWithHost.substring(index + 5);
                    //TODO get ip from payHost
                    String accountUrl = Config.getValue(Config.Group.inbox2HTMLConfig, Config.Property.inbox2HTML, "accountUrl");
                    if (accountUrl == null) {
                        accountUrl = "https://" + payHost + ".com:8443/json/account?accountname=";
                    }
                    String getAccountUrl = accountUrl + domainNameOrAccountName;
                    String json = WrapperHttpsVersion.newIntance().request(IGetRequest.Environment.production, getAccountUrl);
                    String ip = (String) JsonParserFactory.newInstance(json).getValue("Response/IP/text()");
                    if (ip != null) {
                        return ip;
                    }

                }
            } catch (Exception ex) {
            }
            //return if its a domainName
            return InetAddress.getByName(domainName_Or_AccountNameWithHost).getHostAddress();
        } catch (Exception ex) {

        }
        return null;
    }

    public static boolean validateDomain(String domainName, String ip) {
        try {
            String ipFromServer = getHostAddress(domainName);
            if (ipFromServer.equals(ip)) {
                return true;
            }
        } catch (Exception ex) {
        }
        return false;
    }
}
