/*
 * Martin Alexander Thomsen den 18 Juli 2024
 */
package com.maikenwinterberg.fileregistry;

import java.io.File;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class JDBCFileRegistry implements IFileRegistry {

    private static final Map<String, String> CACHE = new HashMap();
    private static final boolean INFO = true;
    private static Connection connection;
    private static boolean useDB;

    private String driver;
    private String url;
    private String username;
    private String password;

    public JDBCFileRegistry() {
    }

    @Override
    public void setDriver(String driver) {
        this.driver = driver;
    }

    @Override
    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public void setusername(String username) {
        this.username = username;
    }

    @Override
    public void setpassword(String password) {
        this.password = password;
    }

    @Override
    public void initConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                Class.forName(driver);
                connection = DriverManager.getConnection(url, username, password);
                PreparedStatement st = connection.prepareStatement("create table IF NOT EXISTS fileregistry(domainname varchar(255), dodomaincheck char(1), link varchar(255), filename varchar(255), filesize bigint, filedate datetime, createdat datetime default CURRENT_TIMESTAMP, updatedat datetime default CURRENT_TIMESTAMP, PRIMARY KEY(domainname,filename,filesize,filedate));");
                st.executeUpdate();
                useDB = true;
                System.out.println("using db for the synchronization");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            useDB = false;
            System.out.println("using cache for the synchronization");
        }
    }

    @Override
    public String isRegistrated(String domainName, File file) throws Exception {
        String fileName = file.getAbsolutePath();
        BasicFileAttributes attr = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
        FileTime fileDate = attr.lastModifiedTime();
        long fileSize = file.length();
        String link = (String) CACHE.get(domainName + "." + fileName + "." + fileSize + "." + fileDate.toMillis());
        if (link != null) {
            return link;
        }
        if (useDB) {
            StringBuilder sqlBuf = new StringBuilder();
            sqlBuf.append("select * from fileregistry where domainname=? and filename=? and filesize=? and filedate=?");
            PreparedStatement st = connection.prepareStatement(sqlBuf.toString());
            st.setString(1, domainName);
            st.setString(2, fileName);
            st.setLong(3, fileSize);
            st.setDate(4, new Date(fileDate.toMillis()));
            if (INFO) {
                System.out.println(sqlBuf.toString());
            }
            ResultSet r = st.executeQuery();
            if (r.next()) {
                link = r.getString("link");
                CACHE.put(domainName + "." + fileName + "." + fileSize + "." + fileDate.toMillis(), link);
                return link;
            }
        }
        return null;
    }

    @Override
    public File getFile(String ipAdress, String link) throws Exception {
        StringBuilder sqlBuf = new StringBuilder();
        sqlBuf.append("select * from fileregistry where link=?");
        PreparedStatement st = connection.prepareStatement(sqlBuf.toString());
        st.setString(1, link);
        if (INFO) {
            System.out.println(sqlBuf.toString());
        }
        ResultSet r = st.executeQuery();
        if (r.next()) {
            String domainName = (String) r.getString("domainname");
            String dodomaincheck = (String) r.getString("dodomaincheck");
            String filename = (String) r.getString("filename");
            if (dodomaincheck != null && dodomaincheck.equals("1")) {
                //verify ip
                InetAddress inetAddress = null;
                try {
                    inetAddress = InetAddress.getByName(domainName);
                    String hostAddress = inetAddress.getHostAddress();
                    if (hostAddress != null && hostAddress.equals(ipAdress)) {
                        return new File(filename);
                    }
                } catch (Exception ex) {
                }
                throw new IllegalStateException("Ip address: " + ipAdress + " check against domainnamne " + domainName + " failed");
            } else {
                return new File(filename);
            }
        }
        return null;
    }

    @Override
    public String registerFile(String receiverDomainName, boolean doDomainCheck, File file) throws Exception {
        String link = isRegistrated(receiverDomainName, file);
        if (link != null) {
            return link;
        } else {
            link = UUID.randomUUID().toString();
            String fileName = file.getAbsolutePath();
            BasicFileAttributes attr = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
            FileTime fileDate = attr.lastModifiedTime();
            long fileSize = file.length();
            if (useDB) {
                StringBuilder sqlBuf = new StringBuilder();
                sqlBuf.append("insert into fileregistry(domainname, dodomaincheck, link, filename,filesize,filedate) values(?,?,?,?,?,?)");
                if (INFO) {
                    System.out.println(sqlBuf.toString());
                }
                PreparedStatement st = connection.prepareStatement(sqlBuf.toString());
                st.setString(1, receiverDomainName);
                if (doDomainCheck) {
                    st.setString(2, "1");
                } else {
                    st.setString(2, "0");
                }
                st.setString(3, link);
                st.setString(4, fileName);
                st.setLong(5, fileSize);
                st.setDate(6, new Date(fileDate.toMillis()));
                st.executeUpdate();
            }
            CACHE.put(receiverDomainName + "." + fileName + "." + fileSize + "." + fileDate.toMillis(), link);
        }
        return link;
    }
}
