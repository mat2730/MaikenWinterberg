Installation of the LinuxServiceInstaller in 4 stepts:

1) Install Java onto your system if not already installed
    sudo apt-get install openjdk-17-jdk

2) modify the installService.sh 
    A) The first parameter is the serviceName
    B) The second parameter is the location of the home folder
    C) The third parameter is the command file to be executed by the service
 
3) execute the installService.sh command. It will create 4 files:
    status${serviceName}.sh
    unInstall${serviceName}.sh
    reInstall${serviceName}.sh
    ${serviceName}.service

4) check status: You can check if the service has been install correctly by executing the status${serviceName}.sh file

If you wish to change the code or create plugins for the MaikenWinterbergLinuxServiceInstaller can I recommend Netbeans: https://netbeans.apache.org/front/main/index.html



    
