echo installing service...
sudo systemctl stop MaikenWinterbergAccount.service
sudo cp MaikenWinterbergAccount.service /etc/systemd/system
sudo systemctl daemon-reload
sudo systemctl start MaikenWinterbergAccount.service
sudo systemctl enable MaikenWinterbergAccount.service
echo done installing service
#sleep 10s