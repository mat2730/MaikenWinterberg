echo unInstalling service...
sudo systemctl stop MaikenWinterbergAccount.service
sudo rm /etc/systemd/system/MaikenWinterbergAccount.service 
sudo systemctl daemon-reload
echo done unInstalling service
sleep 10s