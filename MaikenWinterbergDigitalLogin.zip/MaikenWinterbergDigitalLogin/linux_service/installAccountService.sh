echo installing account service
java --class-path classes Install MaikenWinterbergAccount ../bin startAccountService.sh
echo done installing account service
