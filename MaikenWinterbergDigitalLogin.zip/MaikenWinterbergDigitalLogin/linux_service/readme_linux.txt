This program requires that Java 1.17+ is installed on you computer.

Installation on linux in 3 stepts:
1) Install Java onto your system if not allready installed
    sudo apt-get install openjdk-17-jdk2
2) Execute the installAccountService.sh file
3) Open for firewall port 8443
