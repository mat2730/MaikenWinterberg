/*
 * Martin Alexander Thomsen den 30 December 2024
 */
package com.maikenwinterberg.account.datagram;

import com.maikenwinterberg.account.database.FileAccountImpl;
import com.maikenwinterberg.account.database.Info;
import com.maikenwinterberg.account.http.StartHttps;
import com.maikenwinterberg.config.Config;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class GetAccountNameBySessionIdServer extends Thread {

    public void run() {
        int port = 2202;
        DatagramSocket socket = null;
        try {
            port = Integer.parseInt(Config.getValue(Config.Group.accountConfig, Config.Property.account, "datagramPort"));
        } catch (Exception ex) {
            System.out.println("using default port for datagram " +2202);
        }
        try {
            socket = new DatagramSocket(port);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        int count = 0;
        while (true) {
            try {
                while (true) {
                    //receive request
                    byte[] buffer = new byte[256];
                    DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                    //System.out.println("listening on port " + port);
                    socket.receive(request);
                    //send response
                    String sessionId = new String(buffer, StartHttps.ENCODING);
                    //System.out.println("sessionId " + sessionId);
                    Info info = FileAccountImpl.getInstance().getSessionInfo(sessionId);
                    InetAddress clientAddress = request.getAddress();
                    int clientPort = request.getPort();
                    if (info != null) {
                        buffer = info.toString().getBytes(StartHttps.ENCODING);
                    } else {
                        buffer = "0".getBytes(StartHttps.ENCODING);;
                    }
                    DatagramPacket response = new DatagramPacket(buffer, buffer.length, clientAddress, clientPort);
                    socket.send(response);
                    count = 0;
                }
            } catch (Exception ex) {
                if (count == 0) {
                    try {
                        port = Integer.parseInt(Config.getValue(Config.Group.accountConfig, Config.Property.account, "datagramPort"));
                        socket = new DatagramSocket(port);
                        count++;
                    } catch (Exception exe) {
                        ex.printStackTrace();
                        break;
                    }
                }
            }
        }
        System.out.println("cannot connect to socket");
    }

    public static void main(String arg[]) throws Exception {
        new GetAccountNameBySessionIdServer().start();
    }
}
