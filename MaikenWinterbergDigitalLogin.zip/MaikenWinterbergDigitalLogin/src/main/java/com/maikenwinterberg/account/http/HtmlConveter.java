/*
 * Martin Alexander Thomsen den 30 December 2024
 */
package com.maikenwinterberg.account.http;

import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.htmlwriter.IHtmlWriter;
import com.maikenwinterberg.htmlwriter.TemplateHTMLWriterImpl;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class HtmlConveter implements IConverte {
    
    @Override
    public String converte(String headline, Map<String, String> attributes) throws Exception {
        StringBuilder tablerows = new StringBuilder();
        for (String attributeName : attributes.keySet()) {
            String attributeValue = attributes.get(attributeName);
            tablerows
                    .append("<tr><td style='vertical-align:top;' class=\"table__content\" data-heading=\"Name\">")
                    .append(attributeName)
                    .append("</td>")
                    .append("<td class=\"table__content\" data-heading=\"Value\">")
                    .append(attributeValue)
                    .append("</td></tr>");
        }
        //String resourceUrl = Config.getValue(Config.Group.accountConfig, Config.Property.account, "resourceurl");
        IHtmlWriter iw = new TemplateHTMLWriterImpl();
        iw.addAttribute("header", headline);
        //iw.addAttribute("background", resourceUrl + "/background.jpg");
        iw.addAttribute("tablerows", tablerows.toString());
        String defaulttemplate = Config.getValue(Config.Group.accountConfig, Config.Property.account, "attributetemplate");
        iw.addAttribute("template", defaulttemplate);
        String template = Config.loadConfigResource(Config.Group.accountConfig, defaulttemplate);
        if (template == null) {
            System.out.println("No templage.service found in conf");
            return null;
        }
        iw.addPostHtml(0,template);
        return iw.toString();
    }
    

    @Override
    public String converte(String headline, String link, String errorMessage, Map<String, String> attributes, Throwable throwable) throws Exception{
        StringBuilder tablerows = new StringBuilder();
        for (String attributeName : attributes.keySet()) {
            String attributeValue = attributes.get(attributeName);
            tablerows
                    .append("<tr><td style='vertical-align:top;' class=\"table__content\" data-heading=\"Function\">")
                    .append(attributeName)
                    .append("</td>")
                    .append("<td class=\"table__content\" data-heading=\"Submit\">")
                    .append(attributeValue)
                    .append("</td></tr>");
        }
        //String resourceUrl = Config.getValue(Config.Group.accountConfig, Config.Property.account, "resourceurl");
        IHtmlWriter iw = new TemplateHTMLWriterImpl();
        iw.addAttribute("header", headline);
        if (errorMessage != null) {
            iw.addAttribute("errorMessage", errorMessage);
        }
        //iw.addAttribute("background", resourceUrl + "/background.jpg");
        iw.addAttribute("link", link);
        iw.addAttribute("tablerows", tablerows.toString());
        String defaulttemplate = Config.getValue(Config.Group.accountConfig, Config.Property.account, "defaulttemplate");
        iw.addAttribute("template", defaulttemplate);
        String template = Config.loadConfigResource(Config.Group.accountConfig, defaulttemplate);
        if (template == null) {
            System.out.println("No templage.service found in conf");
            return null;
        }
        iw.addPostHtml(0,template);
        return iw.toString();
    }
}
