/*
 * Martin Alexander Thomsen den 30 December 2024
 */
package com.maikenwinterberg.account.database;

import java.util.UUID;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IAccount {

    public Info createAccount(String privateKey, String accountName, String ip) throws Exception;

    public Info getAccountInfo(String accountName) throws Exception;

    public Info renewAccount(String privateKey, String ip) throws Exception;

    public Info enterAccount(String privateKey, String ip) throws Exception;

    public Info getAccountInfo(UUID accountId) throws Exception;

    public Info getSessionInfo(String sessionId) throws Exception;

    public String getSessionIp(String accountName) throws Exception;

    public boolean renewSessionIp(UUID renewtoken, String newIp) throws Exception;

    public Info lock(UUID accountId) throws Exception;

    public Info unlock(UUID accountId, String ip) throws Exception;

    public Info unlock(UUID accountId, String ip, UUID renewToken) throws Exception;

}
