/*
 * Martin Alexander Thomsen den 30 December 2024
 */
package com.maikenwinterberg.account.datagram;

import com.maikenwinterberg.account.database.Info;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class CheckSession {

    public static void main(String arg[]) throws Exception {
        String sessionId = (arg.length > 0 ? arg[0] : null);
        if (sessionId == null) {
            //test session
            sessionId = "76e849dd-5715-4c63-a64b-fa4d170cc3a2";
        }
        Info info = SessionClientFactory.getSessionClient().getAccountInfo(sessionId);
        System.out.println(info);
    }
}
