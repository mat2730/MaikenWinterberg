/*
 * Martin Alexander Thomsen den 30 December 2024
 */
package com.maikenwinterberg.account.database;

import com.maikenwinterberg.account.http.StartHttps;
import com.maikenwinterberg.config.Config;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.UUID;
import java.util.WeakHashMap;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileAccountImpl implements IAccount {

    public static String SESSION_HOST = Config.getValue(Config.Group.accountConfig, Config.Property.account, "accountHost");
    public static final DateTimeFormatter ZDT_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM/dd HH:mm:ss");
    private static IAccount instance;
    private static final File DB_DIRECTORY;
    private static final Map<String, Info> SESSION = new WeakHashMap();

    static {
        String directory = Config.getValue(Config.Group.accountConfig, Config.Property.account, "dbLocation");
        if (directory == null) {
            directory = "db";
        }
        DB_DIRECTORY = new File(directory);
    }

    public static IAccount getInstance() {
        if (instance == null) {
            instance = new FileAccountImpl();
        }
        return instance;
    }

    private String getDirectoryName(String tableName, String name) {
        StringBuilder buf = new StringBuilder();
        for (int i = 0; i < name.length(); i++) {
            if (name.charAt(i) == '.') {
                buf.append("_");
            } else {
                buf.append(name.charAt(i));
            }
        }
        name = buf.toString();
        buf = new StringBuilder();
        buf.append(DB_DIRECTORY);
        buf.append("/").append(tableName);
        int index = 0;
        while (true) {
            String part;
            try {
                part = name.substring(index, index + 3);
                buf.append("/").append(part);
            } catch (Exception ex) {
                part = name.substring(index);
                if (!part.trim().isEmpty()) {
                    buf.append("/").append(part);
                }
                break;
            }
            index += 3;
        }
        return buf.toString();
    }

    private boolean deleteFileAndDirectory(File file) {
        file.delete();
        File parent = file.getParentFile();
        while (parent != null) {
            if (parent.getName().equals(DB_DIRECTORY.getName())) {
                break;
            }
            parent.delete();
            parent = parent.getParentFile();
        }
        return true;
    }

    private void createAccount(boolean deleteIfExists, String privateKey, String accountName, UUID accountId, String ip, String creationTime) throws Exception {
        updateAccount(deleteIfExists,privateKey,accountName,accountId);
        File f = new File(getDirectoryName("InfoByAccountName", accountName) + "/accountcreation.txt");
        if (f.exists()) {
            if (deleteIfExists) {
                f.delete();
            } else {
                throw new IllegalStateException("Account allready exists " + accountName);
            }
        }
        f.getParentFile().mkdirs();
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write((ip + "|" + creationTime).getBytes(StartHttps.ENCODING));
            fos.flush();
        }
    }
    private void updateAccount(boolean deleteIfExists, String privateKey, String accountName, UUID accountId) throws Exception {
        File f = new File(getDirectoryName("InfoByAccountName", accountName) + "/account.txt");
        if (f.exists()) {
            if (deleteIfExists) {
                f.delete();
            } else {
                throw new IllegalStateException("Account allready exists " + accountName);
            }
        }
        f.getParentFile().mkdirs();
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write((accountId + "|" + privateKey).getBytes(StartHttps.ENCODING));
            fos.flush();
        }
    }

    private void createAccountInfo(boolean deleteIfExists, UUID accountId, UUID renewToken, String ip, String accountName, Info.Status status, String sessionId) throws Exception {
        File f = new File(getDirectoryName("InfoByAccountId", accountId.toString()) + "/accountInfo.txt");
        createInfo(f, deleteIfExists, renewToken, ip, accountName, status, sessionId);
    }

    private void createInfo(File f, boolean deleteIfExists, UUID renewToken, String ip, String accountName, Info.Status status, String sessionId) throws Exception {
        if (f.exists()) {
            if (deleteIfExists) {
                f.delete();
            } else {
                throw new IllegalStateException("Account allready exists " + accountName);
            }
        }
        f.getParentFile().mkdirs();
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write((ip + "|" + ZDT_FORMATTER.format(ZonedDateTime.now()) + "|" + status + "|" + accountName + "|" + sessionId + "|" + (renewToken == null ? "null" : renewToken.toString())).getBytes(StartHttps.ENCODING));
            fos.flush();
        }
    }

    private void updateSession(String sessionId, Info info) throws Exception {
        File f = new File(getDirectoryName("InfoBySessionId", sessionId) + "/sessionInfo.txt");
        createInfo(f, true, null, info.getCurrentIP(), info.getAccountName(), info.getStatus(), sessionId);
        SESSION.put(sessionId, info);
    }

    private UUID createRenewToken(UUID accountId) throws Exception {
        File f = new File(getDirectoryName("InfoByAccountId", accountId.toString()) + "/renewToken.txt");
        f.getParentFile().mkdirs();
        UUID newToken = UUID.randomUUID();
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write(newToken.toString().getBytes(StartHttps.ENCODING));
            fos.flush();
        }
        File f2 = new File(getDirectoryName("RenewTokens", newToken.toString()) + "/accountId.txt");
        f2.getParentFile().mkdirs();
        try (FileOutputStream fos = new FileOutputStream(f2)) {
            fos.write(accountId.toString().getBytes(StartHttps.ENCODING));
            fos.flush();
        }
        return newToken;
    }

    @Override
    public Info createAccount(String privateKey, String accountName, String ip) throws Exception {
        //1 create accountName.txt
        File f = new File(getDirectoryName("InfoByPrivateKey", privateKey) + "/accountName.txt");
        if (f.exists()) {
            throw new IllegalStateException("Account allready exists " + accountName);
        }
        f.getParentFile().mkdirs();
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write((accountName + "|" + ip).getBytes(StartHttps.ENCODING));
            fos.flush();
        }
        UUID accountId = UUID.randomUUID();
        createAccount(false, privateKey, accountName, accountId, ip, ZDT_FORMATTER.format(ZonedDateTime.now()));
        //String sessionId = UUID.randomUUID().toString() + "@" + SESSION_HOST;
        UUID renewToken = createRenewToken(accountId);
        createAccountInfo(false, accountId, renewToken, ip, accountName, Info.Status.locked, null);
        return new Info(accountId, accountName, ip, Info.Status.locked, null, renewToken);
    }

    @Override
    public Info renewAccount(String privateKey, String ip) throws Exception {
        File f = new File(getDirectoryName("InfoByPrivateKey", privateKey) + "/accountName.txt");
        if (f.exists()) {
            try (FileInputStream fis = new FileInputStream(f)) {
                byte d[] = new byte[fis.available()];
                fis.read(d);
                StringTokenizer tok1 = new StringTokenizer(new String(d, StartHttps.ENCODING), "|");
                String accountName = tok1.nextToken();
                f = new File(getDirectoryName("InfoByAccountName", accountName) + "/account.txt");
                if (!f.exists()) {
                    throw new IllegalArgumentException("Account does not exists");
                }
                try (FileInputStream fis2 = new FileInputStream(f)) {
                    byte d2[] = new byte[fis2.available()];
                    fis2.read(d2);
                    String account = new String(d2, StartHttps.ENCODING);
                    StringTokenizer tok = new StringTokenizer(account, "|");
                    String accountId = tok.nextToken();
                    String privateKeyInInfo = tok.nextToken();
                    //String oldIp = tok.nextToken();
                    //String creationTime = tok.nextToken();
                    if (!privateKeyInInfo.equals(privateKey)) {
                        throw new IllegalArgumentException("Account does not exists");
                    }
                    lock(UUID.fromString(accountId));
                    deleteFileAndDirectory(new File(getDirectoryName("InfoByAccountId", accountId) + "/accountInfo.txt"));
                    UUID newAccountId = UUID.randomUUID();
                    //String sessionId = UUID.randomUUID() + "@" + SESSION_HOST;
                    updateAccount(true, privateKey, accountName, newAccountId);
                    createAccountInfo(true, newAccountId, UUID.randomUUID(), ip, accountName, Info.Status.locked, null);
                    //Info i = unlock(newAccountId, ip);
                    return new Info(newAccountId, accountName, ip, Info.Status.locked, null, createRenewToken(UUID.fromString(accountId)));
                }
            }
        } else {
            throw new IllegalArgumentException("Account does not exists");
        }
    }

    @Override
    public Info enterAccount(String privateKey, String ip) throws Exception {
        File f = new File(getDirectoryName("InfoByPrivateKey", privateKey) + "/accountName.txt");
        if (f.exists()) {
            try (FileInputStream fis = new FileInputStream(f)) {
                byte d[] = new byte[fis.available()];
                fis.read(d);
                StringTokenizer tok1 = new StringTokenizer(new String(d, StartHttps.ENCODING), "|");
                String accountName = tok1.nextToken();
                f = new File(getDirectoryName("InfoByAccountName", accountName) + "/account.txt");
                if (!f.exists()) {
                    throw new IllegalArgumentException("Account does not exists");
                }
                try (FileInputStream fis2 = new FileInputStream(f)) {
                    byte d2[] = new byte[fis2.available()];
                    fis2.read(d2);
                    String account = new String(d2, StartHttps.ENCODING);
                    StringTokenizer tok = new StringTokenizer(account, "|");
                    String accountId = tok.nextToken();
                    String privateKeyInInFile = tok.nextToken();
                    if (!privateKeyInInFile.equals(privateKey)) {
                        throw new IllegalArgumentException("Account does not exists");
                    }
                    File f3 = new File(getDirectoryName("InfoByAccountId", accountId) + "/accountInfo.txt");
                    try (FileInputStream fis3 = new FileInputStream(f3)) {
                        byte d3[] = new byte[fis3.available()];
                        fis3.read(d3);
                        String accountInfo = new String(d3, StartHttps.ENCODING);
                        StringTokenizer tok3 = new StringTokenizer(accountInfo, "|");
                        String ipInFile = tok3.nextToken();
                        String tid = tok3.nextToken();
                        String status = tok3.nextToken();
                        String accountNameInFile = tok3.nextToken();
                        String sessionId = tok3.nextToken();
                        String renewToken = tok3.nextToken();
                        if (!accountNameInFile.equals(accountName)) {
                            throw new IllegalArgumentException("Account does not exists");
                        }
                        return new Info(UUID.fromString(accountId), accountName, ip, Info.Status.valueOf(status), sessionId, UUID.fromString(renewToken));
                    }
                }
            }
        } else {
            throw new IllegalArgumentException("Account does not exists");
        }
    }

    @Override
    public Info getSessionInfo(String sessionId) throws Exception {
        Info i = SESSION.get(sessionId);
        if (i == null) {
            File f2 = new File(getDirectoryName("InfoBySessionId", sessionId) + "/sessionInfo.txt");
            try (FileInputStream fis2 = new FileInputStream(f2)) {
                byte d2[] = new byte[fis2.available()];
                fis2.read(d2);
                String publicInfo = new String(d2, StartHttps.ENCODING);
                StringTokenizer tok2 = new StringTokenizer(publicInfo, "|");
                String ip = tok2.nextToken();
                String tid = tok2.nextToken();
                String status = tok2.nextToken();
                String accountNameInFile = tok2.nextToken();
                i = new Info(null, accountNameInFile, ip, Info.Status.valueOf(status), sessionId, null);
                SESSION.put(sessionId, i);
            } catch (Exception ex) {
                return null;
            }
        }
        return i;
    }

    @Override
    public Info getAccountInfo(UUID accountId) throws Exception {
        try {
            File f2 = new File(getDirectoryName("InfoByAccountId", accountId.toString()) + "/accountInfo.txt");
            try (FileInputStream fis2 = new FileInputStream(f2)) {
                byte d2[] = new byte[fis2.available()];
                fis2.read(d2);
                String publicInfo = new String(d2, StartHttps.ENCODING);
                StringTokenizer tok2 = new StringTokenizer(publicInfo, "|");
                String ip = tok2.nextToken();
                String tid = tok2.nextToken();
                String status = tok2.nextToken();
                String accountName = tok2.nextToken();
                String sessionId = tok2.nextToken();
                String renewToken = tok2.nextToken();
                return new Info(accountId, accountName, ip, Info.Status.valueOf(status), sessionId, UUID.fromString(renewToken));
            }
        } catch (Exception ex) {

        }
        return null;
    }

    @Override
    public Info lock(UUID accountId) throws Exception {
        File f2 = new File(getDirectoryName("InfoByAccountId", accountId.toString()) + "/accountInfo.txt");
        try (FileInputStream fis2 = new FileInputStream(f2)) {
            byte d2[] = new byte[fis2.available()];
            fis2.read(d2);
            String publicInfo = new String(d2, StartHttps.ENCODING);
            StringTokenizer tok2 = new StringTokenizer(publicInfo, "|");
            String ipInFile = tok2.nextToken();
            String tid = tok2.nextToken();
            String status = tok2.nextToken();
            String accountName = tok2.nextToken();
            String sessionId = tok2.nextToken();
            String renewToken = tok2.nextToken();
            createAccountInfo(true, accountId, UUID.fromString(renewToken), ipInFile, accountName, Info.Status.locked, null);
            if (sessionId != null && !sessionId.equals("null")) {
                deleteFileAndDirectory(new File(getDirectoryName("InfoBySessionId", sessionId) + "/sessionInfo.txt"));
                SESSION.remove(sessionId);
            }
            return new Info(null, accountName, ipInFile, Info.Status.locked, null, null);
        }
    }

    @Override
    public Info unlock(UUID accountId, String ip) throws Exception {
        return unlock(accountId, ip, null);
    }

    @Override
    public Info unlock(UUID accountId, String ip, UUID renewToken) throws Exception {
        lock(accountId);
        File f2 = new File(getDirectoryName("InfoByAccountId", accountId.toString()) + "/accountInfo.txt");
        try (FileInputStream fis2 = new FileInputStream(f2)) {
            byte d2[] = new byte[fis2.available()];
            fis2.read(d2);
            String publicInfo = new String(d2, StartHttps.ENCODING);
            StringTokenizer tok2 = new StringTokenizer(publicInfo, "|");
            String installationIp = tok2.nextToken();
            String tid = tok2.nextToken();
            String status = tok2.nextToken();
            String accountName = tok2.nextToken();
            String currentSessionId = tok2.nextToken();//old session
            String renewTokenInFile = tok2.nextToken();
            String newSessionId = UUID.randomUUID().toString() + "@" + SESSION_HOST;;
            Info sessionInfo = getSessionInfo(currentSessionId);
            if (sessionInfo != null && !sessionInfo.getCurrentIP().equals(ip)) {
                //mismatch session ip changed
                if (renewToken != null && renewTokenInFile.equals(renewToken.toString())) {
                    //ignore
                } else {
                    throw new IllegalAccessException("Invalid ip " + ip);
                }
            }
            //unlock
            UUID renewTokenInFileUUID = UUID.fromString(renewTokenInFile);
            Info accountInfo = new Info(accountId, accountName, ip, Info.Status.unlocked, newSessionId, renewTokenInFileUUID);
            createAccountInfo(true, accountId, renewTokenInFileUUID, ip, accountName, Info.Status.unlocked, newSessionId);
            updateSession(newSessionId, accountInfo);
            return accountInfo;
        }
    }

    @Override
    public boolean renewSessionIp(UUID renewtoken, String newIp) throws Exception {
        File f2 = new File(getDirectoryName("RenewTokens", renewtoken.toString()) + "/accountId.txt");
        if (!f2.exists()) {
            return false;
        }
        try (FileInputStream ikkeFis = new FileInputStream(f2)) {
            byte[] d = new byte[ikkeFis.available()];
            ikkeFis.read(d);
            String accountId = new String(d, StartHttps.ENCODING).trim();
            if (accountId.isEmpty()) {
                throw new IllegalArgumentException("AccountId cannot be found from token " + renewtoken);
            }
            Info accountInfo = getAccountInfo(UUID.fromString(accountId));
            if (!accountInfo.getRenewToken().equals(renewtoken)) {
                throw new IllegalStateException("invalid renew token" + renewtoken);
            }
            accountInfo.setCurrentIP(newIp);
            updateSession(accountInfo.getSessionId(), accountInfo);
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    @Override
    public Info getAccountInfo(String accountName) throws Exception {
        File f = new File(getDirectoryName("InfoByAccountName", accountName) + "/accountcreation.txt");
        System.out.println("file: " + f.getAbsolutePath());
        if (f.exists()) {
            try (FileInputStream fis = new FileInputStream(f)) {
                byte d[] = new byte[fis.available()];
                String accountInfo = new String(d, StartHttps.ENCODING).trim();
                System.out.println("accountInfo: " + accountInfo);
                StringTokenizer tok = new StringTokenizer(accountInfo);
                //this is one of the tricks of Java - Martin Alexander Thomsen
                String originalip = tok.nextToken();
                String creationTime = tok.nextToken();
                return new Info(null, accountName, null, null, null, null, creationTime, originalip);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public String getSessionIp(String accountName) throws Exception {
        File f = new File(getDirectoryName("InfoByAccountName", accountName) + "/account.txt");
        if (!f.exists()) {
            throw new IllegalArgumentException("Account does not exists");
        }
        try (FileInputStream fis2 = new FileInputStream(f)) {
            byte d2[] = new byte[fis2.available()];
            fis2.read(d2);
            String account = new String(d2, StartHttps.ENCODING);
            StringTokenizer tok = new StringTokenizer(account, "|");
            String accountId = tok.nextToken();
            Info accountInfo = getAccountInfo(UUID.fromString(accountId));
            Info sessionInfo = getSessionInfo(accountInfo.getSessionId());
            return sessionInfo.getCurrentIP();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
}
