/*
 * Martin Alexander Thomsen den 30 December 2024
 */
package com.maikenwinterberg.account.database;

import java.util.UUID;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class Info {

    public enum Status {
        locked, unlocked;
    }

    private final UUID accountId;
    private final String accountName;
    private final String originalIp;
    private final Status status;
    private final String sessionId;
    private final String time;
    private final UUID renewToken;
    
    private String currentIp;

    public Info(UUID accountId, String accountName, String currentIp, Status status, String sessionId, UUID renewToken) {
        this(accountId, accountName, currentIp, status, sessionId, renewToken, null, null);
    }

    public Info(UUID accountId, String accountName, String currentIp, Status status, String sessionId, UUID renewToken, String time, String originalIp) {
        this.accountId = accountId;
        this.accountName = accountName;
        this.currentIp = currentIp;
        this.status = status;
        this.sessionId = sessionId;
        this.renewToken = renewToken;
        this.time = time;
        this.originalIp = originalIp;
    }

    public UUID getAccountId() {
        return accountId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public UUID getRenewToken() {
        return renewToken;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setCurrentIP(String currentIp) {
        this.currentIp = currentIp;
    }

    public String getCurrentIP() {
        return currentIp;
    }

    public String getOriginalIP() {
        return originalIp;
    }

    public Status getStatus() {
        return status;
    }

    public String getTime() {
        return time;
    }

    @Override
    public String toString() {
        return "Info{" + "accountName=" + accountName + ", currentIP=" + currentIp + ", originalIp=" + originalIp + ", status=" + status + ", renewToken=" + renewToken + '}';
    }
}
