/*
 * Martin Alexander Thomsen den 30 December 2024
 */
package com.maikenwinterberg.account.http;

import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IConverte {

    public enum OutputType {
        HTML, JSON
    };

    public final static String TRANSACTION_OK = "Success";
    public final static String UNKNOWN_ERROR = "Error";

    public String converte(String headline, Map<String, String> attributes) throws Exception;

    public String converte(String headline, String link, String errorMessage, Map<String, String> attributes, Throwable throwable) throws Exception;

    public static String converte(OutputType type, String headline, Map<String, String> attributes) throws Exception{
        if (type == IConverte.OutputType.JSON) {
            return new JSonConveter().converte(headline, attributes);
        } else {
            return new HtmlConveter().converte(headline, attributes);
        }
    }
    public static String converte(OutputType type, String headline, String link, String errorMessage, Map<String, String> attributes, Throwable throwable) throws Exception{
        if (type == IConverte.OutputType.JSON) {
            return new JSonConveter().converte(headline, link, errorMessage, attributes, throwable);
        } else {
            return new HtmlConveter().converte(headline, link, errorMessage, attributes, throwable);
        }
    }
}
