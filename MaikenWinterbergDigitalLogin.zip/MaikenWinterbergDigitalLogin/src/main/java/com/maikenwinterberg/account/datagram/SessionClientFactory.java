/*
 * Martin Alexander Thomsen den 5 Januar 2024
 */
package com.maikenwinterberg.account.datagram;

import com.maikenwinterberg.config.Config;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class SessionClientFactory {
    public static ISessionClient getSessionClient() {
        String config = Config.getValue(Config.Group.accountConfig, Config.Property.account, "ISessionClientImpl");
        if (config == null || config.trim().isEmpty()) {
            return new MethodCallSessionClient();
        }
        try {
            ISessionClient c = (ISessionClient) Class.forName(config).newInstance();
            return c;
        } catch (Exception ex) {

        }
        return new GetAccountNameBySessionIdClient();
    }
}