/*
 * Martin Alexander Thomsen den 28 December 2024
 */
package com.maikenwinterberg.account.http;

import com.maikenwinterberg.account.database.FileAccountImpl;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.ZonedDateTime;
import java.util.Iterator;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class JSonConveter implements IConverte {

    private static JSonConveter CONVERTER = new JSonConveter();

    public static String converteJSON(String headline, Map<String, String> attributes) {
        return CONVERTER.converte(headline, attributes);
    }

    public static String converteJSON(String headline, String link, String errorMessage, Map<String, String> attributes, Throwable throwable) {
        return CONVERTER.converte(headline, link, errorMessage, attributes, throwable);
    }

    @Override
    public String converte(String headline, Map<String, String> attributes) {
        StringBuilder builder = new StringBuilder();
        builder.append("{\"Response\": {");
        builder.append("\n\t\"CurrentDate\": \"").append(FileAccountImpl.ZDT_FORMATTER.format(ZonedDateTime.now())).append("\"");
        for (Iterator i = attributes.keySet().iterator(); i.hasNext();) {
            String key = (String) i.next();
            String value = (String) attributes.get(key);
            builder.append(",\n\t\"").append(key).append("\": \"").append(value).append("\"");
        }
        builder.append(",\n\t\"ResponseType\": \"").append(IConverte.TRANSACTION_OK).append("\"");
        builder.append("\n}}");
        return builder.toString();
    }

    @Override
    public String converte(String headline, String link, String errorMessage, Map<String, String> attributes, Throwable throwable) {
        StringBuilder builder = new StringBuilder();
        builder.append("{\"Response\": {");
        builder.append("\n\t\"CurrentDate\": \"").append(FileAccountImpl.ZDT_FORMATTER.format(ZonedDateTime.now())).append("\"");;
        for (Iterator i = attributes.keySet().iterator(); i.hasNext();) {
            String key = (String) i.next();
            Object value = (Object) attributes.get(key);
            if (value != null) {
                builder.append(",\n\t\"").append(key).append("\": \"").append(value.toString()).append("\"");
            }
        }
        if (throwable == null && errorMessage == null) {
            builder.append(",\n\t\"ResponseType\": \"").append(IConverte.TRANSACTION_OK).append("\"");
        } else {
            builder.append(",\n\t\"ResponseType\": \"").append(IConverte.UNKNOWN_ERROR).append("\"");
        }
        if (headline != null || errorMessage != null) {
            builder.append("\n\t\"Text\": \"").append((headline != null ? headline : errorMessage)).append("\"");
        }
        if (link != null) {
            builder.append("\n\t\"Link\": \"").append(link).append("\"");
        }
        if (throwable != null) {
            StringWriter stringWriter = new StringWriter();
            PrintWriter w = new PrintWriter(stringWriter);
            throwable.printStackTrace(w);
            builder.append("\n\t\"Stacktrace\": \"").append(stringWriter.toString()).append("\"");
            /*
            String base64StackTrace = null;
            try {
                base64StackTrace = new String(Base64.encodeBase64(stringWriter.getBuffer().toString().getBytes(StartHttps.ENCODING)), StartHttps.ENCODING);
            } catch (Exception ex) {
            }
            if (base64StackTrace != null) {
                builder.append("\n\t\"Stacktrace\": \"").append(base64StackTrace).append("\"");
            }*/
        }
        builder.append("\n}}");
        return builder.toString();
    }
}
