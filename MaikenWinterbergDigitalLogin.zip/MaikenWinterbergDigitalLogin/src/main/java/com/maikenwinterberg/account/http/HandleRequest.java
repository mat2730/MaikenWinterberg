/*
 * Martin Alexander Thomsen den 30 December 2024
 */
package com.maikenwinterberg.account.http;

import com.maikenwinterberg.account.database.FileAccountImpl;
import com.maikenwinterberg.account.database.Info;
import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.domainname.DomainHandler;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import org.veryquick.embweb.Response;
import org.veryquick.embweb.handlers.MimeTypeParser;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class HandleRequest implements IHandleRequest {

    public static IHandleRequest newInstance() {
        return new HandleRequest();
    }

    @Override
    public Response handleRequest(String ip, String hostName, String url, Map<String, String> parameters) {
        Response response = new Response();
        try {
            if (url.contains("/login")) {
                String title = parameters.get("GET_title");
                if (title == null) {
                    title = "Maiken Winterberg Digital login";
                }
                String link = parameters.get("GET_link");
                if (link == null) {
                    link = "/index.html";
                }
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl == null) {
                    redirecturl = "/bankven.html";
                }
                String errormessage = parameters.get("GET_errormessage");
                if (errormessage == null) {
                    errormessage = "";
                }
                Map a = new TreeMap();
                String form = "<form action='/html/create'><input type='hidden' name='title' value = '" + title + "'></input><input type='hidden' name='redirecturl' value = '" + redirecturl + "'></input><input type='hidden' name='link' value = '" + link + "'></input><label for='Account_name'>Account name:</label><br/><input id='Account_name' name='Account_name'/><br/><label for='Secret_key'>Secret key:</label><br/><input if = 'Secret_key' name='Secret_key'/> <input type='submit' value='Submit'></form>";
                a.put("Create account", form);
                form = "<form action='/html/renew'><input type='hidden' name='title' value = '" + title + "'></input><input type='hidden' name='redirecturl' value = '" + redirecturl + "'></input><input type='hidden' name='link' value = '" + link + "'></input><label for='Account_name'>Account name:</label><br/><input id='Account_name' name='Account_name'/><br/><label for='Secret_key'>Secret key:</label><br/><input if = 'Secret_key' name='Secret_key'/> <input type='submit' value='Submit'></form>";
                //String form2 = "<form action='/html/renew'><input type='hidden' name='redirecturl' value = '" + redirecturl + "'></input><input type='hidden' name='link' value = '" + link + "'></input><label for='Secret_key'>Secret_key:</label><br/><input if = 'Secret_key' name='Secret_key'/> <input type='submit' value='Submit'></form>";
                a.put("Renew account", form);
                form = "<form action='/html/enter'><input type='hidden' name='title' value = '" + title + "'></input><input type='hidden' name='redirecturl' value = '" + redirecturl + "'></input><input type='hidden' name='link' value = '" + link + "'></input><label for='Account_name'>Account name:</label><br/><input id='Account_name' name='Account_name'/><br/><label for='Secret_key'>Secret key:</label><br/><input if = 'Secret_key' name='Secret_key'/> <input type='submit' value='Submit'></form>";
                //String form3 = "<form action='/html/enter'><input type='hidden' name='redirecturl' value = '" + redirecturl + "'></input><input type='hidden' name='link' value = '" + link + "'></input><label for='Secret_key'>Secret_key:</label><br/><input if = 'Secret_key' name='Secret_key'/> <input type='submit' value='Submit'></form>";
                a.put("Enter account", form);
                response.addContent(IConverte.converte(IConverte.OutputType.HTML, title, link, errormessage, a, null));
                response.setOk();
                return response;
            } else if (url.contains("/create")) {
                String redirecturl = parameters.get("GET_redirecturl");
                String link = parameters.get("GET_link");
                if (link == null) {
                    link = "/bankven.html";
                }
                String title = parameters.get("GET_title");
                if (title == null) {
                    title = "Maiken Winterberg Digital login";
                }
                String accountName = "";
                try {
                    String secretKey = parameters.get("GET_Secret_key");
                    accountName = parameters.get("GET_Account_name");
                    if (secretKey == null || accountName == null || secretKey.trim().isEmpty() || accountName.trim().isEmpty()) {
                        throw new IllegalArgumentException("the fields cannot be empty");
                    }
                    boolean validDomainOrigin = false;
                    if (accountName.contains(".")) {
                        boolean validDomainName = false;
                        try {
                            String hostAddress = DomainHandler.getHostAddress(accountName);
                            if (hostAddress == null) {
                                throw new IllegalAccessException("domainname " + accountName + " is not found");
                            }
                            validDomainName = true;
                            if (!hostAddress.equals(ip)) {
                                throw new IllegalAccessException("ip " + ip + " is not approved for " + accountName);
                            }
                            validDomainOrigin = true;
                        } catch (Throwable ex) {
                        }
                        if (!validDomainName) {
                            throw new IllegalAccessException("If you insert a: '.' in the accountname it have to be a valid domainname");
                        }
                        if (validDomainName && !validDomainOrigin) {
                            throw new IllegalAccessException("ip " + ip + " is not approved for " + accountName);
                        }
                    }
                    if (accountName.contains("|") || accountName.contains("/")) {
                        throw new IllegalAccessException("Invalid account name " + accountName);
                    }
                    if (secretKey.contains("|") || secretKey.contains("/")) {
                        throw new IllegalAccessException("Invalid secret key " + secretKey);
                    }
                    String accountUrl = Config.getValue(Config.Group.accountConfig, Config.Property.account, "accountHost");
                    //accountName = accountName.replaceAll("/", "_").toLowerCase().trim();
                    accountName = accountName + "@" + accountUrl;
                    secretKey = accountName + "_" + secretKey;
                    Info info = FileAccountImpl.getInstance().createAccount(secretKey, accountName, ip);
                    if (url.contains("/json/")) {
                        Map attributes = new TreeMap();
                        attributes.put("AccountName", accountName);
                        Info accountInfo = FileAccountImpl.getInstance().getAccountInfo(accountName);
                        if (accountInfo != null) {
                            attributes.put("OriginalIP", accountInfo.getOriginalIP());
                            attributes.put("CreationTime", accountInfo.getTime());
                        }
                        attributes.put("AccountId", info.getAccountId().toString());
                        attributes.put("RenewToken", info.getRenewToken());
                        attributes.put("Status", info.getStatus().toString());
                        response.addContent(JSonConveter.converteJSON("The account is created", null, null, attributes, null));
                        response.setContentType(MimeTypeParser.getInstance().getType("json"));
                        response.setOk();
                    } else {
                        String renewToken = "";
                        if (!validDomainOrigin) {
                            renewToken = "&renewtoken=" + info.getRenewToken().toString();
                        }
                        response.setRedirect("/html/menu?redirecturl=" + redirecturl + "&title=" + title + "&link=" + link + "&accountid=" + info.getAccountId().toString() + renewToken);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    if (url.contains("/json/")) {
                        Map attributes = new TreeMap();
                        attributes.put("AccountName", accountName);
                        Info accountInfo = FileAccountImpl.getInstance().getAccountInfo(accountName);
                        if (accountInfo != null) {
                            attributes.put("OriginalIP", accountInfo.getOriginalIP());
                            attributes.put("CreationTime", accountInfo.getTime());
                        }
                        response.addContent(JSonConveter.converteJSON(null, null, "The account is not created", attributes, ex));
                        response.setContentType(MimeTypeParser.getInstance().getType("json"));
                        response.setOk();
                    } else {
                        response.setRedirect("/html/login?redirecturl=" + redirecturl + "&title=" + title + "&link=" + link + "&errormessage=" + ex.getMessage());
                    }
                }
                return response;
            } else if (url.contains("/renew")) {
                String redirecturl = parameters.get("GET_redirecturl");
                String link = parameters.get("GET_link");
                if (link == null) {
                    link = "/bankven.html";
                }
                String title = parameters.get("GET_title");
                if (title == null) {
                    title = "Maiken Winterberg Digital login";
                }
                String accountName = "";
                try {
                    String secretKey = parameters.get("GET_Secret_key");
                    accountName = parameters.get("GET_Account_name");
                    if (secretKey == null || accountName == null || secretKey.trim().isEmpty() || accountName.trim().isEmpty()) {
                        throw new IllegalArgumentException("the fields cannot be empty");
                    }
                    boolean validDomainOrigin = false;
                    if (accountName.contains(".")) {
                        boolean validDomainName = false;
                        try {
                            String hostAddress = DomainHandler.getHostAddress(accountName);
                            if (hostAddress == null) {
                                throw new IllegalAccessException("domainname " + accountName + " is not found");
                            }
                            validDomainName = true;
                            if (!hostAddress.equals(ip)) {
                                throw new IllegalAccessException("ip " + ip + " is not approved for " + accountName);
                            }
                            validDomainOrigin = true;
                        } catch (Throwable ex) {
                        }
                        if (!validDomainName) {
                            throw new IllegalAccessException("If you insert a: '.' in the accountname it have to be a valid domainname");
                        }
                        if (validDomainName && !validDomainOrigin) {
                            throw new IllegalAccessException("ip " + ip + " is not approved for " + accountName);
                        }
                    }
                    String accountUrl = Config.getValue(Config.Group.accountConfig, Config.Property.account, "accountHost");
                    accountName = accountName + "@" + accountUrl;
                    accountName = accountName.replaceAll("/", "_");
                    secretKey = accountName + "_" + secretKey;
                    Info info = null;
                    try {
                        info = FileAccountImpl.getInstance().renewAccount(secretKey, ip);
                    } catch (Throwable ex) {
                        ex.printStackTrace();
                    }
                    if (info == null || info.getAccountId() == null) {
                        throw new IllegalArgumentException("The secret key is invalid");
                    }
                    if (url.contains("/json/")) {
                        Map attributes = new TreeMap();
                        attributes.put("AccountName", accountName);
                        Info accountInfo = FileAccountImpl.getInstance().getAccountInfo(accountName);
                        if (accountInfo != null) {
                            attributes.put("OriginalIP", accountInfo.getOriginalIP());
                            attributes.put("CreationTime", accountInfo.getTime());
                        }
                        attributes.put("AccountId", info.getAccountId().toString());
                        attributes.put("RenewToken", info.getRenewToken());
                        attributes.put("Status", info.getStatus().toString());
                        response.addContent(JSonConveter.converteJSON("The account is renewed with a new Account id", null, null, attributes, null));
                        response.setContentType(MimeTypeParser.getInstance().getType("json"));
                        response.setOk();
                    } else {
                        String renewToken = "";
                        if (!validDomainOrigin) {
                            renewToken = "&renewtoken=" + info.getRenewToken().toString();
                        }
                        response.setRedirect("/html/menu?redirecturl=" + redirecturl + "&title=" + title + "&link=" + link + "&accountid=" + info.getAccountId().toString() + renewToken);
                    }
                } catch (Exception ex) {
                    if (url.contains("/json/")) {
                        Map attributes = new TreeMap();
                        attributes.put("AccountName", accountName);
                        Info accountInfo = FileAccountImpl.getInstance().getAccountInfo(accountName);
                        if (accountInfo != null) {
                            attributes.put("OriginalIP", accountInfo.getOriginalIP());
                            attributes.put("CreationTime", accountInfo.getTime());
                        }
                        response.addContent(JSonConveter.converteJSON(null, null, "The account is not renewed", attributes, ex));
                        response.setContentType(MimeTypeParser.getInstance().getType("json"));
                        response.setOk();
                    } else {
                        response.setRedirect("/html/login?redirecturl=" + redirecturl + "&title=" + title + "&link=" + link + "&errormessage=" + ex.getMessage());
                    }
                }
            } else if (url.contains("/enter")) {
                String redirecturl = parameters.get("GET_redirecturl");
                String link = parameters.get("GET_link");
                if (link == null) {
                    link = "/bankven.html";
                }
                String title = parameters.get("GET_title");
                if (title == null) {
                    title = "Maiken Winterberg Digital login";
                }
                String accountName = "";
                try {
                    boolean validDomainOrigin = false;
                    String secretKey = parameters.get("GET_Secret_key");
                    accountName = parameters.get("GET_Account_name");
                    if (secretKey == null || accountName == null || secretKey.trim().isEmpty() || accountName.trim().isEmpty()) {
                        throw new IllegalArgumentException("the fields cannot be empty");
                    }
                    if (accountName.contains(".")) {
                        boolean validDomainName = false;
                        try {
                            String hostAddress = DomainHandler.getHostAddress(accountName);
                            if (hostAddress == null) {
                                throw new IllegalAccessException("domainname " + accountName + " is not found");
                            }
                            validDomainName = true;
                            if (!hostAddress.equals(ip)) {
                                throw new IllegalAccessException("ip " + ip + " is not approved for " + accountName);
                            }
                            validDomainOrigin = true;
                        } catch (Throwable ex) {
                        }
                        if (!validDomainName) {
                            throw new IllegalAccessException("If you insert a: '.' in the accountname it have to be a valid domainname");
                        }
                        if (validDomainName && !validDomainOrigin) {
                            throw new IllegalAccessException("ip " + ip + " is not approved for " + accountName);
                        }
                    }
                    String accountUrl = Config.getValue(Config.Group.accountConfig, Config.Property.account, "accountHost");
                    accountName = accountName + "@" + accountUrl;
                    accountName = accountName.replaceAll("/", "_");
                    secretKey = accountName + "_" + secretKey;
                    Info info = FileAccountImpl.getInstance().enterAccount(secretKey, ip);
                    if (url.contains("/json/")) {
                        Map attributes = new TreeMap();
                        attributes.put("AccountName", accountName);
                        Info accountInfo = FileAccountImpl.getInstance().getAccountInfo(accountName);
                        if (accountInfo != null) {
                            attributes.put("OriginalIP", accountInfo.getOriginalIP());
                            attributes.put("CreationTime", accountInfo.getTime());
                        }
                        attributes.put("AccountId", info.getAccountId().toString());
                        attributes.put("RenewToken", info.getRenewToken());
                        attributes.put("SessionId", info.getSessionId());
                        attributes.put("Status", info.getStatus().toString());
                        response.addContent(JSonConveter.converteJSON("Access to the account is granted", null, null, attributes, null));
                        response.setContentType(MimeTypeParser.getInstance().getType("json"));
                        response.setOk();
                    } else {
                        String renewToken = "";
                        if (!validDomainOrigin) {
                            renewToken = "&renewtoken=" + info.getRenewToken().toString();
                        }
                        response.setRedirect("/html/menu?redirecturl=" + redirecturl + "&title=" + title + "&link=" + link + "&accountid=" + info.getAccountId().toString() + renewToken);
                    }
                } catch (Exception ex) {
                    if (url.contains("/json/")) {
                        Map attributes = new TreeMap();
                        attributes.put("AccountName", accountName);
                        Info accountInfo = FileAccountImpl.getInstance().getAccountInfo(accountName);
                        if (accountInfo != null) {
                            attributes.put("OriginalIP", accountInfo.getOriginalIP());
                            attributes.put("CreationTime", accountInfo.getTime());
                        }
                        response.addContent(JSonConveter.converteJSON(null, null, "Access to the account is denied", attributes, ex));
                        response.setContentType(MimeTypeParser.getInstance().getType("json"));
                        response.setOk();
                    } else {
                        response.setRedirect("/html/login?redirecturl=" + redirecturl + "&title=" + title + "&link=" + link + "&errormessage=" + ex.getMessage());
                    }
                }
            } else if (url.contains("/menu")) {
                //request: UUID og redirectURL
                String redirecturl = parameters.get("GET_redirecturl");
                String errormessage = parameters.get("GET_errormessage");
                String link = parameters.get("GET_link");
                if (link == null) {
                    link = "/bankven.html";
                }
                String title = parameters.get("GET_title");
                if (title == null) {
                    title = "Maiken Winterberg Digital login";
                }
                String accountId = parameters.get("GET_accountid");
                String renewToken = parameters.get("GET_renewtoken");
                Info i = null;
                try {
                    i = FileAccountImpl.getInstance().getAccountInfo(UUID.fromString(accountId));
                    String msg = null;
                    if (i != null) {
                        Info.Status status = i.getStatus();
                        msg = "The account " + i.getAccountName() + " is " + status;
                    }else {
                        msg = errormessage;
                    }
                    //TODO show status
                    Map a = new TreeMap();
                    String form1 = "<form action='/html/lock'><input type='hidden' name='title' value = '" + title + "'></input><input type='hidden' name='redirecturl' value = '" + redirecturl + "'></input><input type='hidden' name='accountid' value = '" + accountId + "'></input><input type='hidden' name='renewtoken' value = '" + renewToken + "'><input type='hidden' name='link' value = '" + link + "'></input><input type='submit' id = 'lock' value='Lock account'></form>";
                    a.put("Lock account", form1);
                    String form2 = "<form action='/html/unlock'><input type='hidden' name='title' value = '" + title + "'></input><input type='hidden' name='redirecturl' value = '" + redirecturl + "'></input><input type='hidden' name='accountid' value = '" + accountId + "'></input><input type='hidden' name='renewtoken' value = '" + renewToken + "'></input><input type='hidden' name='link' value = '" + link + "'></input><input type='submit' id = 'unlock' value='Enter account'></form>";
                    a.put("Enter account", form2);
                    response.addContent(IConverte.converte(IConverte.OutputType.HTML, "Bookmark this page. Let it be your starting page for the application.", link, msg, a, null));
                } catch (Exception ex) {
                    if (url.contains("/json/") || errormessage != null) {
                        Map attributes = new TreeMap();
                        attributes.put("AccountId", accountId);
                        if (i != null) {
                            attributes.put("AccountName", i.getAccountName());
                            Info accountInfo = FileAccountImpl.getInstance().getAccountInfo(i.getAccountName());
                            if (accountInfo != null) {
                                attributes.put("OriginalIP", accountInfo.getOriginalIP());
                                attributes.put("CreationTime", accountInfo.getTime());
                            }
                            attributes.put("IP", i.getCurrentIP());
                            attributes.put("SessionId", i.getSessionId());
                            attributes.put("Status", i.getStatus().toString());
                        }
                        response.addContent(JSonConveter.converteJSON(null, link, "Access to the account is denied", attributes, ex));
                        response.setContentType(MimeTypeParser.getInstance().getType("json"));
                        response.setOk();
                    } else {
                        response.setRedirect("/html/menu?redirecturl=" + redirecturl + "&title=" + title + "&link=" + link + "&renewtoken=" + renewToken + "&errormessage=The accountId is invalid");
                    }
                }
                response.setOk();
                return response;
            } else if (url.contains("/lock")) {
                String redirecturl = parameters.get("GET_redirecturl");
                String accountId = parameters.get("GET_accountid");
                String renewToken = parameters.get("GET_renewtoken");
                if (renewToken == null || renewToken.isEmpty() || renewToken.equals("null")) {
                    renewToken = "";
                } else {
                    renewToken = "&renewtoken=" + renewToken;
                }
                String link = parameters.get("GET_link");
                String title = parameters.get("GET_title");
                if (title == null) {
                    title = "Maiken Winterberg Digital login";
                }
                Info i = null;
                Exception ex = null;
                try {
                    i = FileAccountImpl.getInstance().lock(UUID.fromString(accountId));
                } catch (Exception exe) {
                    ex = exe;
                }
                if (i != null) {
                    if (url.contains("/json/")) {
                        Map attributes = new TreeMap();
                        attributes.put("AccountId", accountId);
                        Info accountInfo = FileAccountImpl.getInstance().getAccountInfo(i.getAccountName());
                        if (accountInfo != null) {
                            attributes.put("OriginalIP", accountInfo.getOriginalIP());
                            attributes.put("CreationTime", accountInfo.getTime());
                        }
                        response.addContent(JSonConveter.converteJSON("Access to the account is now locked", null, null, attributes, null));
                        response.setContentType(MimeTypeParser.getInstance().getType("json"));
                        response.setOk();
                    } else {
                        response.setRedirect("/html/menu?redirecturl=" + redirecturl + "&title=" + title + "&accountid=" + accountId + "&link=" + link + renewToken);
                    }
                } else {
                    if (url.contains("/json/")) {
                        Map attributes = new TreeMap();
                        attributes.put("AccountId", accountId);
                        if (i != null) {
                            Info accountInfo = FileAccountImpl.getInstance().getAccountInfo(i.getAccountName());
                            if (accountInfo != null) {
                                attributes.put("OriginalIP", accountInfo.getOriginalIP());
                                attributes.put("CreationTime", accountInfo.getTime());
                            }
                        }
                        response.addContent(JSonConveter.converteJSON(null, null, "Access to the account is denied", attributes, ex));
                        response.setContentType(MimeTypeParser.getInstance().getType("json"));
                        response.setOk();
                    } else {
                        response.setRedirect("/html/menu?redirecturl=" + redirecturl + "&title=" + title + "&accountid=" + accountId + renewToken + "&link=" + link + "&renewtoken=" + renewToken);
                    }
                }
                return response;
            } else if (url.contains("/unlock")) {
                String redirecturl = parameters.get("GET_redirecturl");
                String accountId = parameters.get("GET_accountid");
                String renewToken = parameters.get("GET_renewtoken");
                String renewTokenParam = "";
                if (renewToken == null || renewToken.isEmpty() || renewToken.equals("null")) {
                    renewTokenParam = "";
                    renewToken = null;
                } else {
                    renewTokenParam = "&renewtoken=" + renewToken;
                }
                String link = parameters.get("GET_link");
                String title = parameters.get("GET_title");
                if (title == null) {
                    title = "Maiken Winterberg Digital login";
                }
                Info info = null;
                try {
                    info = FileAccountImpl.getInstance().unlock(UUID.fromString(accountId), ip, (renewToken == null? null : UUID.fromString(renewToken)));
                    String accountName = info.getAccountName();
                    int index = accountName.lastIndexOf("@");
                    String domainName = accountName.substring(0, index);
                    if (domainName.contains(".")) {
                        //must be a valid name
                        String hostAddress = DomainHandler.getHostAddress(domainName);
                        if (hostAddress == null) {
                            throw new IllegalAccessException("domainname " + domainName + " is not found");
                        }
                        if (!hostAddress.equals(ip)) {
                            throw new IllegalAccessException("ip " + ip + " is not approved for " + domainName);
                        }
                    }

                    boolean addSlash = false;
                    if (redirecturl != null) {
                        if (redirecturl.endsWith("/")) {
                            redirecturl = redirecturl.substring(0, redirecturl.length() - 1);
                            addSlash = true;
                        }
                        if (!redirecturl.contains("?")) {
                            redirecturl = redirecturl + "?";
                        } else {
                            redirecturl = redirecturl + "&";
                        }
                        redirecturl = redirecturl + "sessionid=" + info.getSessionId();
                        if (addSlash) {
                            redirecturl = redirecturl + "/";
                        }
                    }
                    if (url.contains("/json/")) {
                        Map attributes = new TreeMap();
                        attributes.put("AccountName", info.getAccountName());
                        Info accountInfo = FileAccountImpl.getInstance().getAccountInfo(info.getAccountName());
                        if (accountInfo != null) {
                            attributes.put("OriginalIP", accountInfo.getOriginalIP());
                            attributes.put("CreationTime", accountInfo.getTime());
                        }
                        attributes.put("IP", info.getCurrentIP());
                        attributes.put("AccountId", accountId);
                        attributes.put("SessionId", info.getSessionId());
                        response.addContent(JSonConveter.converteJSON("Access to the account is granted", redirecturl, null, attributes, null));
                        response.setContentType(MimeTypeParser.getInstance().getType("json"));
                        response.setOk();
                        return response;
                    } else if (redirecturl != null) {
                        response.setRedirect(redirecturl);
                        return response;
                    } else {
                        throw new IllegalStateException("redirecturl param is missing");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    if (url.contains("/json/")) {
                        Map attributes = new TreeMap();
                        if (info != null) {
                            attributes.put("AccountName", info.getAccountName());
                            Info accountInfo = FileAccountImpl.getInstance().getAccountInfo(info.getAccountName());
                            if (accountInfo != null) {
                                attributes.put("OriginalIP", accountInfo.getOriginalIP());
                                attributes.put("CreationTime", accountInfo.getTime());
                            }
                            attributes.put("IP", info.getCurrentIP());
                            attributes.put("AccountId", accountId);
                            attributes.put("SessionId", info.getSessionId());
                        }
                        response.addContent(JSonConveter.converteJSON(null, null, "Access to the account denied", attributes, ex));
                        response.setContentType(MimeTypeParser.getInstance().getType("json"));
                        response.setOk();
                        return response;
                    } else {
                        response.setRedirect("/html/menu?redirecturl=" + redirecturl + "&title=" + title + "&accountid=" + accountId + "&link=" + link + renewTokenParam + "&errormessage=" + ex.getMessage());
                        return response;
                    }
                }
            } else if (url.contains("/session")) {
                String sessionId = parameters.get("GET_sessionid");
                Info info = FileAccountImpl.getInstance().getSessionInfo(sessionId);
                Map attributes = new TreeMap();
                String okText = null;
                String errorText = null;
                if (info != null) {
                    attributes.put("AccountName", info.getAccountName());
                    attributes.put("SessionId", sessionId);
                    attributes.put("IP", info.getCurrentIP());
                    attributes.put("Account status", info.getStatus().toString());
                    okText = "Session found";
                } else {
                    attributes.put("SessionId", sessionId);
                    attributes.put("IP", ip);
                    attributes.put("Account status", Info.Status.locked.toString());
                    errorText = "Session not found";
                }
                if (url.contains("/json/")) {
                    response.addContent(JSonConveter.converteJSON(okText, null, errorText, attributes, null));
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setOk();
                    return response;
                } else {
                    response.addContent(IConverte.converte(IConverte.OutputType.HTML, "Account information", attributes));
                    response.setOk();
                    return response;
                }
            } else if (url.contains("/account")) {
                String accountname = parameters.get("GET_accountname");
                String currentIp = FileAccountImpl.getInstance().getSessionIp(accountname);
                Map attributes = new TreeMap();
                String okText = null;
                String errorText = null;
                if (currentIp != null) {
                    attributes.put("AccountName",accountname);
                    attributes.put("IP", currentIp);
                    okText = "ip found";
                } else {
                    attributes.put("AccountName", accountname);
                    errorText = "ip not found";
                }
                if (url.contains("/json/")) {
                    response.addContent(JSonConveter.converteJSON(okText, null, errorText, attributes, null));
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setOk();
                    return response;
                } else {
                    response.addContent(IConverte.converte(IConverte.OutputType.HTML, "Account information", attributes));
                    response.setOk();
                    return response;
                }
            } else if (url.contains("/iprenew")) {
                String renewToken = parameters.get("GET_renewtoken");
                boolean ok = FileAccountImpl.getInstance().renewSessionIp(UUID.fromString(renewToken), ip);
                Map attributes = new TreeMap();
                if (!ok) {
                    throw new IllegalAccessException("No access to change the session ip address to " + ip);
                } else {
                    attributes.put("IP", ip);
                }
                if (url.contains("/json/")) {
                    response.addContent(JSonConveter.converteJSON("IP status", null, null, attributes, null));
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setOk();
                    return response;
                } else {
                    response.addContent(IConverte.converte(IConverte.OutputType.HTML, "IP status", attributes));
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setOk();
                    return response;
                }
            }
        } catch (Exception ex) {
            if (url.contains("/json/")) {
                Map attributes = new TreeMap();
                attributes.put("Account status", Info.Status.locked.toString());
                response.addContent(JSonConveter.converteJSON(null, null, ex.getMessage(), attributes, ex));
                response.setContentType(MimeTypeParser.getInstance().getType("json"));
                response.setOk();
            } else {
                response.setError(ex);
            }
        }
        return response;
    }
}
