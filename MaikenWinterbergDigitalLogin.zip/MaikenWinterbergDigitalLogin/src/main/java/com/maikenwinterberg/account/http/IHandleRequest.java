/*
 * Martin Alexander Thomsen den 30 December 2024
 */
package com.maikenwinterberg.account.http;

import java.util.Map;
import org.veryquick.embweb.Response;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IHandleRequest {

    public Response handleRequest(String ip, String hostName, String url, Map<String, String> parameters) throws Exception;
}
