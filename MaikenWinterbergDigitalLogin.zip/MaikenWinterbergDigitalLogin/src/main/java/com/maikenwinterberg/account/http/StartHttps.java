/*
 * Martin Alexander Thomsen den 19 December 2024
 */
package com.maikenwinterberg.account.http;

import com.maikenwinterberg.config.Config;
import java.io.File;
import java.util.Map;

import org.veryquick.embweb.EmbeddedServer;
import org.veryquick.embweb.Response;
import org.veryquick.embweb.handlers.FileBasedRequestHandler;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.StringTokenizer;
import javax.swing.filechooser.FileSystemView;
import org.veryquick.embweb.HttpRequestHandler;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class StartHttps {

    public static final String ENCODING = "ISO-8859-1";

    public static void main(String[] args) throws Exception {
        try {
            FileSystemView view = FileSystemView.getFileSystemView();
            String configFolder = view.getHomeDirectory().getAbsolutePath();
            File KEYSTORE_FILE = new File(configFolder + "/config/accountConfig/KeyStore.jks");
            if (!KEYSTORE_FILE.exists()) {
                KEYSTORE_FILE = new File("config/accountConfig/KeyStore.jks");
            }
            if (KEYSTORE_FILE.exists()) {
                if (System.getProperty("javax.net.ssl.keyStore") == null) {
                    System.setProperty("javax.net.ssl.keyStore", KEYSTORE_FILE.getAbsolutePath());
                }
                if (System.getProperty("javax.net.ssl.keyStorePassword") == null) {
                    System.setProperty("javax.net.ssl.keyStorePassword", "123456");
                }
            }
        } catch (Exception ex) {
            System.out.println("unable to initialize ssl");
            ex.printStackTrace();
        }
        try {
            int port = 8443;
            try {
                String portAsString = Config.getValue(Config.Group.accountConfig, Config.Property.account, "port");
                port = Integer.parseInt(portAsString);
            } catch (Exception ex) {
            }
            EmbeddedServer.createInstance(port, new FileBasedRequestHandler(
                    new File("www")) {
                @Override
                public Response handleRequest(HttpRequestHandler.Type type, String hostName, String url,
                        Map<String, String> parameters) {
                    Response response = new Response();
                    //String domainName = parameters.get("GET_domainname");
                    String ip = parameters.get("REMOTE_IP");
                    if (ip != null) {
                        StringTokenizer tok = new StringTokenizer(ip, "/:");
                        ip = tok.nextToken();
                    }
                    try {
                        url = URLDecoder.decode(url, StandardCharsets.UTF_8.toString());
                        if (url.contains("/json/")) {
                            return HandleRequest.newInstance().handleRequest(ip, hostName, url, parameters);
                        } else if (url.contains("/html/")) {
                            return HandleRequest.newInstance().handleRequest(ip, hostName, url, parameters);
                        } else {
                            if (url.trim().isEmpty() || url.equals("/")) {
                                url = "index.html";
                            }
                            return super.handleRequest(type, hostName, url, parameters);
                        }
                    } catch (Throwable ex) {
                        ex.printStackTrace();
                        //TODO handle html
                        response.setContentType("application/json");
                        try {
                            response.setBinaryContent("{'Status': 'Error'}".getBytes(ENCODING));
                        } catch (Exception exe) {
                            response.setError(exe);
                        }
                        return response;
                    }
                }

            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
