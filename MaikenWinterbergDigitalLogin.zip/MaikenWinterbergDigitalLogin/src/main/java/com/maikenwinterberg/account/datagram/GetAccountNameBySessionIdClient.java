/*
 * Martin Alexander Thomsen den 30 December 2024
 */
package com.maikenwinterberg.account.datagram;

import com.maikenwinterberg.account.database.Info;
import com.maikenwinterberg.account.http.StartHttps;
import com.maikenwinterberg.config.Config;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class GetAccountNameBySessionIdClient implements ISessionClient {

    private DatagramSocket socket;
    private InetAddress address;
    private int port;

    @Override
    public Info getAccountInfo(String sessionId) throws Exception {
        port = 2202;
        try {
            port = Integer.parseInt(Config.getValue(Config.Group.bankerConfig, Config.Property.account, "datagramPort"));
        } catch (Exception ex) {
        }
        String hostname = "localhost";
        try {
            hostname = Config.getValue(Config.Group.bankerConfig, Config.Property.account, "datagramHost");
        } catch (Exception ex) {
        }
        socket = new DatagramSocket();
        socket.setSoTimeout(2000);
        address = InetAddress.getByName(hostname);
        if (sessionId == null) {
            return null;
        }
        byte[] buf = new byte[256];
        System.arraycopy(sessionId.getBytes(StartHttps.ENCODING), 0, buf, 0, sessionId.length());
        DatagramPacket packet = new DatagramPacket(buf, buf.length, address, port);
        socket.send(packet);
        byte[] buffer = new byte[512];
        DatagramPacket response = new DatagramPacket(buffer, buffer.length);
        socket.receive(response);
        String info = new String(buffer, StartHttps.ENCODING).trim().toLowerCase();
        //"Info{accountName=sss.green, currentIP=127.0.0.1, status=unlocked} "))
        if (info.contains("unlocked")) {
            String accountName = null;
            String ip = null;
            Info.Status status = Info.Status.unlocked;
            int index = info.indexOf("accountname");
            if (index != -1) {
                index += 12;
                int index2 = info.indexOf(",", index);
                if (index2 > index) {
                    accountName = info.substring(index, index2);
                }
            }
            index = info.indexOf("currentip");
            if (index != -1) {
                index += 10;
                int index2 = info.indexOf(",", index);
                if (index2 > index) {
                    ip = info.substring(index, index2);
                }
            }
            return new Info(null, accountName, ip, status, sessionId, null);
        }
        return null;
    }

    public static void main(String arg[]) throws Exception {
        GetAccountNameBySessionIdClient c = new GetAccountNameBySessionIdClient();
        long time = System.currentTimeMillis();
        for (int i = 0; i < 50000; i++) {
            Info info = c.getAccountInfo("ca13adf6-2ef2-46de-875e-f62a807af144");
            System.out.println(info);
        }
        System.out.println("50000 call " + (System.currentTimeMillis() - time));
    }
}
