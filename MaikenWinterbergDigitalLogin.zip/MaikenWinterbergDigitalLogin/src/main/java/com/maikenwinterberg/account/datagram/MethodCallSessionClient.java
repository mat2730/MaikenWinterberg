/*
 * Martin Alexander Thomsen den 5 Januar 2024
 */
package com.maikenwinterberg.account.datagram;

import com.maikenwinterberg.account.database.FileAccountImpl;
import com.maikenwinterberg.account.database.Info;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class MethodCallSessionClient implements ISessionClient {

    @Override
    public Info getAccountInfo(String sessionId) throws Exception {
        Info info = FileAccountImpl.getInstance().getSessionInfo(sessionId);
        return info;
    }
}
