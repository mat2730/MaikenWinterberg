/*
 * Martin Alexander Thomsen den 5 Januar 2024
 */
package com.maikenwinterberg.account.datagram;

import com.maikenwinterberg.account.database.Info;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface ISessionClient {
    public Info getAccountInfo(String sessionId) throws Exception;
}
