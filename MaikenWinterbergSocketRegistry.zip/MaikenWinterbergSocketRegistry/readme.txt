The socketregistry is a tool for administrating your sockets and database connections from a single source. 

This program require that:
    - Java version 1.17+ is installed on you system. Java can be download at: https://www.oracle.com/java/technologies/downloads/

Starting the registry as a standalone:        
    - execute startRegistry.sh

Starting the registry as a service
    - look at the readme_linux.txt or readme_windows.txt in the linux_service and windows_service folder.

Write cient code - you can use the API to lookup and register attributes in the registry:
    Main Class of API: martin.socketregistry.api.ClientRegistry
    Example code:
        ClientRegistry registry = ClientRegistry.getInstance(domainNameOfClient, maikenwinterberg.com, 4554)
        registry.registerSocket("serviceName", "localhost", "4554",null);
        registry.registerJDBC("serviceName", "org.mariadb.jdbc.Driver", "jdbc:mariadb://localhost:3306/project1", "userName1", "password1"); 
        Map<String,STring> attributes = new HashMap();
        attributes.put("attr1","theValue");
        registry.registerAttributes("serviceName", attributes); 
        registry.lookup(ClientRegistry.TYPE.jdbc, "lookupDomainName", "TheServiceNameYouAreLookingFor";

If you wish to change the code or create plugins for the MaikenWinterbergSocketRegistry can I recommend Netbeans: https://netbeans.apache.org/front/main/index.html


