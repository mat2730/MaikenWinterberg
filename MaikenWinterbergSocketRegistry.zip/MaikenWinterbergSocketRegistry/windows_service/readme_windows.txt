1) This program require that:
    - Java version 1.17+ is installed on you system. Java can be download at: https://www.oracle.com/java/technologies/downloads/

2) You can download the AlwaysUp application and use it to execute the bat command bin/startRegistry.bat: 
        https://download.cnet.com/alwaysup/3000-2084_4-10439107.html

3) then open for port 4554
