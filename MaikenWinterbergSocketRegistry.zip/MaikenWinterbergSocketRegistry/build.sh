cd src/main/java
javac com/**/*.java -s ../../../target/classes
