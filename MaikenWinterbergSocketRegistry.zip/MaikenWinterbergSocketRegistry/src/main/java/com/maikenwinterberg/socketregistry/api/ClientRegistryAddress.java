/*
 * Martin Alexander Thomsen den 7 Juli 2024
 */
package com.maikenwinterberg.socketregistry.api;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class ClientRegistryAddress {

    private final String registryIP;
    private final int registryPort;

    private final String registrationId;
    private final String registationType;
    private final String registrationDomainNameOrIP;
    private final String registrationServiceName;

    public ClientRegistryAddress(String registryIP, int registryPort, String registrationId, String registationType, String registrationDomainNameOrIP, String registrationServiceName) {
        this.registryIP = registryIP;
        this.registryPort = registryPort;
        this.registrationId = registrationId;
        this.registationType = registationType;
        this.registrationDomainNameOrIP = registrationDomainNameOrIP;
        this.registrationServiceName = registrationServiceName;
    }

    public String getRegistryIP() {
        return registryIP;
    }

    public int getRegistryPort() {
        return registryPort;
    }

    public String getRegistrationId() {
        return registrationId;
    }

    public String getRegistationType() {
        return registationType;
    }

    public String getRegistrationDomainNameOrIP() {
        return registrationDomainNameOrIP;
    }

    public String getRegistrationServiceName() {
        return registrationServiceName;
    }

    @Override
    public String toString() {
        if (registrationServiceName != null) {
            return "sr://" + registryIP + ":" + registryPort + "/" + registationType + "." + registrationServiceName + "." + registrationDomainNameOrIP;
        } else {
            return "sr://" + registryIP + ":" + registryPort + "/" + registationType + "." + registrationDomainNameOrIP;
        }
    }
}
