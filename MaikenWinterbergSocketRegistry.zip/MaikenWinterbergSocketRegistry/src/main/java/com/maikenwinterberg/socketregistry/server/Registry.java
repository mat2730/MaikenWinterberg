/*
 * Martin Alexander Thomsen den 30 Juni 2024
 */
package com.maikenwinterberg.socketregistry.server;

import com.maikenwinterberg.socketregistry.api.AbstractRegisration;
import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import com.maikenwinterberg.socketregistry.security.IRegistrySecurity;
import com.maikenwinterberg.socketregistry.security.RegistrySecurity;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import javax.swing.filechooser.FileSystemView;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * Changes to this file you must do in coloboration with me(Martin Alexander
 * Thomsen) see license.txt
 */
public class Registry {

    //DO NOT CHANGE THIS - see license.txt 
    public final static String PROTOCOL = "protocol" + ICommand.EQUAL_SEPERATOR + "maikenwinterberg.com,documentnetwork.com" + ICommand.ATTR_SEPERATOR;

    private static final boolean DEBUG = false;
    private static final Properties PROPERTIES = new Properties();
    private static Properties VALID_DOMAINS = null;
    private static Properties IN_VALID_DOMAINS = null;
    private static long IN_VALID_DOMAINS_LAST_MODIFIED;
    private static long VALID_DOMAINS_LAST_MODIFIED;
    private static long PROPERTIES_LAST_MODIFIED;
    private static File invalidDomainFile;
    private static File validDomainFile;
    private static File registryFile;

    private static ServerSocket SERVER_SOCKET;
    private static int port;
    private static String parentRegistries;

    public static String getProperty(String name) {
        try {
            if (registryFile == null) {
                FileSystemView view = FileSystemView.getFileSystemView();
                String configFolder = view.getHomeDirectory().getAbsolutePath();
                registryFile = new File(configFolder + "/config/registryConfig/registry.properties");
                if (!registryFile.exists()) {
                    //RELATIV
                    registryFile = new File("/config/registryConfig/registry.properties");
                }
            }
            BasicFileAttributes attr = Files.readAttributes(registryFile.toPath(), BasicFileAttributes.class);
            FileTime fileDate = attr.lastModifiedTime();
            if (PROPERTIES_LAST_MODIFIED != fileDate.toMillis()) {
                PROPERTIES.clear();
                PROPERTIES.load(new FileInputStream(registryFile));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return (String) PROPERTIES.get(name);

    }

    public static String getParentRegistries() {
        return parentRegistries;
    }

    public static int getPort() {
        return port;
    }

    private void initParent() {
        //WE WANT ONE NETWORK, THEREFORE, DO NOT CHANGE THIS WITHOUT AGGREMENT WITH ME - SE LICENSE.txt
        String domainNameOfRegistry = PROPERTIES.getProperty("domainNameOfRegistry");
        if (domainNameOfRegistry == null || domainNameOfRegistry.equalsIgnoreCase("localhost")) {
            DomainCheck.updateExternalID();
            domainNameOfRegistry = DomainCheck.getExternalId();
        }
        System.out.println("domainname of registry" + domainNameOfRegistry);
        Random ran = new Random();
        boolean b = ran.nextBoolean();
        String d1, d2;
        if (b) {
            d1 = "maikenwinterberg.com";
            d2 = "documentnetwork.com";
        } else {
            d1 = "documentnetwork.com";
            d2 = "maikenwinterberg.com";
        }
        Map attributes = new HashMap();
        attributes.put("port", "" + getPort());
        try {
            ClientRegistry clientRegistry = ClientRegistry.getRegistryInstance(domainNameOfRegistry, d1, 4554, false, false);
            List<AbstractRegisration> rl = clientRegistry.lookup(ClientRegistry.TYPE.map, domainNameOfRegistry, domainNameOfRegistry, "whoIsMyDaddy", attributes);
            if (rl != null && !rl.isEmpty()) {
                parentRegistries = (String) rl.get(0).getAttributes().get("parentRegistries");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("cannot get the whoIsMyDaddy attribute from " + d1);
        }
        try {
            if (parentRegistries == null) {
                ClientRegistry clientRegistry = ClientRegistry.getRegistryInstance(domainNameOfRegistry, d2, 4554, false, false);
                List<AbstractRegisration> rl = clientRegistry.lookup(ClientRegistry.TYPE.map, domainNameOfRegistry, domainNameOfRegistry, "whoIsMyDaddy", attributes);
                if (rl != null && !rl.isEmpty()) {
                    parentRegistries = (String) rl.get(0).getAttributes().get("parentRegistries");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("cannot get the whoIsMyDaddy attribute from " + d2);
        }
    }

    public static Properties getInValidDomains() throws Exception {
        if (invalidDomainFile == null) {
            FileSystemView view = FileSystemView.getFileSystemView();
            String configFolder = view.getHomeDirectory().getAbsolutePath();
            invalidDomainFile = new File(configFolder + "/config/fileDomainJumperConfig/inValidDomains.cfg");
            if (!invalidDomainFile.exists()) {
                invalidDomainFile = new File("/config/fileDomainJumperConfig/inValidDomains.cfg");
            }
        }
        BasicFileAttributes attr = Files.readAttributes(invalidDomainFile.toPath(), BasicFileAttributes.class);
        FileTime fileDate = attr.lastModifiedTime();
        if (IN_VALID_DOMAINS != null) {
            if (IN_VALID_DOMAINS_LAST_MODIFIED == fileDate.toMillis()) {
                return IN_VALID_DOMAINS;
            }
        }
        IN_VALID_DOMAINS_LAST_MODIFIED = fileDate.toMillis();
        IN_VALID_DOMAINS = new Properties();
        IN_VALID_DOMAINS.load(new FileInputStream(invalidDomainFile));
        return IN_VALID_DOMAINS;
    }

    public static Properties getValidDomains() throws Exception {
        if (validDomainFile == null) {
            FileSystemView view = FileSystemView.getFileSystemView();
            String configFolder = view.getHomeDirectory().getAbsolutePath();
            validDomainFile = new File(configFolder + "/config/fileDomainJumperConfig/validDomains.cfg");
            if (!validDomainFile.exists()) {
                validDomainFile = new File("/config/fileDomainJumperConfig/validDomains.cfg");
            }
        }
        BasicFileAttributes attr = Files.readAttributes(validDomainFile.toPath(), BasicFileAttributes.class);
        FileTime fileDate = attr.lastModifiedTime();
        if (VALID_DOMAINS != null) {
            if (VALID_DOMAINS_LAST_MODIFIED == fileDate.toMillis()) {
                return VALID_DOMAINS;
            }
        }
        VALID_DOMAINS_LAST_MODIFIED = fileDate.toMillis();
        VALID_DOMAINS = new Properties();
        VALID_DOMAINS.load(new FileInputStream(validDomainFile));
        return VALID_DOMAINS;
    }

    public void start() throws Exception {
        System.out.println("starting registry...");

        FileSystemView view = FileSystemView.getFileSystemView();
        String configFolder = view.getHomeDirectory().getAbsolutePath();
        registryFile = new File(configFolder + "/config/registryConfig/registry.properties");
        File startupFile = new File(configFolder + "/config/registryConfig/startup.cfg");
        if (!registryFile.exists()) {
            //RELATIV
            registryFile = new File("/config/registryConfig/registry.properties");
            startupFile = new File("/config/registryConfig/startup.cfg");
        }
        BasicFileAttributes attr = Files.readAttributes(registryFile.toPath(), BasicFileAttributes.class);
        FileTime fileDate = attr.lastModifiedTime();
        PROPERTIES_LAST_MODIFIED = fileDate.toMillis();
        try {
            PROPERTIES.load(new FileInputStream(registryFile));
            String securityimpl = PROPERTIES.getProperty("securityimpl");
            if (securityimpl != null && !securityimpl.trim().isEmpty()) {
                try {
                    RegistrySecurity.DEFAULT_SECURITY_IMPL = (IRegistrySecurity) Class.forName(securityimpl).newInstance();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        try {
            try (BufferedReader br = new BufferedReader(new FileReader(startupFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    try {
                        if (line.startsWith("#") || line.trim().isEmpty()) {
                            //this is a comment continue;
                            continue;
                        }
                        String output = ServerSocketThread.executeCommand(false, null, line);
                        if (DEBUG) {
                            System.out.println(output);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("error loading startup.cfg");
        }
        //WE WANT ONE NETWORK, THEREFORE, DO NOT CHANGE THIS WITHOUT AGGREMENT WITH ME - SE LICENSE.txt
        //not needed now -> have domain registries now
        //initParent();
        //startup serversocket
        //String domainNameOfRegistry = PROPERTIES.getProperty("domainNameOfRegistry");
        InetAddress addr = InetAddress.getByName("0.0.0.0");
        System.out.println("host " + addr.getHostAddress());
        int backlog = 0;
        System.out.println("starting serversocket on port " + port);
        SERVER_SOCKET = new ServerSocket(port, backlog, addr);
        //SERVER_SOCKET = new ServerSocket(port);
        System.out.println("Listening on port " + port + "...");
        while (true) {
            if (DEBUG) {
                System.out.println("waiting for socket...");
            }
            Socket clientSocket = SERVER_SOCKET.accept();
            System.out.println("creating client thread of client " + clientSocket.getRemoteSocketAddress().toString());
            Thread thread = new ServerSocketThread(clientSocket);
            thread.start();
        }
    }

    @Override
    protected void finalize() throws Throwable {
        try {
            SERVER_SOCKET.close();
        } finally {
            super.finalize();
        }
    }

    public static void main(String[] args) throws Exception {
        port = 4554;
        try {
            port = Integer.parseInt(args[0]);
        } catch (Exception ex) {
        }
        Registry server = new Registry();
        server.start();
    }
}
