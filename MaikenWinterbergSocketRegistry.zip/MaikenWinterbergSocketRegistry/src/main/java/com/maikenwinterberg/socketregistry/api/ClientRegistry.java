/*
 * Martin Alexander Thomsen den 1 Juli 2024
 */
package com.maikenwinterberg.socketregistry.api;

import com.maikenwinterberg.socketregistry.security.IRegistrySecurity;
import java.net.Socket;
import java.security.PrivateKey;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import javax.crypto.SecretKey;
import com.maikenwinterberg.socketregistry.security.RegistrySecurity;
import com.maikenwinterberg.socketregistry.server.DomainCheck;
import com.maikenwinterberg.socketregistry.server.ICommand;
import com.maikenwinterberg.socketregistry.server.Registry;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.URL;
import java.rmi.ConnectIOException;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * Changes to this file you must do in coloboration with me(Martin Alexander
 * Thomsen) see license.txt
 */
public final class ClientRegistry {

    private final static boolean DEBUG = true;
    private static ClientRegistry registrySingleton;

    private final String originalIp;
    private final String registryIp;
    private final int registryPort;
    private final boolean useExternalID;

    private Object key2SecurityImpl = null;
    private Socket socket;
    private DataOutputStream out;
    private DataInputStream in;
    private String defaultDomainNameOfClient;
    private boolean registerPublicKeyCalled = false;

    enum CMD {
        com_maikenwinterberg_socketregistry_server_RegisterCmd,
        com_maikenwinterberg_socketregistry_server_LookupCmd,
        com_maikenwinterberg_socketregistry_server_UnregisterCmd,
        com_maikenwinterberg_socketregistry_server_RegpublickeyCmd,
        com_maikenwinterberg_socketregistry_server_SendInfoToParentRegistriesCmd,
        com_maikenwinterberg_socketregistry_server_ReceiveBulkRegistrationCmd
    }

    public enum TYPE {
        jdbc, socket, map, subscription;
    }

    private ClientRegistry(String defaultDomainNameOfClient, String ip, int port, boolean useExternalID) throws Exception {
        this.originalIp = ip;
        String newip = getRedirectUrl(ip);
        if (!newip.equals(ip)) {
            if (DEBUG) {
                System.out.println("redirection url from " + ip + " to " + newip);
            }
            ip = newip;
        }
        this.registryIp = ip;
        this.registryPort = port;
        this.useExternalID = useExternalID;
        this.defaultDomainNameOfClient = defaultDomainNameOfClient;
        this.registerPublicKeyCalled = false;
    }

    public String getOriginalIP() {
        return originalIp;
    }

    public String getRegistryIP() {
        return registryIp;
    }

    public int getPort() {
        return registryPort;
    }

    public synchronized boolean isLocalhost() {
        if (registryIp.equalsIgnoreCase("locahost")) {
            return true;
        } else if (registryIp.equalsIgnoreCase("127.0.0.1")) {
            return true;
        } else if (DomainCheck.getExternalId() != null && registryIp.equalsIgnoreCase(DomainCheck.getExternalId())) {
            return true;
        }
        return false;
    }

    //without this method all redirect urls will make the system stop. 
    private synchronized String getRedirectUrl(String canonicalUrl) throws Exception {
        if (canonicalUrl == null || canonicalUrl.equals("localhost")) {
            return canonicalUrl;
        }
        try {
            //https
            URL url = new URL("https://" + canonicalUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setInstanceFollowRedirects(true);
            int status = connection.getResponseCode();
            String redirectedUrl = null;
            if (status == HttpURLConnection.HTTP_MOVED_PERM || status == HttpURLConnection.HTTP_MOVED_TEMP) {
                redirectedUrl = connection.getHeaderField("Location");
                int index = redirectedUrl.indexOf("//");
                if (index != -1) {
                    redirectedUrl = redirectedUrl.substring(index + 2);
                }
            }
            connection.disconnect();
            if (redirectedUrl != null) {
                if (DEBUG) {
                    System.out.println("https redirecting registry url " + canonicalUrl + "->" + redirectedUrl);
                }
                return redirectedUrl;
            }
        } catch (Exception ex) {
            //ex.printStackTrace();
        }
        //default
        return canonicalUrl;
    }

    private synchronized void connect2Registry() throws Exception {
        //@SEE https://www.baeldung.com/java-socket-connection-read-timeout
        int socketTimeout = 5000;
        try {
            socketTimeout = Integer.parseInt(Registry.getProperty("sockettimeout"));
        } catch (Exception ex) {
        }
        this.socket = new Socket();
        SocketAddress socketAddress = new InetSocketAddress(registryIp, registryPort);
        this.socket.connect(socketAddress, socketTimeout);
        this.out = new DataOutputStream(socket.getOutputStream());
        this.in = new DataInputStream(socket.getInputStream());

    }

    public void close() {
        if (in != null) {
            try {
                in.close();
            } catch (Exception ex) {
                //ignoreclose()
            }
        }
        if (out != null) {
            try {
                out.close();
            } catch (Exception ex) {
                //ignore
            }
        }
        if (socket != null) {
            try {
                socket.close();
            } catch (Exception ex) {
                //ignore
            }
        }
    }

    @Override
    protected void finalize() throws Throwable {
        try {
            close();
        } finally {
            super.finalize();
        }
    }

    private synchronized String sendCmdAsUFT(boolean encrypt, String cmd) throws Exception {
        try {
            connect2Registry();
            if (encrypt && !registerPublicKeyCalled) {
                boolean ok = registerpublickey();
                if (!ok) {
                    throw new ConnectIOException("failed to register public key");
                }
            }
            if (DEBUG) {
                System.out.println("Writing to server: " + Registry.PROTOCOL + cmd);
            }
            if (encrypt) {
                //DO NOT CHANGE THIS - see license.txt 
                out.writeUTF((Registry.PROTOCOL + RegistrySecurity.textEncrypt(key2SecurityImpl, this, cmd)));
            } else {
                //DO NOT CHANGE THIS - see license.txt 
                out.writeUTF((Registry.PROTOCOL + "encrypted=false" + cmd));
            }
            out.flush();
            String line = null;
            try {
                line = in.readUTF();
                if (line.startsWith("encrypted=false")) {
                    line = line.substring(15);
                    if (line.contains("stacktrace")) {
                        throw new IllegalStateException(line);
                    }
                } else {
                    line = RegistrySecurity.textDecrypt(key2SecurityImpl, this, line);
                }
            } catch (Exception ex) {
                if (DEBUG) {
                    ex.printStackTrace();
                }
            }
            if (DEBUG) {
                System.out.println("reading from server: " + line);
            }
            return line;
        } finally {
            close();
        }
    }

    private synchronized String sendCmd(boolean encrypt, String cmd) throws Exception {
        try {
            if (encrypt && !registerPublicKeyCalled) {
                boolean ok = registerpublickey();
                if (!ok) {
                    throw new ConnectIOException("failed to register public key");
                }
            }
            connect2Registry();
            if (DEBUG) {
                System.out.println("Writing to server binary version: " + Registry.PROTOCOL + cmd);
            }
            if (encrypt) {
                //DO NOT CHANGE THIS - see license.txt 
                String text2Send = (Registry.PROTOCOL + RegistrySecurity.textEncrypt(key2SecurityImpl, this, cmd));
                byte[] bytes2Send = text2Send.getBytes("utf-8");
                out.writeInt(bytes2Send.length);
                out.write(bytes2Send);
                //out.writeUTF(text2Send);
            } else {
                //DO NOT CHANGE THIS - see license.txt 
                String text2Send = (Registry.PROTOCOL + "encrypted=false" + cmd);
                byte[] bytes2Send = text2Send.getBytes("utf-8");
                out.writeInt(bytes2Send.length);
                out.write(bytes2Send);
                //out.writeUTF(text2Send);
            }
            //out.flush();
            String line = null;
            try {
                long size = in.readInt();
                byte[] bytes2Read = new byte[(int) size];
                in.readFully(bytes2Read, 0, bytes2Read.length);
                line = new String(bytes2Read, "utf-8");
                //line = in.readUTF();
                if (line.startsWith("encrypted=false")) {
                    line = line.substring(15);
                    if (line.contains("stacktrace")) {
                        throw new IllegalStateException(line);
                    }
                } else {
                    line = RegistrySecurity.textDecrypt(key2SecurityImpl, this, line);
                }
            } catch (Exception ex) {
                if (DEBUG) {
                    ex.printStackTrace();
                }
            }
            if (DEBUG) {
                System.out.println("reading from server binary version: " + line);
            }
            return line;
        } catch (Exception ex) {
            ex.printStackTrace();
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            ex.printStackTrace(pw);
            String sStackTrace = sw.toString();
            return ("encrypted=falsestatus" + ICommand.EQUAL_SEPERATOR + "error" + ICommand.ATTR_SEPERATOR + "errormessage" + ICommand.EQUAL_SEPERATOR + ex.getMessage() + ICommand.ATTR_SEPERATOR + "stacktrace" + ICommand.EQUAL_SEPERATOR + "\n" + sStackTrace);
        } finally {
            close();
        }
    }

    public static final ClientRegistry getRegistryInstance(String domainNameOfClient, String ipOrDomainnameOfRegistry, int portofRegistry, boolean useExternalID, boolean singleton) throws Exception {
        if (domainNameOfClient == null) {
            domainNameOfClient = "localhost";
            //throw new IllegalArgumentException("Invalid paramenters ");
        }
        if (!singleton) {
            //domainNameOfClient = DomainCheck.getDefaultDomainNameOnClient(domainNameOfClient);
            ClientRegistry aNewRegistry = new ClientRegistry(domainNameOfClient, ipOrDomainnameOfRegistry, portofRegistry, useExternalID);
            return aNewRegistry;
        } else if (registrySingleton == null) {
            //domainNameOfClient = DomainCheck.getDefaultDomainNameOnClient(domainNameOfClient);
            registrySingleton = new ClientRegistry(domainNameOfClient, ipOrDomainnameOfRegistry, portofRegistry, useExternalID);
        }
        return registrySingleton;
    }

    private synchronized boolean registerpublickey() {
        return registerpublickey(0);
    }

    private boolean handleResponse(int count, String responseFromServer, Exception exeFromCmdCall) throws Exception {
        if (responseFromServer != null) {
            if (responseFromServer.contains(ICommand.NO_SECURE_KEY_FOUND_ERROR)) {
                if (count == 0) {
                    try {
                        if (DEBUG) {
                            System.out.println("error from server:" + responseFromServer + "\nTrying one more time");
                        }
                        if (registerpublickey(count++)) {
                            return true;
                        }
                    } catch (Exception ex) {
                        return false;
                    }
                } else {
                    throw new SecurityException(responseFromServer);
                }
            } else if (count == 0 && responseFromServer.contains("errormessage===Invalid domainname")) {
                if (count == 0) {
                    if (useExternalID) {
                        try {
                            //if dynamic ip
                            if (DEBUG) {
                                System.out.println("error from server:" + responseFromServer + "\nTrying one more time");
                            }
                            if (registerpublickey(count++)) {
                                return true;
                            }
                        } catch (Exception ex) {
                            return false;
                        }
                    }
                } else {
                    throw new SecurityException(responseFromServer);
                }
            }
        } else {
            if (count == 0) {
                try {
                    //if dynamic ip
                    if (DEBUG) {
                        System.out.println("error from server:" + responseFromServer + "\nTrying one more time");
                    }
                    if (registerpublickey(count++)) {
                        return true;
                    }
                } catch (Exception ex) {
                    return false;
                }
            } else {
                throw new ConnectException("cannot connect to registry " + this);
            }
        }
        if (responseFromServer != null && responseFromServer.contains("stacktrace")) {
            throw new IllegalStateException(responseFromServer);
        } else if (exeFromCmdCall != null) {
            if (DEBUG) {
                System.out.println("cannot connect to server " + this);
            }
            throw exeFromCmdCall;
        }
        return false;
    }

    /*
    if this method returns a value the clientDomainName is overridden
     */
    private synchronized boolean registerpublickey(int count) {
        if (DEBUG) {
            System.out.println("\n\nregisterpublickey");
        }
        try {
            if (useExternalID) {
                //dynamic ip
                DomainCheck.updateExternalID();
                defaultDomainNameOfClient = DomainCheck.getDefaultDomainNameOnClient2(defaultDomainNameOfClient);
            }
            StringBuilder builder = new StringBuilder();
            builder.append("securityplugin");
            builder.append(ICommand.EQUAL_SEPERATOR);
            if (key2SecurityImpl == null) {
                builder.append(RegistrySecurity.DEFAULT_SECURITY_IMPL.getClass().getName());
            } else {
                builder.append(key2SecurityImpl.toString());
            }
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.com_maikenwinterberg_socketregistry_server_RegpublickeyCmd.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainname");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(defaultDomainNameOfClient);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("publickey");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(RegistrySecurity.toBase64(key2SecurityImpl, RegistrySecurity.getKeyPair(key2SecurityImpl, this).getPublic()));
            String secretKeyAsEncryptedBase64 = sendCmd(false, builder.toString());
            if (secretKeyAsEncryptedBase64 != null) {
                try {
                    if (count == 0) {
                        IRegistrySecurity s = (IRegistrySecurity) Class.forName(secretKeyAsEncryptedBase64).newInstance();
                        this.key2SecurityImpl = s.getClass().getName();
                        //do one more call to new security plugin
                        if (DEBUG) {
                            System.out.println("changing security plugin to " + secretKeyAsEncryptedBase64);
                        }
                        return registerpublickey(1);
                    }
                } catch (Exception ex) {
                    //ignore
                }
                if (!secretKeyAsEncryptedBase64.contains("stacktrace")) {
                    PrivateKey privateKey = RegistrySecurity.getKeyPair(key2SecurityImpl, this).getPrivate();
                    byte[] secretKeyAsEncrypted = RegistrySecurity.fromBase64(key2SecurityImpl, secretKeyAsEncryptedBase64); //String secretKeyAsEncryptedBase64);
                    byte[] seretKeyAsBytes = RegistrySecurity.privateKeyDecrypt(key2SecurityImpl, privateKey, secretKeyAsEncrypted);
                    SecretKey secretKey = RegistrySecurity.toSecretKey(key2SecurityImpl, seretKeyAsBytes);//AESUtil.fromBytes(seretKeyAsDecrypted);
                    RegistrySecurity.setSecretKey(key2SecurityImpl, this, secretKey);
                    if (DEBUG) {
                        System.out.println("secretKey received from registry " + secretKey);
                    }
                    registerPublicKeyCalled = true;
                    return true;
                }
            } else {
                if (DEBUG) {
                    System.out.println("empty response from server");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        if (DEBUG) {
            System.out.println("cannot register public key at " + registryIp + ":" + registryPort);
        }
        registerPublicKeyCalled = false;
        return false;
    }

    public synchronized ClientRegistryAddress registerSocket(String serviceName, String ip, String port, String publicRSAKeyAsBase64) {
        return registerSocket(null, serviceName, null, ip, port, publicRSAKeyAsBase64, null);
    }

    public synchronized ClientRegistryAddress registerSocket(String domainName, String serviceName, String registrationId, String ip, String port, String publicRSAKeyAsBase64, String securityImpl) {
        return registerSocket(0, domainName, serviceName, registrationId, ip, port, publicRSAKeyAsBase64, securityImpl);
    }

    private synchronized ClientRegistryAddress registerSocket(int count, String domainName, String serviceName, String registrationId, String ip, String port, String publicRSAKeyAsBase64, String securityImpl) {
        if (DEBUG) {
            System.out.println("\n\nregisterSocket");
        }
        try {
            if (serviceName == null || ip == null || port == null) {
                throw new IllegalArgumentException("Invalid paramenters ");
            }
            domainName = DomainCheck.getDomainNameOnClient(defaultDomainNameOfClient, domainName);
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.com_maikenwinterberg_socketregistry_server_RegisterCmd.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("type");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(TYPE.socket.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainname");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(domainName);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("servicename");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(serviceName);
            if (registrationId != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("registrationId");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(registrationId);
            }
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("ip");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(ip);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("port");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(port);
            if (publicRSAKeyAsBase64 != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("public_key");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(publicRSAKeyAsBase64);
            }
            if (securityImpl != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("security_impl");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(securityImpl);
            }
            String response = null;
            Exception exeFromCmd = null;
            try {
                response = sendCmd(true, builder.toString());
            } catch (Exception exe) {
                exeFromCmd = exe;
            }
            try {
                boolean recall = handleResponse(count, response, exeFromCmd);
                if (recall) {
                    return registerSocket(count++, domainName, serviceName, registrationId, ip, port, publicRSAKeyAsBase64, securityImpl);
                }
                return new ClientRegistryAddress(registryIp, registryPort, registrationId, TYPE.socket.toString(), domainName, serviceName);
            } catch (Exception ex) {
                return null;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public synchronized ClientRegistryAddress registerAttributes(String serviceName, Map<String, String> attributes) {
        return registerAttributes(null, serviceName, null, attributes);
    }

    public synchronized ClientRegistryAddress registerAttributes(String domainName, String serviceName, String registrationId, Map<String, String> attributes) {
        return registerAttributes(0, domainName, serviceName, registrationId, attributes);
    }

    private synchronized ClientRegistryAddress registerAttributes(int count, String domainName, String serviceName, String registrationId, Map<String, String> attributes) {
        return register(TYPE.map, 0, domainName, serviceName, registrationId, attributes);
    }

    public synchronized ClientRegistryAddress registerSubscription(String domainName, String serviceName, String registrationId, String registryIp, String registryPort) {
        Map<String, String> attributes = new HashMap();
        attributes.put("registry_ip", registryIp);
        attributes.put("registry_port", registryPort);
        return register(TYPE.subscription, 0, domainName, serviceName, registrationId, attributes);
    }

    private synchronized ClientRegistryAddress register(TYPE type, int count, String domainName, String serviceName, String registrationId, Map<String, String> attributes) {
        if (DEBUG) {
            System.out.println("\n\nregister");
        }
        try {
            if (serviceName == null || attributes == null || attributes.isEmpty()) {
                throw new IllegalArgumentException("Invalid paramenters ");
            }
            domainName = DomainCheck.getDomainNameOnClient(defaultDomainNameOfClient, domainName);
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.com_maikenwinterberg_socketregistry_server_RegisterCmd.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("type");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(type.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainname");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(domainName);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("servicename");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(serviceName);
            if (registrationId != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("registrationId");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(registrationId);
            }
            try {
                for (Iterator<String> i = attributes.keySet().iterator(); i.hasNext();) {
                    String attributeName = i.next();
                    String attributeValue = i.next();
                    builder.append(ICommand.ATTR_SEPERATOR);
                    builder.append(attributeName);
                    builder.append(ICommand.EQUAL_SEPERATOR);
                    builder.append(attributeValue);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            String response = null;
            Exception exeFromCmd = null;
            try {
                response = sendCmd(true, builder.toString());
            } catch (Exception exe) {
                exeFromCmd = exe;
            }
            try {
                boolean recall = handleResponse(count, response, exeFromCmd);
                if (recall) {
                    return registerAttributes(count++, domainName, serviceName, registrationId, attributes);
                }
                return new ClientRegistryAddress(registryIp, registryPort, registrationId, type.toString(), domainName, serviceName);
            } catch (Exception ex) {
                return null;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public synchronized ClientRegistryAddress registerJDBC(String serviceName, String driver, String url, String userName, String password) {
        return registerJDBC(null, serviceName, null, driver, url, userName, password);
    }

    public synchronized ClientRegistryAddress registerJDBC(String domainName, String serviceName, String registrationId, String driver, String url, String userName, String password) {
        return registerJDBC(0, domainName, serviceName, registrationId, driver, url, userName, password);
    }

    private synchronized ClientRegistryAddress registerJDBC(int count, String domainName, String serviceName, String registrationId, String driver, String url, String userName, String password) {
        if (DEBUG) {
            System.out.println("\n\nregisterJDBC");
        }
        try {
            if (serviceName == null || driver == null || url == null) {
                throw new IllegalArgumentException("Invalid paramenters ");
            }
            domainName = DomainCheck.getDomainNameOnClient(defaultDomainNameOfClient, domainName);
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.com_maikenwinterberg_socketregistry_server_RegisterCmd.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("type");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(TYPE.jdbc.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainname");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(domainName);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("servicename");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(serviceName);
            if (registrationId != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("registrationId");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(registrationId);
            }
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("driver");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(driver);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("url");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(url);
            if (userName != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("username");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(userName);
            }
            if (password != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("password");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(password);
            }
            String response = null;
            Exception exeFromCmd = null;
            try {
                response = sendCmd(true, builder.toString());
            } catch (Exception exe) {
                exeFromCmd = exe;
            }
            try {
                boolean recall = handleResponse(count, response, exeFromCmd);
                if (recall) {
                    return registerJDBC(count++, domainName, serviceName, registrationId, driver, url, userName, password);
                }
                return new ClientRegistryAddress(registryIp, registryPort, registrationId, TYPE.jdbc.toString(), domainName, serviceName);
            } catch (Exception ex) {
                return null;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public synchronized boolean UnRegister(TYPE type, String serviceName) {
        return UnRegister(type, null, serviceName);
    }

    public synchronized boolean UnRegister(TYPE type, String domainName, String serviceName) {
        return UnRegister(0, type, domainName, serviceName);

    }

    private synchronized boolean UnRegister(int count, TYPE type, String domainName, String serviceName) {
        if (DEBUG) {
            System.out.println("\n\nUnRegister");
        }
        try {
            if (type == null) {
                throw new IllegalArgumentException("Invalid paramenters ");
            }
            domainName = DomainCheck.getDomainNameOnClient(defaultDomainNameOfClient, domainName);
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.com_maikenwinterberg_socketregistry_server_UnregisterCmd.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("type");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(type.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainName");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(domainName);
            if (serviceName != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("servicename");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(serviceName);
            }
            String response = null;
            Exception exeFromCmd = null;
            try {
                response = sendCmd(true, builder.toString());
            } catch (Exception exe) {
                exeFromCmd = exe;
            }
            try {
                boolean recall = handleResponse(count, response, exeFromCmd);
                if (recall) {
                    return UnRegister(count++, type, domainName, serviceName);
                }
                return true;
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public synchronized List<AbstractRegisration> lookup(TYPE type, String lookupDomainName, String serviceName) {
        return lookup(type, null, lookupDomainName, serviceName);
    }

    public synchronized List<AbstractRegisration> lookup(TYPE type, String domainNameOfClient, String lookupDomainName, String serviceName) {
        return lookup(0, type, domainNameOfClient, lookupDomainName, serviceName);
    }

    /*
    @param int fetchSizelookup
    Max fetch size is controlled by com.maikenwinterberg.socketregistry.persistence.jdbc.RegistryJDBCDB.maxFetchSize
    currently its 100
     */
    public synchronized List<AbstractRegisration> lookup(TYPE type, String domainNameOfClient, String lookupDomainName, String serviceName, int offset, int fetchSize) {
        Map attributes = new HashMap();
        attributes.put("offset", offset);
        attributes.put("fetchsize", fetchSize);
        return lookup(0, type, domainNameOfClient, lookupDomainName, serviceName, attributes);
    }

    public synchronized List<AbstractRegisration> lookup(TYPE type, String domainNameOfClient, String lookupDomainName, String serviceName, Map<String, String> attributes) {
        return lookup(0, type, domainNameOfClient, lookupDomainName, serviceName, attributes);
    }

    private synchronized List<AbstractRegisration> lookup(int count, TYPE type, String domainNameOfClient, String lookupDomainName, String serviceName) {
        return lookup(count, type, domainNameOfClient, lookupDomainName, serviceName, new HashMap());
    }

    private synchronized List<AbstractRegisration> lookup(int count, TYPE type, String domainNameOfClient, String lookupDomainName, String serviceName, Map<String, String> attributes) {
        //TODO avoid loop - implement domainTrace
        if (DEBUG) {
            System.out.println("\n\nUlookup");
        }
        List<AbstractRegisration> registrationList = new LinkedList<>();
        try {
            domainNameOfClient = DomainCheck.getDomainNameOnClient(defaultDomainNameOfClient, domainNameOfClient);
            if (lookupDomainName == null) {
                lookupDomainName = domainNameOfClient;
            }
            lookupDomainName = DomainCheck.getLookupDomainName(lookupDomainName);
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.com_maikenwinterberg_socketregistry_server_LookupCmd.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("type");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(type.toString());
            if (domainNameOfClient != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("domainName");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(domainNameOfClient);
            }
            if (lookupDomainName != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("lookupDomainName");

                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(lookupDomainName);
            }
            if (serviceName != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("servicename");

                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(serviceName);
            }
            if (attributes != null) {
                for (Iterator i = attributes.keySet().iterator(); i.hasNext();) {
                    String key = (String) i.next();
                    Object value = (Object) attributes.get(key);
                    if (key != null && value != null) {
                        builder.append(ICommand.ATTR_SEPERATOR);
                        builder.append(key.toLowerCase());
                        builder.append(ICommand.EQUAL_SEPERATOR);
                        builder.append(value.toString());
                    }
                }
            }
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("lookupType");
            builder.append(ICommand.EQUAL_SEPERATOR);
            if (lookupDomainName != null && serviceName != null) {
                builder.append("lookupByDomainAndService");
            } else if (lookupDomainName != null) {
                builder.append("lookupByDomain");
            } else if (serviceName != null) {
                builder.append("lookupByService");
            } else {
                builder.append("lookupAll");
            }
            String response = null;
            Exception exeFromCmd = null;
            try {
                response = sendCmd(true, builder.toString());
            } catch (Exception exe) {
                exeFromCmd = exe;
            }
            try {
                boolean recall = handleResponse(count, response, exeFromCmd);
                if (recall) {
                    return lookup(count++, type, domainNameOfClient, lookupDomainName, serviceName);
                }
                StringTokenizer tok = new StringTokenizer(response, ICommand.REG_SEPERATOR);
                //boolean firstRun = true;
                while (tok.hasMoreTokens()) {
                    String registationAsString = tok.nextToken();
                    StringTokenizer tok2 = new StringTokenizer(registationAsString, ICommand.ATTR_SEPERATOR);
                    Map<String, String> registrationAsMap = new HashMap();
                    while (tok2.hasMoreTokens()) {
                        StringTokenizer tok3 = new StringTokenizer(tok2.nextToken(), ICommand.EQUAL_SEPERATOR);
                        String name = null;
                        if (tok3.hasMoreTokens()) {
                            name = tok3.nextToken();
                        }
                        String value = null;
                        if (tok3.hasMoreTokens()) {
                            value = tok3.nextToken();
                        }
                        if (DEBUG) {
                            if (DEBUG) {
                                System.out.println("Adding value to map " + name.toLowerCase() + "," + value);
                            }
                        }
                        if (name != null && value != null) {
                            registrationAsMap.put(name.toLowerCase(), value);
                        }
                    }
                    AbstractRegisration registration = null;
                    String typeAsString = registrationAsMap.get("type");
                    if (typeAsString == null) {
                        if (registrationAsMap.get("ip") != null && registrationAsMap.get("port") != null) {
                            typeAsString = TYPE.socket.toString();
                        } else if (registrationAsMap.get("driver") != null && registrationAsMap.get("url") != null) {
                            typeAsString = TYPE.jdbc.toString();
                        } else if (registrationAsMap.get("registry_ip") != null && registrationAsMap.get("registry_port") != null) {
                            typeAsString = TYPE.subscription.toString();
                        } else {
                            typeAsString = TYPE.map.toString();
                        }
                    }
                    if (DEBUG) {
                        if (DEBUG) {
                            System.out.println("type " + typeAsString);
                        }
                    }
                    if (typeAsString.equalsIgnoreCase(TYPE.socket.toString())) {
                        registration = new SocketRegistration();
                        ((SocketRegistration) registration).setIp(registrationAsMap.get("ip"));
                        ((SocketRegistration) registration).setPort(registrationAsMap.get("port"));
                    } else if (typeAsString.equalsIgnoreCase(TYPE.jdbc.toString())) {
                        registration = new JDBCRegistration();
                        ((JDBCRegistration) registration).setDriver(registrationAsMap.get("driver"));
                        ((JDBCRegistration) registration).setUrl(registrationAsMap.get("url"));
                        ((JDBCRegistration) registration).setUserName(registrationAsMap.get("username"));
                        ((JDBCRegistration) registration).setPassword(registrationAsMap.get("password"));
                    } else if (typeAsString.equalsIgnoreCase(TYPE.jdbc.toString())) {
                        registration = new SubscriptionRegistration(registrationAsMap.get("registry_ip"), registrationAsMap.get("registry_port"));
                    } else {
                        registration = new MapRegistration();
                    }
                    registration.setAttributes(registrationAsMap);
                    registration.setDomainName(registrationAsMap.get("domainname"));
                    registration.setServicenName(registrationAsMap.get("servicename"));
                    registration.setType(TYPE.valueOf(typeAsString));
                    registration.setClientDomainName(domainNameOfClient);
                    registrationList.add(registration);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } catch (IllegalStateException ise) {
            //ignore
        } catch (Exception ex) {
            //ignore
            ex.printStackTrace();
        }
        return registrationList;
    }

    @Override
    public synchronized String toString() {
        return originalIp + "-->" + registryIp + ":" + registryPort;
    }

    @Override
    public synchronized int hashCode() {
        return (registryIp + ":" + registryPort).hashCode();
    }
}
