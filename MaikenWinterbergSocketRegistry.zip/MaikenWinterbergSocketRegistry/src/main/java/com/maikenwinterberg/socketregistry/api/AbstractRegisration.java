/*
 * Martin Alexander Thomsen den 1 Juli 2024
 */
package com.maikenwinterberg.socketregistry.api;

import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public abstract class AbstractRegisration {

    private ClientRegistry.TYPE type;
    private String domainName;
    private String servicenName;
    protected Map attributes;
    private String clientDomainName;

    public String getClientDomainName() {
        return clientDomainName;
    }

    public void setClientDomainName(String clientDomainName) {
        this.clientDomainName = clientDomainName;
    }

    public Map getAttributes() {
        return attributes;
    }

    @Override
    public String toString() {
        return "AbstractRegisration{" + "type=" + type + ", attributes=" + attributes + '}';
    }

    public void setAttributes(Map attributes) {
        this.attributes = attributes;
    }
    
    public ClientRegistry.TYPE getType() {
        return type;
    }

    public void setType(ClientRegistry.TYPE type) {
        this.type = type;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public String getServicenName() {
        return servicenName;
    }

    public void setServicenName(String servicenName) {
        this.servicenName = servicenName;
    }
}
