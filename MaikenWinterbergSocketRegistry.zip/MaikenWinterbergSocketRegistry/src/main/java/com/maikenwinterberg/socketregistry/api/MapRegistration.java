/*
 * Martin Alexander Thomsen den 1 Juli 2024
 */
package com.maikenwinterberg.socketregistry.api;

import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class MapRegistration extends AbstractRegisration{
    
}
