/*
 * Martin Alexander Thomsen den 30 Juni 2024
 */
package com.maikenwinterberg.socketregistry.server;

import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 * 
 * Changes to this file you must do in coloboration with me(Martin Alexander Thomsen) see license.txt
 * You can freely make your own implementation of the Icommand interface
 */
public interface ICommand {
    public final static String SPACE_SEPERATOR = "___UNIQ_NOT_USED_IN_PATH_NAME___"; //jdbc or socket
    public final static String ATTR_SEPERATOR = ";;;"; //jdbc or socket
    public final static String REG_SEPERATOR = "|||"; //jdbc or socket
    public final static String EQUAL_SEPERATOR = "===";

    public final static String NO_SECURE_KEY_FOUND_ERROR = "No secure key found for ip: ";
    public final static String STATUS_OK = "status===ok";
    
    public final static String TYPE_PARAM = "type"; //jdbc or socket
    public final static String LOOKUP_CMD = "lookup";
    
    public final static String LOOKUP_TYPE_PARAM = "lookuptype";
    
    public final static String LOOKUP_ALL = "lookupAll";
    public final static String LOOKUP_BY_DOMAIN = "lookupByDomain";
    public final static String LOOKUP_BY_SERVICE = "lookupByService";
    public final static String LOOKUP_BY_DOMAIN_AND_SERVICE = "lookupByDomainAndService";

    public final static String REGISTER_CMD = "register";

    public final static String DOMAIN_NAME_PARAM = "domainname";
    public final static String SERVICE_NAME_PARAM = "servicename";

    public final static String TYPE_SOCKET = "socket";
    public final static String TYPE_PARAM_SOCKET_PORT = "port";
    public final static String TYPE_PARAM_SOCKET_IP = "ip";

    public final static String TYPE_JDBC = "jdbc";
    public final static String TYPE_PARAM_JDBC_DRIVER = "driver";
    public final static String TYPE_PARAM_JDBC_URL = "url";
    public final static String TYPE_PARAM_JDBC_USERNAME = "username";
    public final static String TYPE_PARAM_JDBC_PASSWORD = "password";

    public String execute(String clientSocketIP, Map<String,String> attributes) throws Exception;
}
