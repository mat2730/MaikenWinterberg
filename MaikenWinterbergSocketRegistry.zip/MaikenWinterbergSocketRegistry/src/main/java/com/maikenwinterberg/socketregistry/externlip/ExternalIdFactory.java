/*
 * Martin Alexander Thomsen den 23 August 2024
 */
package com.maikenwinterberg.socketregistry.externlip;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class ExternalIdFactory {

    private static IExternalId EXTERNAL_ID;

    public static IExternalId newInstance() {
        if (EXTERNAL_ID == null) {
            EXTERNAL_ID = new WrapperExternalIdImpl();
        }
        return EXTERNAL_ID;
    }
}
