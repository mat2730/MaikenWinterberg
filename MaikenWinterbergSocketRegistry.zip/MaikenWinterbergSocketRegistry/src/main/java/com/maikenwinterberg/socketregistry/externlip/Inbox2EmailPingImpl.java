/*
 * Martin Alexander Thomsen den 23 August 2024
 */
package com.maikenwinterberg.socketregistry.externlip;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.security.cert.CertificateException;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509ExtendedTrustManager;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * https://maikenwinterberg.com:8090/ping?ping=externalIp
 */
public class Inbox2EmailPingImpl implements IExternalId {

    private static String EXTERNAL_ID = null;
    private static Long time;

    @Override
    public void updateExternalId() throws Exception {
        trustAllHosts();
        if (time == null || (System.currentTimeMillis() - time) > 60000) {
            System.out.println("looking up externalID");
            URL whatismyip = new URL("https://maikenwinterberg.com:8090/ping?ping=externalIp");
            URLConnection conn = whatismyip.openConnection();
            if (conn instanceof HttpsURLConnection) {
                HttpsURLConnection conn1 = (HttpsURLConnection) whatismyip.openConnection();
                conn1.setHostnameVerifier((String hostname, SSLSession session) -> true);

                BufferedReader in = new BufferedReader(new InputStreamReader(conn1.getInputStream()));
                //whatismyip.openStream()));
                EXTERNAL_ID = in.readLine(); //you get the IP as a String
                System.out.println("externalID=" + EXTERNAL_ID);
                time = System.currentTimeMillis();
            }
        }
    }

    @Override
    public String getExternalId() {
        return EXTERNAL_ID;
    }

    public static void trustAllHosts() {
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{
                new X509ExtendedTrustManager() {
                    @Override
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }

                    @Override
                    public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                    }

                    @Override
                    public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                    }

                    @Override
                    public void checkClientTrusted(java.security.cert.X509Certificate[] xcs, String string, Socket socket) throws CertificateException {
                    }

                    @Override
                    public void checkServerTrusted(java.security.cert.X509Certificate[] xcs, String string, Socket socket) throws CertificateException {
                    }

                    @Override
                    public void checkClientTrusted(java.security.cert.X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException {
                    }

                    @Override
                    public void checkServerTrusted(java.security.cert.X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException {
                    }
                }
            };

            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            // Create all-trusting host name verifier
            HostnameVerifier allHostsValid = new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };
            // Install the all-trusting host verifier
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //test
    public static void main(String arg[]) throws Exception{
        new Inbox2EmailPingImpl().updateExternalId();
    }
}
