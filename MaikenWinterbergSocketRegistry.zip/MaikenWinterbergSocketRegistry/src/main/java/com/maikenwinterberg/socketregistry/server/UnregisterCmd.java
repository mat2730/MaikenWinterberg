/*
 * Martin Alexander Thomsen den 1 Juli 2024
 */
package com.maikenwinterberg.socketregistry.server;

import java.util.Map;
import com.maikenwinterberg.socketregistry.persistence.PersistenceFactory;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 * 
 * Changes to this file you must do in coloboration with me(Martin Alexander Thomsen) see license.txt
 * You can freely make your own commands
 */
public class UnregisterCmd implements ICommand {

    public static final String DOMAIN_KEY = "domain.";
    public static final String SERVICE_KEY = "service.";

    @Override
    public String execute(String clientSocketIP, Map attributes) throws Exception {
        return PersistenceFactory.getRegistryDB().unRegister(clientSocketIP, attributes);
    }
}
