/*
 * Martin Alexander Thomsen den 3 August 2024
 */
package com.maikenwinterberg.socketregistry.api;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class SubscriptionRegistration extends AbstractRegisration {

    private final String registryIp;
    private final String registryPort;

    public SubscriptionRegistration(String registryIp, String registryPort) {
        this.registryIp = registryIp;
        this.registryPort = registryPort;
    }

    public String getRegistryIp() {
        return registryIp;
    }

    public String getRegistryPort() {
        return registryPort;
    }
}
