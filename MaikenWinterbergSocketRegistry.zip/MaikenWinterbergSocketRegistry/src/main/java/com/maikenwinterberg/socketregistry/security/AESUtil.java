/*
 * Martin Alexander Thomsen den 2 Juli 2024
 */
package com.maikenwinterberg.socketregistry.security;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 * @see doc/alfInSSL.pdf
 *
 * inspiration from: https://www.baeldung.com/java-aes-encryption-decryption
 *
 * fix: When I use the code from baeldung over a socket connection I need to add
 * chars-in the beginning of the text
 */
class AESUtil {

    //fix: the encryption do not work properly over a socket connection with jdk 17. Therefore, I insert a dummy string.
    //@see doc/alfInSSL.pdf
    public static final String DUMMY_STRING = "XXXXXXXXXXXXXXXX;;;";
    public static final int NUMBER_OF_DUMMY_BYTES = 16;
    
    public static final boolean DEBUG = false;
    private final static Map<Object, SecretKey> PROJECT_KEYS = new HashMap();
    private static IvParameterSpec projectParivameterSpec;

    private static byte[] encrypt(String algorithm, byte[] input, SecretKey key,
            IvParameterSpec iv) throws Exception {
        Cipher cipher = Cipher.getInstance(algorithm);
        cipher.init(Cipher.ENCRYPT_MODE, key, iv);
        byte[] cipherText = cipher.doFinal(input);
        //return cipherText;
        return Base64.encodeBase64(cipherText);
    }

    private static byte[] decrypt(String algorithm, byte[] cipherText, SecretKey key,
            IvParameterSpec iv) throws Exception {
        Cipher cipher = Cipher.getInstance(algorithm);
        cipher.init(Cipher.DECRYPT_MODE, key, iv);
        byte[] bytes = cipher.doFinal(Base64.decodeBase64(cipherText));
        //byte[] bytes = cipher.doFinal(cipherText);
        return bytes;
    }

    private static IvParameterSpec generateIv() {
        byte[] iv = new byte[NUMBER_OF_DUMMY_BYTES];
        new SecureRandom().nextBytes(iv);
        return new IvParameterSpec(iv);
    }

    private static SecretKey generateKey(int n) throws Exception {
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(n);
        SecretKey key = keyGenerator.generateKey();
        return key;
    }

    private static SecretKey getKeyFromPassword(String password, String salt)
            throws Exception {
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec(password.toCharArray(), salt.getBytes(), 65536, 256);
        SecretKey secret = new SecretKeySpec(factory.generateSecret(spec)
                .getEncoded(), "AES");
        return secret;
    }

    private static IvParameterSpec getProjectParivameterSpec() throws Exception {
        File keyFile = new File("/config/securityConfig/dontTouchMeSecurity.obj");
        if (projectParivameterSpec == null) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(keyFile))) {
                projectParivameterSpec = (IvParameterSpec) ois.readObject();
            } catch (Exception ex) {
            }
        }
        if (projectParivameterSpec == null) {
            projectParivameterSpec = AESUtil.generateIv();
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(keyFile))) {
               // oos.writeObject(projectParivameterSpec);
            } catch (Exception ex) {
            }
        }
        return projectParivameterSpec;
    }

    public static String simpleEncrypt(Object objectKey, String input) throws Exception {
        SecretKey key = getProjectKey(objectKey);
        IvParameterSpec ivParameterSpec = getProjectParivameterSpec();
        String algorithm = "AES/CBC/PKCS5Padding";
        //fix: the encrypting do not work properly over a socket connetion. Therefore, I insert a dummy string.
        if (DUMMY_STRING != null) {
            input = DUMMY_STRING + input;
        }
        byte[] cipherText = encrypt(algorithm, input.getBytes("utf-8"), key, ivParameterSpec);
        return new String(cipherText, "utf-8");
    }

    public static String simpleDecrypt(Object objectKey, String cipherText) throws Exception {
        SecretKey key = getProjectKey(objectKey);
        IvParameterSpec ivParameterSpec = getProjectParivameterSpec();
        String algorithm = "AES/CBC/PKCS5Padding";
        byte[] plainTextAsBytes = decrypt(algorithm, cipherText.getBytes("utf-8"), key, ivParameterSpec);
        String plainText = new String(plainTextAsBytes, "utf-8");
        if (AESUtil.DUMMY_STRING != null) {
            try {
                //the fist NUMBER_OF_DUMMY_BYTES bytes are crap over a socket connection
                int index = plainText.indexOf(";;;");
                if (index != -1) {
                    plainText = plainText.substring(index + 3);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return plainText;
    }

    public static byte[] simpleDecrypt(Object objectKey, byte[] cipherText) throws Exception {
        SecretKey key = getProjectKey(objectKey);
        IvParameterSpec ivParameterSpec = getProjectParivameterSpec();
        String algorithm = "AES/CBC/PKCS5Padding";
        byte[] plainText = decrypt(algorithm, cipherText, key, ivParameterSpec);
        if (DUMMY_STRING != null) {
            plainText = Arrays.copyOfRange(plainText, NUMBER_OF_DUMMY_BYTES, plainText.length);
        }
        return plainText;
    }

    public static byte[] simpleEncrypt(Object objectKey, byte[] input) throws Exception {
        if (DUMMY_STRING != null) {
            byte[] DUMMY_ARRAY = new byte[NUMBER_OF_DUMMY_BYTES];
            byte[] result = new byte[DUMMY_ARRAY.length + input.length];
            System.arraycopy(DUMMY_ARRAY, 0, result, 0, DUMMY_ARRAY.length);
            System.arraycopy(input, 0, result, DUMMY_ARRAY.length, input.length);
            input = result;
        }
        SecretKey key = getProjectKey(objectKey);
        IvParameterSpec ivParameterSpec = getProjectParivameterSpec();
        String algorithm = "AES/CBC/PKCS5Padding";
        //fix: the encrypting do not work properly over a socket connetion. Therefore, I insert a dummy string.
        byte[] cipherText = encrypt(algorithm, input, key, ivParameterSpec);
        return cipherText;
    }

    public static SecretKey getProjectKey(Object keyObject) throws Exception {
        SecretKey projectKey = PROJECT_KEYS.get(keyObject);
        if (projectKey == null) {
            projectKey = generateKey(128);
            PROJECT_KEYS.put(keyObject, projectKey);
            System.out.println("generating SecretKey: " + projectKey + ", keyObject=" + keyObject + ", keyObject.hashCode=" + keyObject.hashCode());
        }
        return projectKey;
    }

    public static void setProjectKey(Object keyObject, SecretKey secretKey) {
        PROJECT_KEYS.put(keyObject, secretKey);
    }

    public static String toBase64(SecretKey key) {
        String base64 = Base64.encodeBase64String(key.getEncoded());
        return base64;
    }

    public static SecretKey fromBase64(String base64) throws Exception {
        byte[] encodedKey = Base64.decodeBase64(base64);
        SecretKey originalKey = new SecretKeySpec(encodedKey, 0, encodedKey.length, "AES");
        return originalKey;
    }

    public static SecretKey fromBytes(byte[] bytes) throws Exception {
        SecretKey originalKey = new SecretKeySpec(bytes, 0, bytes.length, "AES");
        return originalKey;
    }

    //test
    public static void main(String arg[]) throws Exception {
        String cipherText = AESUtil.simpleEncrypt("P1", "cmd=register;domainName=maikenwinterberg.com;serviceName=MariaDB1;type=jdbc;driver=org.mariadb.jdbc.Driver;url=jdbc:mariadb://localhost:3306/project1;username=dbusername;password=xx");
        String plainText = AESUtil.simpleDecrypt("P1", cipherText);
        String base64 = toBase64(PROJECT_KEYS.get("P1"));

        System.out.println(cipherText);
        System.out.println(plainText);
        PROJECT_KEYS.put("P1", fromBase64(base64));
        cipherText = AESUtil.simpleEncrypt("P1", "cmd=register;domainName=maikenwinterberg.com;serviceName=MariaDB1;type=jdbc;driver=org.mariadb.jdbc.Driver;url=jdbc:mariadb://localhost:3306/project1;username=dbusername;password=xx");
        plainText = AESUtil.simpleDecrypt("P1", cipherText);
        System.out.println(cipherText);
        System.out.println(plainText);

    }
}
