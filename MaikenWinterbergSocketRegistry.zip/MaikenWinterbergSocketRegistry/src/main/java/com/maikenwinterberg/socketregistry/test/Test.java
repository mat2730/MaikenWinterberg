/*
 * Martin Alexander Thomsen den 29 August 2024
 */
package com.maikenwinterberg.socketregistry.test;

import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import com.maikenwinterberg.socketregistry.api.ClientRegistryAddress;
import com.maikenwinterberg.socketregistry.api.RegistryConnectionFactory;
import com.maikenwinterberg.socketregistry.api.SocketRegistration;
import com.maikenwinterberg.security.RegistrySecurity;
import java.net.Socket;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class Test {

    public static void main(String arg[]) throws Exception {
        //init
        String securityImpl = "com.maikenwinterberg.socketregistry.security.StaticRegistrySecurity";
        String publicKeyAsBase64 = RegistrySecurity.toBase64(securityImpl, RegistrySecurity.getKeyPair(securityImpl, Test.class, true).getPublic());
        ClientRegistry clientRegistry = ClientRegistry.getRegistryInstance("localhost", "localhost", 4554, true, false);
        //register
        ClientRegistryAddress registryAddress = clientRegistry.registerSocket("localhost", "fileReciever", "1", "testlocalhost", "4445", publicKeyAsBase64, securityImpl);
        if (registryAddress != null) {
            System.out.println("completed");
        } else {
            System.out.println("error");
        }
        //lookup
        SocketRegistration reg = RegistryConnectionFactory.getValidSocketRegistration(clientRegistry, "testlocalhost", "fileReceiver");
        if (reg != null) {
            Socket s = reg.getSocket();
        } else {
            System.out.println("error. no registration");
        }
        //your socket programme comes next.
    }
}
