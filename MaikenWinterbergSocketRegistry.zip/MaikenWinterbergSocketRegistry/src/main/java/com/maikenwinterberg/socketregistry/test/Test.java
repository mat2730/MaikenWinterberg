/*
 * Martin Alexander Thomsen den 29 August 2024
 */
package com.maikenwinterberg.socketregistry.test;

import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import com.maikenwinterberg.socketregistry.api.ClientRegistryAddress;
import com.maikenwinterberg.socketregistry.api.RegistryConnectionFactory;
import com.maikenwinterberg.socketregistry.api.SocketRegistration;
import com.maikenwinterberg.socketregistry.security.RegistrySecurity;
import java.net.Socket;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class Test {

    public static void main(String arg[]) throws Exception {
        //init
        String securityImpl = "com.maikenwinterberg.socketregistry.security.StaticRegistrySecurity";
        String publicKeyAsBase64 = RegistrySecurity.toBase64(securityImpl, RegistrySecurity.getKeyPair(securityImpl, Test.class).getPublic());
        ClientRegistry clientRegistry = ClientRegistry.getRegistryInstance("localhost", "localhost", 4554, true, false);
        //register
        ClientRegistryAddress registryAddress = clientRegistry.registerSocket("localhost", "fileReciever", "1", "localhost", "4445", publicKeyAsBase64, securityImpl);
        if (registryAddress != null) {
            System.out.println("completed");
        } else {
            System.out.println("error");
        }
        //lookup
        SocketRegistration reg = RegistryConnectionFactory.getValidSocketRegistration(clientRegistry, "localhost", "fileReceiver");
        Socket s = reg.getSocket();
        //your socket programme comes next.
    }
}
