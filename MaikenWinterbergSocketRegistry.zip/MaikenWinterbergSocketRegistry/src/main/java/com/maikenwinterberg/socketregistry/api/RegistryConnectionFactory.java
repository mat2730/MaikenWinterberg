/*
 * Martin Alexander Thomsen den 2 Juli 2024
 */
package com.maikenwinterberg.socketregistry.api;

import java.net.Socket;
import java.util.Iterator;
import java.util.List;
import com.maikenwinterberg.socketregistry.server.DomainCheck;
import com.maikenwinterberg.socketregistry.server.Registry;
import java.net.InetSocketAddress;
import java.net.SocketAddress;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class RegistryConnectionFactory {

    public synchronized static SocketRegistration getFirstValidSocketRegistration(List<ClientRegistry> registryList, String domainNameOfClient, String lookupDomainName, String serviceName) throws Exception {
        //TODO use threads and mix result connect to newst registration
        for (Iterator<ClientRegistry> i = registryList.iterator(); i.hasNext();) {
            try {
                ClientRegistry cr = i.next();
                SocketRegistration r = getValidSocketRegistration(cr, lookupDomainName, serviceName);
                if (r != null) {
                    //todo connect to latest registration
                    return r;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                //ignore
            }
        }
        return null;
    }

    public synchronized static SocketRegistration getValidSocketRegistration(ClientRegistry registry, String lookupDomainName, String serviceName) throws Exception {
        try {
            int socketTimeout = 30000;
            try {
                socketTimeout = Integer.parseInt(Registry.getProperty("sockettimeout"));
            } catch (Exception ex) {
            }

            List registrations = registry.lookup(ClientRegistry.TYPE.socket, lookupDomainName, serviceName);
            for (Iterator i = registrations.iterator(); i.hasNext();) {
                try {
                    Object reg = i.next();
                    if (reg instanceof SocketRegistration) {
                        SocketRegistration r = (SocketRegistration) reg;
                        String ip = r.getIp();
                        if (DomainCheck.getExternalId() != null) {
                            System.out.println("comparing " + ip + " with " + DomainCheck.getExternalId());
                            if (ip.trim().equalsIgnoreCase(DomainCheck.getExternalId())) {
                                ip = "localhost";
                            }
                        }
                        System.out.println("connection to " + ip + ":" + r.getPort() + "...");
                        //Socket socket = new Socket(ip, r.getPort());
                        Socket socket = new Socket();
                        SocketAddress socketAddress = new InetSocketAddress(ip, r.getPort());
                        socket.connect(socketAddress, socketTimeout);

                        if (!socket.isConnected()) {
                            System.out.println("no connection to " + ip + ":" + r.getPort());
                            continue;
                        }
                        System.out.println("connected to " + ip + ":" + r.getPort());
                        r.setSocket(socket);
                        return r;
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
}
