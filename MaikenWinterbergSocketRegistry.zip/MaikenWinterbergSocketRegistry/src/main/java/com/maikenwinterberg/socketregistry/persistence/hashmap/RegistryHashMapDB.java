/*
 * Martin Alexander Thomsen den 30 Juni 2024
 */
package com.maikenwinterberg.socketregistry.persistence.hashmap;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import com.maikenwinterberg.socketregistry.persistence.AbstractRegistryDB;
import com.maikenwinterberg.socketregistry.persistence.jdbc.RegistryJDBCDB;
import static com.maikenwinterberg.socketregistry.persistence.jdbc.RegistryJDBCDB.MAXFETCHSIZE;
import com.maikenwinterberg.socketregistry.server.ICommand;
import com.maikenwinterberg.socketregistry.server.RegisterCmd;
import java.util.IdentityHashMap;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 * @see doc/takeNanna.pdf (I changed from TreeMashMap to IdentityHashMap)
 */
public class RegistryHashMapDB extends AbstractRegistryDB {

    private static final Map REGISTRATIONS_OF_TYPE_MAP = new HashMap();
    private static final boolean DEBUG = false;
    public static final String DOMAIN_KEY = "domain.";
    public static final String SERVICE_KEY = "service.";

    private static Map getRegistryMap(String type) {
        Map m = (Map) REGISTRATIONS_OF_TYPE_MAP.get(type.toLowerCase());
        if (m == null) {
            m = new HashMap();
            REGISTRATIONS_OF_TYPE_MAP.put(type.toLowerCase(), m);
        }
        return m;
    }

    @Override
    public void cleanUp() {
        try {
            //TODO double check
            for (Iterator k = REGISTRATIONS_OF_TYPE_MAP.keySet().iterator(); k.hasNext();) {
                Object key = k.next();
                Object cmdHashMap = REGISTRATIONS_OF_TYPE_MAP.get(key);
                if (cmdHashMap instanceof Map) {
                    Map cmdmap = (Map) cmdHashMap;
                    for (Iterator hi = cmdmap.keySet().iterator(); hi.hasNext();) {
                        Object keyLevel1 = hi.next();
                        Object cacheLevel1 = cmdmap.get(keyLevel1);
                        if (cacheLevel1 == null) {
                            continue;
                        }
                        if (cacheLevel1 instanceof HashMap) {
                            //for all attributes in hashMap
                            for (Iterator hi2 = ((Map) cacheLevel1).keySet().iterator(); hi2.hasNext();) {
                                Object keyLevel2 = hi2.next();
                                Object cacheLevel2 = ((Map) cacheLevel1).get(keyLevel2);
                                Long timestamp = (Long) ((HashMap) cacheLevel2).get("registration_timestamp");
                                if (timestamp != null) {
                                    if (System.currentTimeMillis() - timestamp > RegistryJDBCDB.CLEANUP_TIME) {
                                        ((Map) cacheLevel2).remove(keyLevel2);
                                    }
                                }
                            }
                        } else {
                            //identifier
                            for (Iterator hi2 = ((Map) cacheLevel1).keySet().iterator(); hi2.hasNext();) {
                                Object keyLevel2 = hi2.next();
                                Object cacheLevel2 = ((Map) cacheLevel1).get(keyLevel2);
                                for (Iterator hi3 = ((Map) cacheLevel2).keySet().iterator(); hi3.hasNext();) {
                                    Object keyLevel3 = hi3.next();
                                    Object cacheLevel3 = ((Map) cacheLevel2).get(keyLevel3);
                                    //for all attributes
                                    for (Iterator hi4 = ((Map) cacheLevel3).keySet().iterator(); hi4.hasNext();) {
                                        Object keyLevel4 = hi4.next();
                                        Object cacheLevel4 = ((Map) cacheLevel3).get(keyLevel4);
                                        Long timestamp = (Long) ((HashMap) cacheLevel4).get("registration_timestamp");
                                        if (timestamp != null) {
                                            if (System.currentTimeMillis() - timestamp > RegistryJDBCDB.CLEANUP_TIME) {
                                                ((Map) cacheLevel4).remove(keyLevel4);
                                            }
                                        }
                                    }
                                }

                            }
                        }
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public synchronized String register(String socketClientIP, Map<String, String> attributes) throws Exception {
        if (attributes == null || !(attributes instanceof HashMap)) {
            throw new IllegalStateException("Invalid attributes. Must be a HashMap");
        }
        attributes.put("socket_client_ip", socketClientIP);
        String cmdType = attributes.get(ICommand.TYPE_PARAM);
        String domainName = attributes.get(ICommand.DOMAIN_NAME_PARAM);
        String serviceName = attributes.get(ICommand.SERVICE_NAME_PARAM);
        long timestamp = System.currentTimeMillis();
        attributes.put("registration_timestamp", "" + timestamp);
        Map registryMap = getRegistryMap(cmdType);
        String key = domainName.toLowerCase() + "." + serviceName.toLowerCase();
        Map doomainCommands = (Map) registryMap.get(DOMAIN_KEY + domainName.toLowerCase());
        if (doomainCommands == null) {
            doomainCommands = new IdentityHashMap(); //TreeMap do not traverse new TreeMap();
            registryMap.put(DOMAIN_KEY + domainName.toLowerCase(), doomainCommands);
        }
        doomainCommands.put(key, attributes);
        Map serviceCommands = (Map) registryMap.get(SERVICE_KEY + serviceName.toLowerCase());
        if (serviceCommands == null) {
            serviceCommands = new IdentityHashMap(); //TreeMap do not traverse new TreeMap();
            registryMap.put(SERVICE_KEY + serviceName.toLowerCase(), serviceCommands);
        }
        serviceCommands.put(key, attributes);
        registryMap.put(key, attributes);

        return "status" + ICommand.EQUAL_SEPERATOR + "ok" + ICommand.ATTR_SEPERATOR + "timestamp" + ICommand.EQUAL_SEPERATOR + timestamp;
    }

    @Override
    public synchronized String unRegister(String socketClientIP, Map<String, String> attributes) throws Exception {
        String cmdType = attributes.get(ICommand.TYPE_PARAM);
        String domainName = attributes.get(ICommand.DOMAIN_NAME_PARAM);
        String serviceName = attributes.get(ICommand.SERVICE_NAME_PARAM);

        Map registryMap = getRegistryMap(cmdType);
        String status;
        String errorMessage = null;
        if (serviceName != null) {
            boolean ok = unregister(registryMap, domainName, serviceName);
            if (ok) {
                status = "ok";
            } else {
                status = "error";
            }
        } else {
            status = "error";
            errorMessage = "Servicename is missing";
            //delete all service of domain
            //@see doc/takeNanna.pdf
            /* cannot traverse TreeMap - BUG */
            Map domainMap = (Map) registryMap.get(DOMAIN_KEY + domainName.toLowerCase());
            if (domainMap != null) {
                for (Iterator i = domainMap.values().iterator(); i.hasNext();) {
                    Map values = (Map) i.next();
                    serviceName = (String) values.get("servicename");
                    unregister(registryMap, domainName, serviceName);
                }
            }
        }
        StringBuilder builder = new StringBuilder();
        builder.append("status" + ICommand.EQUAL_SEPERATOR).append(status).append(ICommand.ATTR_SEPERATOR + "timestamp" + ICommand.EQUAL_SEPERATOR).append(System.currentTimeMillis());
        if (errorMessage != null) {
            builder.append(ICommand.ATTR_SEPERATOR + "errormessage" + ICommand.EQUAL_SEPERATOR).append(errorMessage);
        }
        return builder.toString();
    }

    private synchronized boolean unregister(Map registryMap, String domainName, String serviceName) {
        String key = domainName.toLowerCase() + "." + serviceName.toLowerCase();
        Object obj2Remove = registryMap.get(key);
        if (obj2Remove == null) {
            return false;
        }
        Map domainMap = (Map) registryMap.get(DOMAIN_KEY + domainName.toLowerCase());
        if (domainMap != null) {
            domainMap.remove(key, obj2Remove);
        }
        Map serviceMap = (Map) registryMap.get(SERVICE_KEY + serviceName.toLowerCase());
        if (serviceMap != null) {
            serviceMap.remove(key, obj2Remove);
        }
        registryMap.remove(key);
        return true;
    }

    @Override
    public synchronized String lookup(String socketClientIP, Map<String, String> attributes) throws Exception {
        String cmdType = attributes.get(ICommand.TYPE_PARAM);
        String serviceName = attributes.get(ICommand.SERVICE_NAME_PARAM);
        String lookupType;
        String lookupDomainName = (String) attributes.get("lookupdomainname");
        String key = null;
        String fetchsize = attributes.get("fetchsize");
        int fetchsizeInt;
        try {
            fetchsizeInt = Integer.parseInt(fetchsize);
        } catch (Exception ex) {
            fetchsizeInt = MAXFETCHSIZE;
        }
        if (MAXFETCHSIZE != 0 && fetchsizeInt > MAXFETCHSIZE) {
            fetchsizeInt = MAXFETCHSIZE;
        }
        String offset = attributes.get("offset");
        int offsetAsInt;
        try {
            offsetAsInt = Integer.parseInt(offset);
        } catch (Exception ex) {
            offsetAsInt = 0;
        }

        if ((serviceName == null || serviceName.trim().isEmpty()) && (lookupDomainName == null || lookupDomainName.trim().isEmpty())) {
            lookupType = ICommand.LOOKUP_ALL;
        } else if ((serviceName == null || serviceName.trim().isEmpty())) {
            lookupType = ICommand.LOOKUP_BY_DOMAIN;
        } else if (lookupDomainName == null || lookupDomainName.trim().isEmpty()) {
            lookupType = ICommand.LOOKUP_BY_SERVICE;
        } else {
            lookupType = ICommand.LOOKUP_BY_DOMAIN_AND_SERVICE;
        }

        if (cmdType == null) {
            cmdType = ICommand.TYPE_SOCKET;
        }
        Map registryMap = getRegistryMap(cmdType);
        if (DEBUG) {
            System.out.println("lookup: " + cmdType + " registryMap " + registryMap.getClass().getName());
        }
        if (lookupType.equalsIgnoreCase(ICommand.LOOKUP_ALL)) {
            key = null;
        } else if (lookupType.equalsIgnoreCase(ICommand.LOOKUP_BY_DOMAIN)) {
            key = RegisterCmd.DOMAIN_KEY + lookupDomainName.toLowerCase();
        } else if (lookupType.equalsIgnoreCase(ICommand.LOOKUP_BY_SERVICE)) {
            key = RegisterCmd.SERVICE_KEY + serviceName.toLowerCase();
        } else if (lookupType.equalsIgnoreCase(ICommand.LOOKUP_BY_DOMAIN_AND_SERVICE)) {
            Map lookupCommand = (Map) registryMap.get(lookupDomainName.toLowerCase() + "." + serviceName.toLowerCase());
            return getCommandAsString(lookupCommand);
        }
        if (DEBUG) {
            System.out.println("lookuptype " + lookupType + ", key " + key);
        }
        List rcommands;
        if (key != null) {
            Map map = (Map) registryMap.get(key);
            if (map != null) {
                rcommands = new LinkedList(map.values());
            } else {
                rcommands = new LinkedList();
            }
        } else {
            rcommands = new LinkedList();
            for (Iterator i = registryMap.keySet().iterator(); i.hasNext();) {
                key = (String) i.next();
                Object obj = registryMap.get(key);
                if (obj instanceof HashMap) {
                    if (DEBUG) {
                        System.out.println("adding to commandMap " + key);
                    }
                    rcommands.add(obj);
                }
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (DEBUG) {
            System.out.println("size of commandMap " + rcommands.size());
        }
        int counter = 0;
        while (true) {
            if (counter == offsetAsInt + fetchsizeInt) {
                break;
            }
            Map command = (Map) rcommands.get(counter + offsetAsInt);
            String commandAsString = getCommandAsString(command);
            stringBuilder.append(commandAsString);
            if (counter + 1 < offsetAsInt + fetchsizeInt) {
                stringBuilder.append(ICommand.REG_SEPERATOR);
            }
            counter++;
        }
        return stringBuilder.toString();
    }
}
