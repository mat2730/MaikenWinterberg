/*
 * Martin Alexander Thomsen den 1 Juli 2024
 */
package com.maikenwinterberg.socketregistry.api;

import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class SocketRegistration extends AbstractRegisration {

    private String ip;
    private String port;

    private final Map<Socket, Integer> counts = new HashMap();
    private final Stack<Socket> socketPool = new Stack();

    public synchronized void setSocket(Socket socket) throws Exception {
        counts.put(socket, 0);
        socketPool.push(socket);
    }

    public synchronized Socket getSocket() throws Exception {
        Socket socket = null;
        try {
            socket = socketPool.pop();
        } catch (Exception ex) {
        }
        if (socket != null) {
            int count = counts.get(socket);
            counts.put(socket, count++);
            return socket;
        } else {
            socket = new Socket(ip, Integer.parseInt(port));
            counts.put(socket, 1);
            return socket;
        }
    }

    public synchronized void releaseSocket(Socket socket) {
        socketPool.push(socket);
    }

    public boolean publicKeySent(Socket socket) {
        int count = counts.get(socket);
        return count == 1;
    }

    public synchronized void close() {
        try {
            for (Socket socket : socketPool) {
                if (socket != null) {
                    socket.close();
                    socket = null;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getPort() {
        try {
            return Integer.parseInt(port);
        } catch (Exception ex) {
            return -1;
        }
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getBase64PublicKey() {
        //this method will only retturn the public key at the first call
        return (String) this.attributes.get("public_key");
    }

    public String getSecurityImpl() {
        String impl = (String) attributes.get("security_impl");
        return impl;
    }
}
