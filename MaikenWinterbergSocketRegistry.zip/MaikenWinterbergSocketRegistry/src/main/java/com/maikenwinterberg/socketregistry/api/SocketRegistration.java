/*
 * Martin Alexander Thomsen den 1 Juli 2024
 */
package com.maikenwinterberg.socketregistry.api;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class SocketRegistration extends AbstractRegisration {

    private boolean isNew;
    private String ip;
    private String port;

    private int count;
    private DataOutputStream dos;
    private DataInputStream dis;
    private Socket socket;

    public void setSocket(Socket socket) throws Exception {
        this.isNew = true;
        this.socket = socket;
        dos = new DataOutputStream(socket.getOutputStream());
        dis = new DataInputStream(socket.getInputStream());
    }

    public boolean isSocketValid() {
        if (socket == null || socket.isClosed()) {
            return false;
        }
        return true;
    }

    public void close() {
        try {
            if (socket != null) {
                dos.close();
                dis.close();
                socket.close();
                socket = null;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        count = 0;
    }

    public int getCount() {
        return count;
    }

    public DataOutputStream getDataOutputStream() throws Exception {
        count++;
        return dos;
    }

    public DataInputStream getDataInputStream() throws Exception {
        return dis;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getPort() {
        return Integer.parseInt(port);
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getBase64PublicKey() {
        //this method will only retturn the public key at the first call
        if (isNew) {
            isNew = false;
            return (String) this.attributes.get("public_key");
        }
        return null;
    }

    public String getSecurityImpl() {
        String impl = (String) attributes.get("security_impl");
        return impl;
    }
}
