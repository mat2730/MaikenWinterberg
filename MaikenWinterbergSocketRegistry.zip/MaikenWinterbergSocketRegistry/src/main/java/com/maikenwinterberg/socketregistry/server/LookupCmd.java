/*
 * Martin Alexander Thomsen den 30 Juni 2024
 */
package com.maikenwinterberg.socketregistry.server;

import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import java.util.Map;
import com.maikenwinterberg.socketregistry.persistence.PersistenceFactory;
import java.net.InetAddress;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * Changes to this file you must do in coloboration with me(Martin Alexander
 * Thomsen) see license.txt You can freely make your own commands
 */
public class LookupCmd implements ICommand {

    @Override
    public String execute(String clientSocketIP, Map<String, String> attributes) throws Exception {
        String type = (String) attributes.get(ICommand.TYPE_PARAM);
        String lookupDomainName = (String) attributes.get("lookupdomainname");
        //not for subsritpion lookup
        if ((type == null || !type.equals(ClientRegistry.TYPE.subscription.toString())) && lookupDomainName == null) {
            boolean approved = false;
            try {
                String domainName = (String) attributes.get(ICommand.DOMAIN_NAME_PARAM);
                if (domainName != null) {
                    if (domainName.toLowerCase().contains("documentnetwork.com") || domainName.toLowerCase().contains("maikenwinterberg.com")) {
                        approved = true;
                    } else {
                        InetAddress inetAddress = InetAddress.getByName(domainName);
                        if (inetAddress != null) {
                            if (DomainCheck.getExternalId() == null) {
                                DomainCheck.updateExternalID();
                            }
                            if (inetAddress.toString().equals(DomainCheck.getExternalId())) {
                                approved = true;
                            }
                        }
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            if (!approved) {
                throw new SecurityException("I you want to query all domains you must come from ip: " + DomainCheck.getExternalId());
            }
        }
        String returnString = null;
        try {
            returnString = PersistenceFactory.getRegistryDB().lookup(clientSocketIP, attributes);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return returnString;
    }
}
