/*
 * Martin Alexander Thomsen den 10 Juli 2024
 */
package com.maikenwinterberg.socketregistry.server;

import com.maikenwinterberg.domainname.DomainHandler;
import com.maikenwinterberg.socketregistry.externlip.ExternalIdFactory;
import java.io.BufferedReader;
import java.io.FileReader;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * Changes to this file you must do in coloboration with me(Martin Alexander
 * Thomsen) see license.txt
 */
public class DomainCheck {

    private static final Map<String, Properties> PROPERTIES = new HashMap();

    private static String EXTERNAL_ID = null;

    public static void updateExternalID() {
        try {
            ExternalIdFactory.newInstance().updateExternalId();
            EXTERNAL_ID = ExternalIdFactory.newInstance().getExternalId();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static String getExternalId() {
        return EXTERNAL_ID;
    }

    private static Properties getProperties(String fileName) {
        Properties p = PROPERTIES.get(fileName);
        if (p == null) {
            p = new Properties();
        }
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("#") || line.trim().isEmpty()) {
                    continue;
                }
                p.put(line.toLowerCase(), "");
            }
        } catch (Exception ex) {
            System.out.println("cannot find property file " + fileName);
        }
        return p;
    }

    /*
    public static String updateDefaultDomainNameOnClient(String clientDomainName) throws Exception {
        updateExternalID();
        return getDefaultDomainNameOnClient2(clientDomainName);
    }*/
    public static String getDefaultDomainNameOnClient2(String clientDomainName) throws Exception {
        String hostAddress = DomainHandler.getHostAddress(clientDomainName);
        if (EXTERNAL_ID != null && !EXTERNAL_ID.equalsIgnoreCase(hostAddress)) {
            //invalid domainName use externalId instead
            return EXTERNAL_ID;
        }
        return clientDomainName;
    }

    public static String getDomainNameOnClient(String defaultDomainNameOfClient, String domainName) {
        if (domainName == null || domainName.trim().isEmpty()) {
            return defaultDomainNameOfClient;
        }
        if (domainName.equalsIgnoreCase("localhost") || domainName.equals("127.0.0.1")) {
            return defaultDomainNameOfClient;
        }
        return domainName;
    }

    public static String getLookupDomainName(String lookupDomainName) {
        if (lookupDomainName == null || lookupDomainName.equalsIgnoreCase("localhost") || lookupDomainName.equals("127.0.0.1")) {
            if (EXTERNAL_ID != null) {
                lookupDomainName = EXTERNAL_ID;
            }
        }
        return lookupDomainName;
    }

    public static boolean isAnIPv4(String domainName) {
        if (domainName == null) {
            return false;
        }
        int index1 = 0;
        int index2 = domainName.indexOf(".");
        int count = 0;
        while (true) {
            if (index1 == -1 || index2 == -1) {
                return false;
            }
            try {
                String nr = domainName.substring(index1, index2);
                System.out.println(nr);
                Integer.valueOf(nr);
                count++;
                if (count == 3) {
                    break;
                }
                index1 = index2 + 1;
                index2 = domainName.indexOf(".", index1);
            } catch (NumberFormatException ex) {
                return false;
            }
        }
        try {
            String nr = domainName.substring(index2 + 1);
            if (nr.contains(".")) {
                return false;
            }
            System.out.println(nr);
            Integer.valueOf(nr);
            return true;
        } catch (NumberFormatException ex) {
        }
        return false;
    }

    public static void validateDomainNameOnServer(Properties validDomains, Properties notValidDomains, boolean doNotAcceptIpAsDomainName, String socketClientIP, String domainName) throws Exception {
        if (socketClientIP == null) {
            //this is a command from statup its always approved;
            return;
        }
        if (socketClientIP.equalsIgnoreCase("127.0.0.1")) {
            //localhost is always approved
            return;
        }
        if (EXTERNAL_ID != null && socketClientIP.equalsIgnoreCase(EXTERNAL_ID)) {
            //localhost is always approved
            return;
        }

        if (domainName == null) {
            throw new SecurityException("No client domsocketClientIPainname found");
        }
        if (socketClientIP.equals("34.41.57.110")) {
            //system ip address
            return;
        }
        //test if domain name match socketClientIp
        String hostAddress = DomainHandler.getHostAddress(domainName);
        if (hostAddress == null || !socketClientIP.equalsIgnoreCase(hostAddress)) {
            throw new IllegalStateException("Invalid domainname " + domainName + ". You must come from ip: " + hostAddress + ", your ip is " + socketClientIP);
        }
        if (hostAddress.equals(domainName) && doNotAcceptIpAsDomainName) {
            throw new SecurityException("the domainname " + domainName + " is an IP address. Only valid domainnames are accepted.");
        }
        //DO NOT CHANGE THIS - see license.txt 
        if (domainName.equals("maikenwinterberg.com") || domainName.equals("documentnetwork.com")) {
            //preapproved see license.txt
            return;
        }
        //this is to avoid domains with bad behavior
        if (!validDomains.isEmpty() && validDomains.get(domainName) == null) {
            throw new SecurityException("the domain " + domainName + " is not present in validDomains.cfg");
        }
        if (notValidDomains.get(domainName) != null) {
            throw new SecurityException("the domain " + domainName + " is present in inValidComains.cfg");
        }
        //the idea behind validDomain is for subscriptions, not for the FileSender. I do not wish close groups in general. 
        //I want everyone with good behavaur to be able to send and receive documents to each orther.
        //But it makes sence that you can have subscriptions for a closed group. And it also makes sence that the parent registries have a closed group
        if (!validDomains.isEmpty() && validDomains.get(hostAddress) == null) {
            throw new SecurityException("the domain ip " + hostAddress + " of domain " + domainName + "is not present in validDomains.cfg");
        }
        if (notValidDomains.get(hostAddress) != null) {
            throw new SecurityException("the domain ip " + hostAddress + " of domain " + domainName + " is present in inValidComains.cfg");
        }
    }

    public static void main(String arg[]) {
        System.out.println("is an IP " + isAnIPv4("1.22.1.5"));
        System.out.println("is an IP " + isAnIPv4("1.22.1.2.6"));
        System.out.println("is an IP " + isAnIPv4("1.22.f.7"));
        System.out.println("is an IP " + isAnIPv4("test"));
    }
}
