/*
 * Martin Alexander Thomsen den 4 Juli 2024
 */
package com.maikenwinterberg.socketregistry.security;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import com.maikenwinterberg.socketregistry.server.Registry;
import org.apache.commons.codec.binary.Base64;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * List of pages that gave me inspiration:
 * https://stackoverflow.com/questions/43459993/how-do-i-generate-rsa-key-pair-in-java-in-openssl-format
 * https://www.baeldung.com/java-rsa
 */
class RSAUtil {

    private static final String ENCODING = "iso-8859-1";
    public static Map<Object, KeyPair> KEY_PAIRS = new HashMap();
    private static boolean DEBUG = false;

    public static KeyPair getRSAKeyPar(Object objectKey) throws Exception {
        KeyPair kp = KEY_PAIRS.get(objectKey);
        if (kp != null) {
            //the privateKeyPair is located in memory
            if (DEBUG) {
                System.out.println("KeyPair is located in memory");
            }
            return kp;
        }
        //load keys from config
        /* Det er en dårlig ide at gemme keys i filsystemet. Kan misbruges
        byte[] publicKeyAsBytes = null;
        byte[] privateKeyAsBytes = null;
        try (FileInputStream stream = new FileInputStream(new File("conf/id_rsa.pub"))) {
            byte[] base64AsBytes = stream.readAllBytes();
            publicKeyAsBytes = Base64.getMimeDecoder().decode(new String(base64AsBytes, ENCODING));
        } catch (Exception ex) {
            if (DEBUG) {
                ex.printStackTrace();
            }
        }
        if (publicKeyAsBytes != null) {
            try (FileInputStream stream = new FileInputStream(new File("conf/id_rsa"))) {
                byte[] base64AsBytes = stream.readAllBytes();
                privateKeyAsBytes = Base64.getMimeDecoder().decode(new String(base64AsBytes, ENCODING));
            } catch (Exception ex) {
                if (DEBUG) {
                    ex.printStackTrace();
                }
            }
        }
        if (privateKeyAsBytes != null && publicKeyAsBytes != null) {
            //private and public keys exists
            PublicKey publicKey = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(publicKeyAsBytes));
            PrivateKey privateKey = KeyFactory.getInstance("RSA").generatePrivate(new X509EncodedKeySpec(privateKeyAsBytes));
            kp = new KeyPair(publicKey, privateKey);
            KEY_PAIRS.put(serviceClass, kp);
            if (DEBUG) {
                System.out.println("KeyPair is loaded from file");
            }
            return kp;
        }
         */
        //generate keys
        kp = generateRSAKeyPair();
        KEY_PAIRS.put(objectKey, kp);
        if (DEBUG) {
            System.out.println("A new set of KeyPair is created");
        }
        return kp;
    }

    public static KeyPair generateRSAKeyPair() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        KeyPair kp = kpg.generateKeyPair();
        return kp;
    }

    public static void setRSAKeyPair(Object key, KeyPair kp) {
        KEY_PAIRS.put(key, kp);
    }

    public static String toBase64(PublicKey key) {
        String base64 = Base64.encodeBase64String(key.getEncoded());
        return base64;
    }

    public static PublicKey fromBase64(String base64) throws Exception {
        byte[] keyAsBytes = Base64.decodeBase64(base64);
        PublicKey publicKey = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(keyAsBytes));
        return publicKey;
    }

    public static String encrypt(PublicKey publicKey, byte[] secretMessage) throws Exception {
        Cipher encryptCipher = Cipher.getInstance("RSA");
        encryptCipher.init(Cipher.ENCRYPT_MODE, publicKey);
        //byte[] secretMessageBytes = secretMessage.getBytes(StandardCharsets.UTF_8);
        byte[] encryptedMessageBytes = encryptCipher.doFinal(secretMessage);
        String encodedMessage = Base64.encodeBase64String(encryptedMessageBytes);
        return encodedMessage;
    }

    public static byte[] encrypt2Bytes(PublicKey publicKey, byte[] secretMessage) throws Exception {
        Cipher encryptCipher = Cipher.getInstance("RSA");
        encryptCipher.init(Cipher.ENCRYPT_MODE, publicKey);
        //byte[] secretMessageBytes = secretMessage.getBytes(StandardCharsets.UTF_8);
        byte[] encryptedMessageBytes = encryptCipher.doFinal(secretMessage);
        return encryptedMessageBytes;
        //String encodedMessage = Base64.getEncoder().encodeToString(encryptedMessageBytes);
        //return encodedMessage;
    }

    public static byte[] decrypt(PrivateKey privateKey, String encryptedBase64Message) throws Exception {
        if (DEBUG) {
            System.out.println("decrypt.1");
        }
        Cipher decryptCipher = Cipher.getInstance("RSA");
        if (DEBUG) {
            System.out.println("decrypt.2");
        }
        decryptCipher.init(Cipher.DECRYPT_MODE, privateKey);
        if (DEBUG) {
            System.out.println("decrypt.3");
        }
        byte[] encrypteddMessageBytes = Base64.decodeBase64(encryptedBase64Message);
        if (DEBUG) {
            System.out.println("decrypt.4");
        }
        byte[] decryptedMessageBytes = decryptCipher.doFinal(encrypteddMessageBytes);
        if (DEBUG) {
            System.out.println("decrypt.5");
        }
        //String decryptedMessage = new String(decryptedMessageBytes, StandardCharsets.UTF_8);
        return decryptedMessageBytes;
    }

    public static byte[] decrypt(PrivateKey privateKey, byte[] encrypteddMessageBytes) throws Exception {
        if (DEBUG) {
            System.out.println("decrypt.1");
        }
        Cipher decryptCipher = Cipher.getInstance("RSA");
        if (DEBUG) {
            System.out.println("decrypt.2");
        }
        decryptCipher.init(Cipher.DECRYPT_MODE, privateKey);
        if (DEBUG) {
            System.out.println("decrypt.3");
        }
        byte[] decryptedMessageBytes = decryptCipher.doFinal(encrypteddMessageBytes);
        if (DEBUG) {
            System.out.println("decrypt.5");
        }
        //String decryptedMessage = new String(decryptedMessageBytes, StandardCharsets.UTF_8);
        return decryptedMessageBytes;
    }

    /*test*/
    public static void main(String[] args) throws Exception {
        //enrypt/decrypt tests
        KeyPair kp = getRSAKeyPar(Registry.class.getName());
        byte[] secretMessage = "secret".getBytes("utf-8");
        String encryptedMessage = encrypt(kp.getPublic(), secretMessage);
        System.out.println("encrypted Message 1: " + encryptedMessage);
        System.out.println("decrypted Message 1: " + new String(decrypt(kp.getPrivate(), encryptedMessage), "utf-8"));
        /*
        kp = getRSAKeyPar(Registry.class.getName());
        
        secretMessage = "secret2";
        encryptedMessage = encrypt(kp.getPublic(), secretMessage);
        System.out.println("encrypted Message 2: " + encryptedMessage);
        System.out.println("decrypted Message 2: " + decrypt(kp.getPrivate(), encryptedMessage));
        String base64 = toBase64(kp.getPublic());
        System.out.println(base64);
        PublicKey publicKey = fromBase64(base64);
        System.out.println(publicKey);
        //print keys in standardoutput
        System.out.println("-----BEGIN PRIVATE KEY-----");
        System.out.println(Base64.getMimeEncoder().encodeToString(kp.getPrivate().getEncoded()));
        System.out.println("-----END PRIVATE KEY-----");
        System.out.println("-----BEGIN PUBLIC KEY-----");
        System.out.println(Base64.getMimeEncoder().encodeToString(kp.getPublic().getEncoded()));
        System.out.println("-----END PUBLIC KEY-----");*/
    }
}
