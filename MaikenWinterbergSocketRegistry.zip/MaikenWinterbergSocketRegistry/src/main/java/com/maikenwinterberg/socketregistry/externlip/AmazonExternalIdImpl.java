/*
 * Martin Alexander Thomsen den 23 August 2024
 */
package com.maikenwinterberg.socketregistry.externlip;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class AmazonExternalIdImpl implements IExternalId {

    private static String EXTERNAL_ID = null;
    private static Long time;

    public void updateExternalId() throws Exception {
        try {
            if (time == null || (System.currentTimeMillis() - time) > 60000) {
                //TODO add multiple implementations
                System.out.println("looking up externalID");
                URL whatismyip = new URL("http://checkip.amazonaws.com");
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        whatismyip.openStream()));
                EXTERNAL_ID = in.readLine(); //you get the IP as a String
                System.out.println("externalID=" + EXTERNAL_ID);
                time = System.currentTimeMillis();
            }
        } catch (Exception ex) {
            Thread.sleep(200);
            //TODO add multiple implementations
            System.out.println("looking up externalID");
            URL whatismyip = new URL("http://checkip.amazonaws.com");
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    whatismyip.openStream()));
            EXTERNAL_ID = in.readLine(); //you get the IP as a String
            System.out.println("externalID=" + EXTERNAL_ID);
            time = System.currentTimeMillis();
        }
    }

    @Override
    public String getExternalId() {
        return EXTERNAL_ID;
    }
}
