/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maikenwinterberg.socketregistry.persistence;

import com.maikenwinterberg.socketregistry.persistence.jdbc.RegistryJDBCDB;

/**
 *
 * @author martin
 */
public class CleanUpthread extends Thread {

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(RegistryJDBCDB.CLEANUP_TIME);
                PersistenceFactory.getRegistryDB().cleanUp();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
