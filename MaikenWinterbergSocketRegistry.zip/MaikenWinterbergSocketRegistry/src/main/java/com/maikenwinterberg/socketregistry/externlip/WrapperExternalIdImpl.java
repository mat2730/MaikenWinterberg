/*
 * Martin Alexander Thomsen den 23 August 2024
 */
package com.maikenwinterberg.socketregistry.externlip;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class WrapperExternalIdImpl implements IExternalId {

    private IExternalId INBOX = new Inbox2EmailPingImpl();
    private IExternalId AMAZON = new AmazonExternalIdImpl();

    @Override
    public void updateExternalId() throws Exception {
        try {
            INBOX.updateExternalId();
            if (INBOX.getExternalId() == null || INBOX.getExternalId().equalsIgnoreCase("127.0.0.1")) {
                AMAZON.updateExternalId();
            }
        } catch (Exception ex) {
            AMAZON.updateExternalId();
        }
    }

    @Override
    public String getExternalId() {
        String id = INBOX.getExternalId();
        if (id == null || INBOX.getExternalId().equalsIgnoreCase("127.0.0.1")) {
            id = AMAZON.getExternalId();
        }
        return id;
    }

}
