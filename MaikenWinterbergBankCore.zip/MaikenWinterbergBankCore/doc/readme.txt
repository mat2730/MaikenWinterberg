Overview of flow view with many VM:

packages:
    com.maikenwinterberg.banker.communication.request 
        contains the types of banking request
    com.maikenwinterberg.banker.communication
        contains the abstract communication layer: supports currently only method call
    
Running a Test

1) Create test input:
    invoke com.maikenwinterberg.banker.communication.request.CreateGivemoneyRequest.main

2) Verify test input
    Look in bin/box/inbox/domainOfRequest for csv files

3) Invoke ReadCsvFiles.main:
    process input Flow:
    1) ReadCsvFiles
    2) LoadBalancer
    3) AccountManager
    4) Account 1 and Account 2
    5) AccountCollector

4) Verify output
    Look in bin/box/processed/domainOfRequest directory for csv files
    Look in bin/box/images/domainOfRequest directory for image files