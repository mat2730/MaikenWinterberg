echo unInstalling service...
sudo systemctl stop MaikenWinterbergBankCore.service
sudo rm /etc/systemd/system/MaikenWinterbergBankCore.service 
sudo systemctl daemon-reload
echo done unInstalling service
sleep 10s