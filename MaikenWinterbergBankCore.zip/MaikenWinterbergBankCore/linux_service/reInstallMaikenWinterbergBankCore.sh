echo installing service...
sudo systemctl stop MaikenWinterbergBankCore.service
sudo cp MaikenWinterbergBankCore.service /etc/systemd/system
sudo systemctl daemon-reload
sudo systemctl start MaikenWinterbergBankCore.service
sudo systemctl enable MaikenWinterbergBankCore.service
echo done installing service
#sleep 10s