echo installing bankcore service
java --class-path classes Install MaikenWinterbergBankCore ../bin startBankCore.sh
echo done installing bankcore service
