/*
 * Martin Alexander Thomsen den 7. December 2024
 */

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class StartupBankCore {
    
    public static void main(String arg[]) throws Throwable {
        StartAccountService.main(arg);
        com.maikenwinterberg.banker.http.StartHttps.main(arg);
        com.maikenwinterberg.banker.loader.LoaderService.main(arg);
        //StartInboxServer.main(arg);
    }
}
