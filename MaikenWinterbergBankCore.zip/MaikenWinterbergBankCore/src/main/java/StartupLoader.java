/*
 * Martin Alexander Thomsen den 16. Januar 2025
 */

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class StartupLoader {

    public static void main(String arg[]) throws Throwable {
        com.maikenwinterberg.banker.loader.LoaderService.main(arg);
    }
}
