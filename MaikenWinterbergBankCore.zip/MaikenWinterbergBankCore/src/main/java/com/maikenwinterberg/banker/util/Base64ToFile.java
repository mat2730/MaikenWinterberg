/*
 * Martin Alexander Thomsen den 5. December 2024
 */
package com.maikenwinterberg.banker.util;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.StandardOpenOption;
import java.util.Base64;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class Base64ToFile {

    public static String toBase64(File imageFile) throws Exception {
        try (FileChannel channel = FileChannel.open(imageFile.toPath(), StandardOpenOption.READ)) {
            ByteBuffer byteBuffer = ByteBuffer.allocate((int) imageFile.length());
            channel.read(byteBuffer);
            byte[] imageBytes = byteBuffer.array();
            return Base64.getMimeEncoder().encodeToString(imageBytes);
        }
    }

    public static File toFile(String base64, String fileName) throws Exception {
        byte[] imageBytes = Base64.getMimeDecoder().decode(base64);
        File newFile = new File(fileName);
        File parentFile = newFile.getParentFile();
        if (parentFile != null) {
            parentFile.mkdirs();
        }
        try (FileOutputStream fos = new FileOutputStream(newFile)) {
            fos.write(imageBytes);
            return newFile;
        } catch (Exception ex) {
            newFile.deleteOnExit();
            throw ex;
        }
    }
}
