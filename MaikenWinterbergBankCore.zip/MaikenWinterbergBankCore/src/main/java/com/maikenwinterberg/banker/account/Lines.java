/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maikenwinterberg.banker.account;

import java.util.List;

/**
 *
 * @author martin
 */
public class Lines {

    private final List<String> lines;
    private final long startingIndex;

    public Lines(List<String> lines, long startingIndex) {
        this.lines = lines;
        this.startingIndex = startingIndex;
    }

    public List<String> getLines() {
        return lines;
    }

    public long getStartingIndex() {
        return startingIndex;
    }

}
