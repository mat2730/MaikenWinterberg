/*
 * Martin Alexander Thomsen den 12. December 2024
 */
package com.maikenwinterberg.banker.communication.api.factories;

import com.maikenwinterberg.banker.communication.api.TakemoneyTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.translate.Translater;
import static com.maikenwinterberg.banker.util.Base64ToFile.toBase64;
import com.maikenwinterberg.config.Config;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class TakeMoneyTelegramFactory {

    private final File file;
    private final FileOutputStream fos;
    private boolean first = true;
    private final String domainName;
    private final String transactionId;

    public TakeMoneyTelegramFactory(String domainName, String inbox) throws Exception {
        if (inbox == null) {
            inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "inboxDirectory");
        }
        new File(inbox + "/" + domainName).mkdirs();
        this.domainName = domainName;
        this.transactionId = TransactionIdCreator.getTransactionId();
        this.file = new File(inbox + "/" + domainName + "/takemoney_" + transactionId);
        this.fos = new FileOutputStream(file);
    }

    public static Telegram createTakeMoneyTelegram(String ip, String sessionId, String domainName, String domainNameOrNumberOfReceiver, Float amount, String text) throws Exception {
        String inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "telegramFactoryDirectory");
        TakeMoneyTelegramFactory f = new TakeMoneyTelegramFactory(domainName, inbox);
        if (text != null) {
            text = Translater.translate(Translater.COLLECTION, text);
        } else {
            text = Translater.translate(Translater.COLLECTION);
        }
        String csv = f.addTakeMoneyLine(domainNameOrNumberOfReceiver, amount, text, null);
        TakemoneyTelegram gt = new TakemoneyTelegram();
        gt.setDomainName(ip, sessionId, domainName);
        gt.setFile(new File(inbox + "/" + domainName + "/takemoney_" + f.transactionId), 0);
        gt.setTransactionId(f.transactionId);
        gt.setGiverPassportNumberOrDomainName(domainNameOrNumberOfReceiver);
        gt.setCsvLine(csv);
        return gt;
    }

    public String getTransactionId(int index) {
        return domainName + "/" + transactionId + "/" + index;
    }

    public String addTakeMoneyLine(String passportNumberOrDomainName, float amount, String text, List<File> attachments) throws Exception {
        StringBuilder builder = new StringBuilder();
        if (!first) {
            builder.append(Telegram.NEW_LINE);
        }
        first = false;
        builder.append(passportNumberOrDomainName);
        builder.append(Telegram.DELIMITER);
        builder.append(amount);
        builder.append(Telegram.DELIMITER);
        if (text == null) {
            text = " ";
        }
        builder.append(text);
        if (attachments != null) {
            for (Iterator<File> i = attachments.iterator(); i.hasNext();) {
                File f = i.next();
                builder.append(Telegram.DELIMITER);
                builder.append(f.getName());
                builder.append(Telegram.DELIMITER);
                builder.append(toBase64(f));
            }
        }
        fos.write(builder.toString().getBytes(Telegram.ENCODING));
        return builder.toString();
    }

    public void commit() throws Exception {
        fos.flush();
        fos.close();
        file.renameTo(new File(file.getAbsolutePath() + ".csv"));
    }
}
