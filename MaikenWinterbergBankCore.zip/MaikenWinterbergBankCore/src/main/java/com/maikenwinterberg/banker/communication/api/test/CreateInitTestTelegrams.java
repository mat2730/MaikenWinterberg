/*
 * Martin Alexander Thomsen den 7. December 2024
 */
package com.maikenwinterberg.banker.communication.api.test;

import com.maikenwinterberg.banker.communication.api.factories.AccountTelegramFactory;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class CreateInitTestTelegrams {

    public static void main(String arg[]) throws Exception {
        AccountTelegramFactory.doLinkTelegram("maikenwinterberg.com", "passportnumber_1", null,null,null);
        AccountTelegramFactory.doLinkTelegram("documentnetwork.com", "passportnumber_2", null,null,null);
    }
}
