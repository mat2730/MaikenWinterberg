/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maikenwinterberg.banker.communication.api;

/**
 *
 * @author martin
 */
public class HasAmountImpl implements HasAmount {

    private String text;
    private Float amount;
    private boolean isRollback;

    public HasAmountImpl(Float amount, String text, boolean isRollback) {
        this.amount = amount;
        this.text = text;
        this.isRollback = isRollback;
    }

    @Override
    public boolean isRollback() {
        return isRollback;
    }

    @Override
    public float getAmount() {
        return amount;
    }

    @Override
    public String getText() {
        return text;
    }

}
