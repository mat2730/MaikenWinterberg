/*
 * Martin Alexander Thomsen den 5. December 2024
 */
package com.maikenwinterberg.banker.loader;

import com.maikenwinterberg.config.Config;
import java.io.File;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * read in Niro is an integer. Its to small
 */
public class LoaderService {

    public static final DateTimeFormatter ZDT_FORMATTER1 = DateTimeFormatter.ofPattern("yyyy-MM/dd HH:mm:ss");
    public static final DateTimeFormatter ZDT_FORMATTER2 = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    public static void main(String arg[]) {
        File inputDirectory = new File(Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "inboxDirectory"));;
        File processedDirectory = new File(Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "processedDirectory"));
        String domainName;
        File csvFile;
        try {
            TransactionListener.addEventListener(processedDirectory);
            int fileCount = 1;
            while (true) {
                long startTime = System.currentTimeMillis();
                domainName = null;
                csvFile = null;
                File[] domains = inputDirectory.listFiles();
                if (domains != null) {
                    for (int fileIndex = 0; fileIndex < domains.length; fileIndex++) {
                        File domainDirectory = domains[fileIndex];
                        if (!domainDirectory.isDirectory()) {
                            continue;
                        }
                        domainName = domainDirectory.getName();
                        File[] csvFiles = domainDirectory.listFiles();
                        if (csvFiles != null) {
                            int lineIndex = 0;
                            while (true) {
                                long iterationStartTime = System.currentTimeMillis();
                                if (lineIndex == csvFiles.length) {
                                    break;
                                }
                                csvFile = csvFiles[lineIndex++];
                                if (csvFile.isFile()) {
                                    String csvFileName = csvFile.getName();
                                    if (csvFileName.endsWith(".csv")) {
                                        fileCount++;
                                        File newFile = new File(csvFile.getAbsolutePath() + ".processing");
                                        csvFile.renameTo(newFile);
                                        if (newFile.exists()) {
                                            CsvTelegramProcess.processCsv(processedDirectory, domainName, newFile);
                                        } else {
                                            System.out.println("cannot rename file " + newFile.getAbsolutePath());
                                        }
                                    }
                                } else if (csvFile.isDirectory() && csvFile.getName().equalsIgnoreCase("local")) {
                                    csvFiles = csvFile.listFiles();
                                    if (csvFiles != null) {
                                        for (int lineIndex2 = 0; lineIndex2 < domains.length; lineIndex2++) {
                                            csvFile = csvFiles[lineIndex2];
                                            if (csvFile.isFile()) {
                                                String csvFileName = csvFile.getName();
                                                if (csvFileName.endsWith(".csv")) {
                                                    fileCount++;
                                                    File newFile = new File(csvFile.getAbsolutePath() + ".processing");
                                                    csvFile.renameTo(newFile);
                                                    if (newFile.exists()) {
                                                        CsvTelegramProcess.processCsv(processedDirectory, domainName, newFile);
                                                    } else {
                                                        System.out.println("cannot rename file " + newFile.getAbsolutePath());
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                try {
                    Thread.sleep(1000);
                }
                catch(Exception ex) {}
            }
        } catch (Throwable ex) {
            ex.printStackTrace();
        }
    }

    public static String appendDate2FileName(String fileName) {
        int index = fileName.indexOf(".");
        return fileName.substring(0, index) + "_" + getDateString2() + fileName.substring(index);
    }

    public static String getDateString1() {
        return ZDT_FORMATTER1.format(ZonedDateTime.now());
    }

    public static String getDateString2() {
        return ZDT_FORMATTER2.format(ZonedDateTime.now());
    }
}
