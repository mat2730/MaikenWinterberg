/*
 * Martin Alexander Thomsen den 16. December 2024
 */
package com.maikenwinterberg.banker.accountManager.telegramProcess;

import com.maikenwinterberg.banker.accountManager.AccountServiceLookupFactory;
import com.maikenwinterberg.banker.communication.Destination;
import com.maikenwinterberg.banker.communication.IReceiveRequest;
import com.maikenwinterberg.banker.communication.SendRequestFactory;
import com.maikenwinterberg.banker.communication.api.AccountTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.event.CommunicationEvent;
import com.maikenwinterberg.banker.communication.event.LocalEvents;
import com.maikenwinterberg.banker.communication.event.TelegramErrorResponse;
import com.maikenwinterberg.banker.communication.event.TelegramOKResponse;
import com.maikenwinterberg.banker.communication.translate.JsonConverter;
import com.maikenwinterberg.domainname.DomainHandler;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class BalanceTelegramProcess implements IReceiveRequest {

    @Override
    public String receiveRequest(Telegram telegram) throws Throwable {
        try {
            Destination accountService1 = AccountServiceLookupFactory.getAccountDestinationLookupByDomainNameInstance().getAccountService(telegram.getDomainName());
            Destination source = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountManagerService);
            String text = SendRequestFactory.newInstance().sendRequest(source, accountService1, new AccountTelegram(telegram, telegram.getDomainName(), null, AccountTelegram.Action.Balance, null,false));
            text = JsonConverter.toJson(telegram, true, text);
            CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramOKResponse(telegram.getTransactionId(), text));
            LocalEvents.fireEvent(ce);
            return text;
        } catch (Exception ex) {
            String text = JsonConverter.toJson(telegram, ex);
            CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(), new IllegalStateException(text)));
            LocalEvents.fireEvent(ce);
            return text;
        }
    }
}
