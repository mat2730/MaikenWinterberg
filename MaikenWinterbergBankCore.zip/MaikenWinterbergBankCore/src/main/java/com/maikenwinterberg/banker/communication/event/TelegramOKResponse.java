/*
 * Martin Alexander Thomsen den 7. December 2024
 */
package com.maikenwinterberg.banker.communication.event;

import com.maikenwinterberg.banker.communication.event.TelegramResponse;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class TelegramOKResponse extends TelegramResponse {

    private final String message;
    private final String transactionId;

    public TelegramOKResponse(String transactionId, String message) {
        this.message = message;
        this.transactionId = transactionId;
    }

    @Override
    public String getTransactionId() {
        return this.transactionId;
    }

    @Override
    public boolean isOk() {
        return true;
    }

    @Override
    public String getStackTrace() {
        return null;
    }

    @Override
    public String getMessage() {
        return message;
    }

}
