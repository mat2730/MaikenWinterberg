/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maikenwinterberg.banker.util;

import java.io.File;
import java.net.URL;
import java.util.Enumeration;

/**
 *
 * @author martin
 */
public class ClassLoaderSecurity {

    public String decode(String text) {
        return text;
    }

    public String encode(String text) {
        return text;
    }

    public static void main(String arg[]) {
        ClassFinder.findClasses(new Visitor<String>() {
            @Override
            public boolean visit(String clazz) {
                URL url = ClassLoader.getPlatformClassLoader().getResource(clazz);
                if (url != null) {
                System.out.println(url.getFile().length());
                }
                return true;
            }
        });
    }
}
