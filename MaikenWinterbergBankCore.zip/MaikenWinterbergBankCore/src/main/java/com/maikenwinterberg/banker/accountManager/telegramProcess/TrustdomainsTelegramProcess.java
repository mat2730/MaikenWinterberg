/*
 * Martin Alexander Thomsen den 17. December 2024
 */
package com.maikenwinterberg.banker.accountManager.telegramProcess;

import com.maikenwinterberg.banker.accountManager.AccountServiceLookupFactory;
import com.maikenwinterberg.banker.communication.Destination;
import com.maikenwinterberg.banker.communication.IReceiveRequest;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.api.TrustdomainsTelegram;
import com.maikenwinterberg.banker.communication.event.CommunicationEvent;
import com.maikenwinterberg.banker.communication.event.LocalEvents;
import com.maikenwinterberg.banker.communication.event.TelegramErrorResponse;
import com.maikenwinterberg.banker.communication.event.TelegramOKResponse;
import com.maikenwinterberg.banker.communication.translate.JsonConverter;
import com.maikenwinterberg.banker.communication.translate.Translater;
import com.maikenwinterberg.domainname.DomainHandler;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class TrustdomainsTelegramProcess implements IReceiveRequest {

    @Override
    public String receiveRequest(Telegram telegram) throws Throwable {
        try {
            TrustdomainsTelegram tm = (TrustdomainsTelegram) telegram;
            if (!tm.isReversed()) {
                AccountServiceLookupFactory.getTrustDomainsInstance().addTrustDomains(tm.getDomainName(), tm.getTrustedDomainNames(), tm.isAppend());
            } else {
                AccountServiceLookupFactory.getTrustDomainsInstance().removeTrustDomains(tm.getDomainName(), tm.getTrustedDomainNames());
            }
            List<String> alltrustedDomains = AccountServiceLookupFactory.getTrustDomainsInstance().getTrustDomains(tm.getDomainName());
            Destination source = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountManagerService);
            Destination loader = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.loaderService);
            String text = Translater.translate(Translater.TRUST_ACCOUNT_LIST, alltrustedDomains.toString());
            text = JsonConverter.toJson(telegram, true, text);
            CommunicationEvent ce = new CommunicationEvent(source, loader, telegram, new TelegramOKResponse(telegram.getTransactionId(),text));
            LocalEvents.fireEvent(ce);
            return text;
        } catch (Exception ex) {
            String text = JsonConverter.toJson(telegram, ex);
            CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(),new IllegalStateException(text)));
            LocalEvents.fireEvent(ce);
            return text;
        }
    }
}
