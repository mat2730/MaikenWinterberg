/*
 * Martin Alexander Thomsen den 21. December 2024
 */
package com.maikenwinterberg.banker.communication.translate;

import com.maikenwinterberg.banker.communication.api.ApproveBankTelegram;
import com.maikenwinterberg.banker.communication.api.GivemoneyTelegram;
import com.maikenwinterberg.banker.communication.api.HasOriginal;
import com.maikenwinterberg.banker.communication.api.PrintmoneyTelegram;
import com.maikenwinterberg.banker.communication.api.RollbacktransactionTelegram;
import com.maikenwinterberg.banker.communication.api.TakemoneyTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.loader.LoaderService;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Iterator;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.
 */
public class JsonConverter {
    
    public static String toMessage(String jsonText) {
        int index = jsonText.indexOf("Text");
        if (index != -1) {
            index+=8;
            int index2 = jsonText.indexOf("\"",index);
            if (index2 > index) {
                return jsonText.substring(index,index2);
            }
        }
        index = jsonText.indexOf("TransactionId");
        if (index != -1) {
            index += 17;
            int index2 = jsonText.indexOf("\"",index);
            if (index2 > index) {
                return jsonText.substring(index,index2);
            }
        }
        index = jsonText.indexOf("ResponseType");
        if (index != -1) {
            index += 16;
            int index2 = jsonText.indexOf("\"",index);
            if (index2 > index) {
                return jsonText.substring(index,index2);
            }
        }
        return "Unknnown error";
    }

    public static String toJson(String transactionId, boolean acknowledged, Map<String, String> attributes) {
        StringBuilder builder = new StringBuilder();
        builder.append("{\"Response\": {");
        builder.append("\n\t\"CurrentDate\": \"").append(LoaderService.getDateString1()).append("\"");
        for (Iterator i = attributes.keySet().iterator(); i.hasNext();) {
            String key = (String) i.next();
            String value = (String) attributes.get(key);
            builder.append(",\n\t\"").append(key).append("\": \"").append(value).append("\"");
        }
        if (acknowledged) {
            builder.append(",\n\t\"ResponseType\": \"").append(Translater.TRANSACTION_OK).append("\"");
        } else {
            builder.append(",\n\t\"ResponseType\": \"").append(Translater.UNKNOWN_ERROR).append("\"");
        }
        if (transactionId != null) {
            builder.append(",\n\t\"TransactionId\": \"").append(transactionId).append("\"");
        }
        builder.append("\n}}");
        return builder.toString();
    }

    public static String toJson(Telegram telegram, boolean acknowledged, String text) {
        if (text != null && text.startsWith("{\"Response\":")) {
            //its allready a json
            return text;
        }
        StringBuilder builder = new StringBuilder();
        builder.append("{\"Response\": {");
        builder.append("\n\t\"CurrentDate\": \"").append(LoaderService.getDateString1()).append("\"");
        if (telegram != null) {
            if (telegram instanceof HasOriginal) {
                Telegram ot = ((HasOriginal) telegram).getOriginalTelegram();
                if (ot != null) {
                    telegram = ot;
                }
            }
            builder.append(",\n\t\"Account\": \"").append(telegram.getDomainName()).append("\"");
            builder.append(",\n\t\"TelegramType\": \"").append(telegram.getClass().getSimpleName()).append("\"");
            builder.append(",\n\t\"IP\": \"").append(telegram.getIp()).append("\"");
            if (telegram.getTransactionId() != null) {
                builder.append(",\n\t\"TransactionId\": \"").append(telegram.getTransactionId()).append("\"");
            }
            if (telegram instanceof GivemoneyTelegram) {
                String receiverPassportNumberOrDomainName = ((GivemoneyTelegram) telegram).getReceiverPassportNumberOrDomainName();
                builder.append(",\n\t\"CounterAccount\": \"").append(receiverPassportNumberOrDomainName).append("\"");
            } else if (telegram instanceof TakemoneyTelegram) {
                String giverPassportNumberOrDomainName = ((TakemoneyTelegram) telegram).getGiverPassportNumberOrDomainName();
                builder.append(",\n\t\"CounterAccount\": \"").append(giverPassportNumberOrDomainName).append("\"");
            } else if (telegram instanceof PrintmoneyTelegram) {
                String bankAccount = ((PrintmoneyTelegram) telegram).getBankaccount();
                builder.append(",\n\t\"CounterAccount\": \"").append(bankAccount).append("\"");
            } else if (telegram instanceof RollbacktransactionTelegram) {
                String passportNumberOrDomainName = ((RollbacktransactionTelegram) telegram).getCounterAccountDomainName();
                builder.append(",\n\t\"CounterAccount\": \"").append(passportNumberOrDomainName).append("\"");
                builder.append(",\n\t\"Rolledbacktransaction\": \"").append(((RollbacktransactionTelegram)telegram).getTransactionid2Rollback()).append("\"");
            } else if (telegram instanceof ApproveBankTelegram) {
                String bankDomainName = ((ApproveBankTelegram) telegram).getBankAccount();
                builder.append(",\n\t\"CounterAccount\": \"").append(bankDomainName).append("\"");
            }
        }
        if (acknowledged) {
            builder.append(",\n\t\"ResponseType\": \"").append(Translater.TRANSACTION_OK).append("\"");
        } else {
            builder.append(",\n\t\"ResponseType\": \"").append(Translater.UNKNOWN_ERROR).append("\"");
        }
        if (text != null) {
            builder.append(",\n\t\"Text\": \"").append(text.trim()).append("\"");
        }
        builder.append("\n}}");
        return builder.toString();
    }

    public static String toJson(String transactionId, String text, Throwable throwable) {
        if (throwable != null && throwable.getMessage() != null && throwable.getMessage().startsWith("{\"Response\":")) {
            //its allready a json
            return throwable.getMessage();
        }
        StringBuilder builder = new StringBuilder();
        builder.append("{\"Response\": {");
        builder.append("\n\t\"CurrentDate\": \"").append(LoaderService.getDateString1()).append("\"");
        builder.append(",\n\t\"ResponseType\": \"").append(Translater.UNKNOWN_ERROR).append("\"");
        if (transactionId != null) {
            builder.append(",\n\t\"TransactionId\": \"").append(transactionId).append("\"");
        }
        if (text != null) {
            builder.append(",\n\t\"Text\": \"").append(text.trim()).append("\"");
        }
        if (throwable != null) {
            StringWriter stringWriter = new StringWriter();
            PrintWriter w = new PrintWriter(stringWriter);
            throwable.printStackTrace(w);
            builder.append("\n\t\"Stacktrace\": \"").append(stringWriter.getBuffer().toString()).append("\"");
           /*
            String base64StackTrace = null;
            try {
                base64StackTrace = new String(Base64.encodeBase64(stringWriter.getBuffer().toString().getBytes(Telegram.ENCODING)), Telegram.ENCODING);
            } catch (Exception ex) {
            }
            if (base64StackTrace != null) {
                builder.append("\n\t\"Stacktrace\": \"").append(base64StackTrace).append("\"");
            }*/
        }
        builder.append("\n}}");
        return builder.toString();
    }

    public static String toJson(Telegram telegram, Throwable throwable) {
        if (throwable != null && throwable.getMessage() != null && throwable.getMessage().startsWith("{\"Response\":")) {
            //its allready a json
            return throwable.getMessage();
        }
        StringBuilder builder = new StringBuilder();
        builder.append("{\"Response\": {");
        builder.append("\n\t\"CurrentDate\": \"").append(LoaderService.getDateString1()).append("\"");
        if (telegram != null) {
            if (telegram instanceof HasOriginal) {
                Telegram ot = ((HasOriginal) telegram).getOriginalTelegram();
                if (ot != null) {
                    telegram = ot;
                }
            }
            builder.append(",\n\t\"Account\": \"").append(telegram.getDomainName()).append("\"");
            builder.append(",\n\t\"TelegramType\": \"").append(telegram.getClass().getSimpleName()).append("\"");
            builder.append(",\n\t\"IP\": \"").append(telegram.getIp()).append("\"");
            if (telegram.getTransactionId() != null) {
                builder.append(",\n\t\"TransactionId\": \"").append(telegram.getTransactionId()).append("\"");
            }
            if (telegram instanceof GivemoneyTelegram) {
                String receiverPassportNumberOrDomainName = ((GivemoneyTelegram) telegram).getReceiverPassportNumberOrDomainName();
                builder.append(",\n\t\"CounterAccount\": \"").append(receiverPassportNumberOrDomainName).append("\"");
            } else if (telegram instanceof TakemoneyTelegram) {
                String giverPassportNumberOrDomainName = ((TakemoneyTelegram) telegram).getGiverPassportNumberOrDomainName();
                builder.append(",\n\t\"CounterAccount\": \"").append(giverPassportNumberOrDomainName).append("\"");
            } else if (telegram instanceof PrintmoneyTelegram) {
                String passportNumberOrDomainName = ((PrintmoneyTelegram) telegram).getPassportnumberOrDomainName();
                builder.append(",\n\t\"CounterAccount\": \"").append(passportNumberOrDomainName).append("\"");
            } else if (telegram instanceof RollbacktransactionTelegram) {
                String passportNumberOrDomainName = ((RollbacktransactionTelegram) telegram).getCounterAccountDomainName();
                builder.append(",\n\t\"CounterAccount\": \"").append(passportNumberOrDomainName).append("\"");
            } else if (telegram instanceof ApproveBankTelegram) {
                String passportNumberOrDomainName = ((ApproveBankTelegram) telegram).getBankAccount();
                builder.append(",\n\t\"CounterAccount\": \"").append(passportNumberOrDomainName).append("\"");
            }
        }
        builder.append(",\n\t\"ResponseType\": \"").append(Translater.UNKNOWN_ERROR).append("\"");
        if (throwable != null) {
            builder.append(",\n\t\"Text\": \"").append(throwable.getMessage().trim()).append("\"");
            StringWriter stringWriter = new StringWriter();
            PrintWriter w = new PrintWriter(stringWriter);
            throwable.printStackTrace(w);
            builder.append("\n\t\"Stacktrace\": \"").append(stringWriter.getBuffer().toString()).append("\"");
            /*
            String base64StackTrace = null;
            try {
                base64StackTrace = new String(Base64.encodeBase64(stringWriter.getBuffer().toString().getBytes(Telegram.ENCODING)), Telegram.ENCODING);
            } catch (Exception ex) {
            }
            if (base64StackTrace != null) {
                builder.append("\n\t\"Stacktrace\": \"").append(base64StackTrace).append("\"");
            }*/
        }
        builder.append("\n}}");
        return builder.toString();
    }
}
