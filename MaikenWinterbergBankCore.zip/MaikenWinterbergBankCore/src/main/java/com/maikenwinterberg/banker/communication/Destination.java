/*
 * Martin Alexander Thomsen den 11. December 2024
 */
package com.maikenwinterberg.banker.communication;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class Destination {

    private final String ip;
    private final ServiceName serviceName;

    public static enum ServiceName {
        loaderService, loadBalancerService, accountManagerService, accountService;
    }

    public Destination(String ip, ServiceName serviceName) {
        this.ip = ip;
        this.serviceName = serviceName;
    }

    public String getIp() {
        return ip;
    }

    public ServiceName getServiceName() {
        return serviceName;
    }
    
    @Override
    public String toString() {
        return ip + "/" + serviceName.toString();
    }
}