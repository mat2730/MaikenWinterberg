/*
 * Martin Alexander Thomsen den 11. December 2024
 */
package com.maikenwinterberg.banker.accountManager;

import com.maikenwinterberg.banker.communication.Destination;
import com.maikenwinterberg.domainname.DomainHandler;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class DefaultAccountServiceDestinationLookupByDomainName implements IDomain2Account {

    @Override
    public Destination getAccountService(String domainName) {
        //TODO implement multiple destinations by domainName
        Destination destination = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountService);
        return destination;
    }

}
