/*
 * Martin Alexander Thomsen den 12. December 2024
 */
package com.maikenwinterberg.banker.communication.api;

import static com.maikenwinterberg.banker.communication.api.Telegram.getDateString;
import com.maikenwinterberg.banker.util.Base64ToFile;
import com.maikenwinterberg.banker.loader.LoaderService;
import com.maikenwinterberg.config.Config;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class TakemoneyTelegram extends Telegram implements HasAmount {

    private String text;
    private float amount;
    private String giverPassportNumberOrDomainName;
    private final List images = new LinkedList();

    @Override
    public void setCsvLine(String csvLine) throws Exception {
        StringTokenizer tok = new StringTokenizer(csvLine, Telegram.DELIMITER);
        this.giverPassportNumberOrDomainName = tok.nextToken();
        this.amount = Float.parseFloat(tok.nextToken());
        this.text = tok.nextToken();

        String saveAttachments = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "saveAttachments");
        String imageDirectory = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "imageDirectory");
        while (tok.hasMoreTokens()) {
            String nameOfAttachment = tok.nextToken();
            String base64 = tok.nextToken();
            String fileName = "/" + getDomainName() + "/" + getDateString() + "/" + getClass().getSimpleName() + "/" + LoaderService.appendDate2FileName(nameOfAttachment);
            String fullFileName = imageDirectory + fileName;
            if (saveAttachments != null && saveAttachments.equalsIgnoreCase("false")) {
                continue;
            }
            Base64ToFile.toFile(base64, fullFileName);
            images.add(fullFileName);
        }
    }

    @Override
    public float getAmount() {
        return amount;
    }

    public String getGiverPassportNumberOrDomainName() {
        return giverPassportNumberOrDomainName;
    }
    
    public void setGiverPassportNumberOrDomainName(String domainName) {
        this.giverPassportNumberOrDomainName = domainName;
    }

    public List getImages() {
        return images;
    }

    @Override
    public String getText() {
        return text;
    }
    
    @Override
    public boolean isRollback() {
        return false;
    }

    @Override
    public String toString() {
        return "TakemoneyTelegram{" + "domainName=" + getDomainName() + ", file=" + getFile() + ", telegramIndex=" + getTelegramIndex() + ", transactionId=" + getTransactionId() + ", text=" + text + ", amount=" + amount + ", giverPassportNumberOrDomainName=" + giverPassportNumberOrDomainName + ", images=" + images + '}';
    }
}
