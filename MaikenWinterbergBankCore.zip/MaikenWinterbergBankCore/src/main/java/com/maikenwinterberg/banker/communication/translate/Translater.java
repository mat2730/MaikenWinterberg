/*
 * Martin Alexander Thomsen den 20. December 2024
 */
package com.maikenwinterberg.banker.communication.translate;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.
 */
public class Translater {

    public final static String NUMBER_LINKED = "is now linked to the account";
    public final static String NUMBER_NO_LINKED = "is no longer linked to the account";
    public final static String NUMBER_ALLREADY_LINKED = "The number is allready linked to another account";
    public final static String INVALID_NUMBER = "The format of the number is invalid";
    public final static String INVALID_DOMAIN = "The domain is invalid";
    public final static String INVALID_DOMAIN2 = "is the wrong ip for domain";
    public final static String INVALID_DOMAIN3 = "is not an administrator ip";
    public final static String IS_LOCAL_DOMAIN = "The domainname is a local address";
    public final static String NO_PERMISTION = "You have no permision to execute this function";
    public final static String ALLREADY_ROLLEDBACK = "You have allready rolledback the transaction";
    public final static String NO_RECEIVER_LINK = "The uniq number of the receiver is not linked to any account:";
    public final static String TRANSACTION_OK = "Success";
    public final static String UNKNOWN_ERROR = "Error";
    public final static String UNKNOWN_BANK = "Ukendt bank";
    public final static String NO_NEGATIVE_AMOUNT = "Balance cannot be negative";
    public final static String TRANSFERED_FROM = "has been transfered from";
    public final static String TRUST_ACCOUNT_LIST = "List of trust accounts";
    public final static String SHOW_SALDO = "The saldo of the account is";
    public final static String TRANSFER_TO = "has been transfered to";
    public final static String COLLECTION = "Money collection";
    public final static String CANNOT_ROLLBACK = "This transaction cannot be rolled back";
    public final static String CANNOT_FIND_TRANSACTION = "Transaction not found";
    public final static String ROLLBACK = "Transaction rollback";
    public final static String THE_TRANSACTION = "The transaction";
    public final static String IS_ROLLEDBACKED_BACK_FROM = "is rolled back together with account";
    public final static String AMOUNT_IS_TO_BIG = "is to big. Max loan amount is";
    public final static String LOAN_GRANTED = "Is now the max loan amount of account";
    public final static String IN_BANK = "in bank";
    public final static String PRINTET_TO = "Is now inserted into account";
    public final static String FROM_BANK = "of bank";

    public static String translate(String key) {
        return key;
    }

    public static String translate(String key, Object param1) {
        return key + " " + param1;
    }

    public static String translate(Object param1, String key, Object param2) {
        return param1 + " " + key + " " + param2;
    }

    public static String translate(String key1, Object param1, String key2, Object param2) {
        return key1 + " " + param1 + " " + key2 + " " + param2;
    }
    
    public static String translate(Object param1, String key, Object param2, String key2, Object param3) {
        return param1 + " " + key + " " + param2 + " " + key2 + " " + param3;
    }
}