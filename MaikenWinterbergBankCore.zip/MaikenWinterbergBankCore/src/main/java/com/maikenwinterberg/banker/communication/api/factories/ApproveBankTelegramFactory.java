/*
 * Martin Alexander Thomsen den 23. December 2024
 */
package com.maikenwinterberg.banker.communication.api.factories;

import com.maikenwinterberg.banker.communication.api.ApproveBankTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import static com.maikenwinterberg.banker.util.Base64ToFile.toBase64;
import com.maikenwinterberg.config.Config;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class ApproveBankTelegramFactory {

    private final String transactionId;
    private final OutputStream os;
    private final File file;
    private boolean first = true;

    public static ApproveBankTelegram createApproveBankTelegram(String ip, String sessionId, String domainName, String domainNameOfBank2Approve, String oprettelsesText, boolean delete) throws Exception {
        String inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "telegramFactoryDirectory");
        ApproveBankTelegramFactory factory = new ApproveBankTelegramFactory(domainName, inbox);
        String csv = factory.addApproveBankLine(domainNameOfBank2Approve, oprettelsesText, delete, null);
        factory.commit();
        ApproveBankTelegram t = new ApproveBankTelegram();
        t.setDomainName(ip, sessionId, domainName);
        t.setFile(new File(inbox + "/" + domainName + "/ApproveBank_" + factory.transactionId), 0);
        t.setTransactionId(factory.transactionId);
        t.setCsvLine(csv);
        return t;
    }

    public ApproveBankTelegramFactory(String domainName, String inbox) throws Exception {
        if (inbox == null) {
            inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "inputDirectory");
        }
        new File(inbox + "/" + domainName).mkdirs();
        this.transactionId = TransactionIdCreator.getTransactionId();
        file = new File(inbox + "/" + domainName + "/ApproveBank_" + transactionId);
        os = new FileOutputStream(file);
    }

    public String addApproveBankLine(String domainNameOfBank, String oprettelsesText, boolean delete, List<File> attachments) throws Exception {
        StringBuilder builder = new StringBuilder();
        if (!first) {
            builder.append(Telegram.NEW_LINE);
        }
        first = false;
        builder.append(domainNameOfBank);
        builder.append(Telegram.DELIMITER);
        builder.append(oprettelsesText);
        builder.append(Telegram.DELIMITER);
        builder.append(delete);
        if (attachments != null) {
            for (Iterator<File> i = attachments.iterator(); i.hasNext();) {
                File f = i.next();
                builder.append(Telegram.DELIMITER);
                builder.append(f.getName());
                builder.append(Telegram.DELIMITER);
                builder.append(toBase64(f));
            }
        }
        os.write(builder.toString().getBytes(Telegram.ENCODING));
        return builder.toString();
    }

    public void commit() throws Exception {
        os.flush();
        os.close();
        if (file != null) {
            file.renameTo(new File(file.getAbsolutePath() + ".csv"));
        }
    }
}
