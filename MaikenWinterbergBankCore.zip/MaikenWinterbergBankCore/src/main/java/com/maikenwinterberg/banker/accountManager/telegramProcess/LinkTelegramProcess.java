/*
 * Martin Alexander Thomsen den 16. December 2024
 */
package com.maikenwinterberg.banker.accountManager.telegramProcess;

import com.maikenwinterberg.banker.accountManager.AccountServiceLookupFactory;
import com.maikenwinterberg.banker.communication.Destination;
import com.maikenwinterberg.banker.communication.IReceiveRequest;
import com.maikenwinterberg.banker.communication.api.LinkTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.event.CommunicationEvent;
import com.maikenwinterberg.banker.communication.event.LocalEvents;
import com.maikenwinterberg.banker.communication.event.TelegramErrorResponse;
import com.maikenwinterberg.banker.communication.event.TelegramOKResponse;
import com.maikenwinterberg.banker.communication.translate.JsonConverter;
import com.maikenwinterberg.banker.communication.translate.Translater;
import com.maikenwinterberg.domainname.DomainHandler;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class LinkTelegramProcess implements IReceiveRequest {

    @Override
    public String receiveRequest(Telegram telegram) throws Throwable {
        try {
            Destination source = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountManagerService);
            Destination loader = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.loaderService);
            String passportNumber = ((LinkTelegram) telegram).getPassportnumber();
            if (passportNumber == null || passportNumber.contains(".")) {
                String text = Translater.translate(Translater.INVALID_NUMBER, passportNumber);
                text = JsonConverter.toJson(telegram, false, text);
                CommunicationEvent ce = new CommunicationEvent(source, loader, telegram, new TelegramErrorResponse(telegram.getTransactionId(),new IllegalStateException(text + " " + passportNumber)));
                LocalEvents.fireEvent(ce);
                return text;
            }

            String linkedDomainName = AccountServiceLookupFactory.getDomainLookupByPassportInstance().getDomainName(passportNumber);
            if (linkedDomainName != null) {
                String text;
                if (linkedDomainName.equalsIgnoreCase(telegram.getDomainName())) {
                    text = Translater.translate(passportNumber, Translater.NUMBER_LINKED, linkedDomainName);
                    text = JsonConverter.toJson(telegram, true, text);
                } else {
                    text = Translater.translate(Translater.NUMBER_ALLREADY_LINKED, passportNumber);
                    text = JsonConverter.toJson(telegram, false, text);
                }
                CommunicationEvent ce = new CommunicationEvent(source, loader, telegram, new TelegramErrorResponse(telegram.getTransactionId(),new IllegalStateException(text)));
                LocalEvents.fireEvent(ce);
                return text;
            }
            AccountServiceLookupFactory.getDomainLookupByPassportInstance().link(passportNumber, telegram.getDomainName());
            String text = Translater.translate(passportNumber,Translater.NUMBER_LINKED, telegram.getDomainName());
            text = JsonConverter.toJson(telegram, true, text);
            CommunicationEvent ce = new CommunicationEvent(source, loader, telegram, new TelegramOKResponse(telegram.getTransactionId(),text));
            LocalEvents.fireEvent(ce);
            return text;
        } catch (Exception ex) {
            String text = JsonConverter.toJson(telegram, ex);
            CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(),new IllegalStateException(text)));
            LocalEvents.fireEvent(ce);
            return text;
        }
    }
}
