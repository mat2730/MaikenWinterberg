/*
 * Martin Alexander Thomsen den 11. December 2024
 */
package com.maikenwinterberg.banker.accountManager;

import com.maikenwinterberg.config.Config;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class AccountServiceLookupFactory {

    public static IAccountLookupByTransaction getAccountLookupByTransactionInstance() {
        try {
            String zlass = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "IAccountLookupByTransaction");
            IAccountLookupByTransaction obj = (IAccountLookupByTransaction) Class.forName(zlass).newInstance();
            return obj;
        } catch (Exception ex) {
            return new DefaultAccountLookupByTransaction();
        }
    }

    public static ITrustDomains getTrustDomainsInstance() {
        try {
            String zlass = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "ITrustDomains");
            ITrustDomains obj = (ITrustDomains) Class.forName(zlass).newInstance();
            return obj;
        } catch (Exception ex) {
            return new DefaultTrustDomainsImpl();
        }
    }
    public static IDomain2Account getAccountDestinationLookupByDomainNameInstance() {
        try {
            String zlass = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "IDomain2Account");
            IDomain2Account obj = (IDomain2Account) Class.forName(zlass).newInstance();
            return obj;
        } catch (Exception ex) {
            return new DefaultAccountServiceDestinationLookupByDomainName();
        }
    }

    public static IDomainLookupByPassport getDomainLookupByPassportInstance() {
        try {
            String zlass = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "IDomainLookupByPassport");
            IDomainLookupByPassport obj = (IDomainLookupByPassport) Class.forName(zlass).newInstance();
            return obj;
        } catch (Exception ex) {
            return new DefaultDomainLookupByPassport();
        }
    }
}
