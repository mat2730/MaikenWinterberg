/*
 * Martin Alexander Thomsen den 5. December 2024
 */
package com.maikenwinterberg.banker.communication;

import com.maikenwinterberg.banker.communication.api.Telegram;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface ISendRequest {
    public String sendRequest(Destination source, Destination destination, Telegram telegram) throws Throwable;
}