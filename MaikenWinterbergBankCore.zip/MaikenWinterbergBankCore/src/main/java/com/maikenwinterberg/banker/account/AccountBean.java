/*
 * Martin Alexander Thomsen den 11. December 2024
 * 
 */
package com.maikenwinterberg.banker.account;

import com.maikenwinterberg.banker.accountManager.AccountServiceLookupFactory;
import com.maikenwinterberg.banker.communication.Destination;
import com.maikenwinterberg.banker.communication.SendRequestFactory;
import com.maikenwinterberg.banker.communication.api.AccountTelegram;
import com.maikenwinterberg.banker.communication.api.GivemoneyTelegram;
import com.maikenwinterberg.banker.communication.api.HasAmount;
import com.maikenwinterberg.banker.communication.api.HasAmountImpl;
import com.maikenwinterberg.banker.communication.api.HistoryTelegram;
import com.maikenwinterberg.banker.communication.api.PrintmoneyTelegram;
import com.maikenwinterberg.banker.communication.api.RollbacktransactionTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.loader.LoaderService;
import com.maikenwinterberg.banker.communication.translate.Translater;
import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.domainname.DomainHandler;
import java.io.File;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.WeakHashMap;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * TODO implement rolling account.txt file
 */
public class AccountBean {

    public final static Map<String, BigDecimal> CACHE = new WeakHashMap<>();
    public final static DecimalFormat df = new DecimalFormat("###,###,###,###,###,###,###,###,###,###,###,###.##");

    private final String domainNameOfAccount;

    public AccountBean(String domainNameOfAccount) {
        this.domainNameOfAccount = domainNameOfAccount;
    }

    public static BigDecimal getOriginalBalance(String domainNameOfAccount, File f) throws Exception {
        synchronized (domainNameOfAccount) {
            BigDecimal amount = (BigDecimal) CACHE.get(domainNameOfAccount);
            if (amount != null) {
                return amount;
            }
            if (f == null) {
                f = FileAccount.getFile(domainNameOfAccount, false);
            }
            String lastLine = FileAccount.getLastLine(domainNameOfAccount, f);
            if (lastLine != null) {
                StringTokenizer tok = new StringTokenizer(lastLine, Telegram.NEW_LINE + Telegram.DELIMITER);
                String lastElement = null;
                while (tok.hasMoreTokens()) {
                    String nextToken = tok.nextToken();
                    if (!nextToken.trim().isEmpty()) {
                        lastElement = nextToken;
                    }
                }
                if (lastElement != null && !lastElement.trim().isEmpty()) {
                    amount = new BigDecimal(lastElement);
                    CACHE.put(domainNameOfAccount, amount);
                    return new BigDecimal(lastElement);
                }
            }
            CACHE.put(domainNameOfAccount, new BigDecimal("0.0"));
            return new BigDecimal("0.0");
        }
    }

    public boolean debit(AccountTelegram at, HasAmount hmt) throws Exception {
        synchronized (domainNameOfAccount) {
            File file = FileAccount.getFile(domainNameOfAccount, true);
            StringBuilder lines = new StringBuilder();
            lines.append(Telegram.NEW_LINE);
            lines.append(at.getTransactionId()).append(Telegram.DELIMITER);
            lines.append(LoaderService.getDateString1()).append(Telegram.DELIMITER);
            lines.append("Debit").append(Telegram.DELIMITER);
            lines.append(hmt.getText().replaceAll(Telegram.DELIMITER, "").trim()).append(Telegram.DELIMITER);
            lines.append(hmt.getAmount()).append(Telegram.DELIMITER);
            lines.append(at.getDomainNameOfOtherAccount()).append(Telegram.DELIMITER);
            if (hmt.isRollback()) {
                lines.append("S").append(Telegram.DELIMITER);
            } else {
                lines.append("R").append(Telegram.DELIMITER);
            }
            lines.append(at.getOriginalTelegram().getIp()).append(Telegram.DELIMITER);
            lines.append(at.getOriginalTelegram().getLinkedDomainName() == null ? "_SELF_" : at.getOriginalTelegram().getLinkedDomainName()).append(Telegram.DELIMITER);
            BigDecimal originalBalance = getOriginalBalance(domainNameOfAccount, file);
            BigDecimal newValue = originalBalance.add(new BigDecimal(hmt.getAmount()));
            CACHE.put(domainNameOfAccount, newValue);
            lines.append(newValue);
            FileAccount.insertLine(domainNameOfAccount, file, lines.toString());
            return true;
        }
    }

    public boolean kredit(AccountTelegram at, HasAmount hmt) throws Exception {
        synchronized (domainNameOfAccount) {
            File file = FileAccount.getFile(domainNameOfAccount, true);
            BigDecimal newSum;
            BigDecimal originalBalance = getOriginalBalance(domainNameOfAccount, file);
            newSum = originalBalance.add(new BigDecimal(-1 * hmt.getAmount()));
            if (at.getBalanceRequired() != null) {
                if (at.getBalanceRequired() > newSum.doubleValue()) {
                    String text = Translater.translate(Translater.NO_NEGATIVE_AMOUNT);
                    throw new IllegalArgumentException(text);
                }
            }
            if (at.getBalanceRequired() != null && newSum.doubleValue() < at.getBalanceRequired()) {
                throw new IllegalStateException(Translater.translate(Translater.NO_NEGATIVE_AMOUNT, newSum));
            }
            CACHE.put(domainNameOfAccount, newSum);
            StringBuilder lines = new StringBuilder();
            lines.append(Telegram.NEW_LINE);
            lines.append(at.getTransactionId()).append(Telegram.DELIMITER);
            lines.append(LoaderService.getDateString1()).append(Telegram.DELIMITER);
            lines.append("Kredit").append(Telegram.DELIMITER);
            lines.append(hmt.getText().replaceAll(Telegram.DELIMITER, "").trim()).append(Telegram.DELIMITER);
            lines.append(-1 * hmt.getAmount()).append(Telegram.DELIMITER);
            lines.append(at.getDomainNameOfOtherAccount()).append(Telegram.DELIMITER);
            if (hmt.isRollback() || at.getOriginalTelegram() instanceof GivemoneyTelegram || at.getOriginalTelegram() instanceof PrintmoneyTelegram) {
                lines.append("S").append(Telegram.DELIMITER);
            } else {
                lines.append("R").append(Telegram.DELIMITER);
            }
            lines.append(at.getOriginalTelegram().getIp()).append(Telegram.DELIMITER);
            lines.append(at.getOriginalTelegram().getLinkedDomainName() == null ? "_SELF_" : at.getOriginalTelegram().getLinkedDomainName()).append(Telegram.DELIMITER);
            lines.append(newSum);
            FileAccount.insertLine(domainNameOfAccount, file, lines.toString());
            return true;
        }
    }

    public boolean rollback(AccountTelegram at, HasAmount hmt) throws Throwable {
        synchronized (domainNameOfAccount) {
            RollbacktransactionTelegram rt = (RollbacktransactionTelegram) at.getOriginalTelegram();
            long blockSize = 1500;
            try {
                blockSize = Long.parseLong(Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "rollbackBlockSize"));
            } catch (Exception ex) {
            }
            List<String> lines = getHistoryLines(domainNameOfAccount, blockSize);
            //while (line != null) {
            for (int i = lines.size() - 1; i >= 0; i--) {
                String line = lines.get(i);
                StringTokenizer tok = new StringTokenizer(line, Telegram.DELIMITER);
                String transactionId = tok.nextToken();
                if (transactionId.equals(rt.getTransactionid2Rollback())) {
                    tok.nextToken(); //dato
                    tok.nextToken(); //type
                    String text = tok.nextToken(); //text
                    Float amount = Float.valueOf(tok.nextToken()); //beløb
                    if (amount == 0) {
                        return true;
                    }
                    String modkonto = tok.nextToken(); //modkonto
                    String rollbackable = tok.nextToken();
                    if (rollbackable.charAt(0) == 'R') {
                        rt.setCounterAccountDomainName(modkonto);
                        Destination source = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountManagerService);
                        if (amount > 0) {
                            //giv penge tilbage (hvis du har dem endnu)
                            AccountTelegram newTelegram = new AccountTelegram(at.getOriginalTelegram(), at.getDomainName(), modkonto, AccountTelegram.Action.Kredit, null, true);
                            kredit(newTelegram, new HasAmountImpl(amount, rt.getText(),true));
                            Destination accountService1 = AccountServiceLookupFactory.getAccountDestinationLookupByDomainNameInstance().getAccountService(modkonto);
                            rt.setAmount(amount);
                            SendRequestFactory.newInstance().sendRequest(source, accountService1, new AccountTelegram(rt, modkonto, at.getDomainName(), AccountTelegram.Action.Debit, null, true));
                            return true;
                        } else if (amount < 0) {
                            //få pengene retur
                            AccountTelegram newTelegram = new AccountTelegram(at.getOriginalTelegram(), at.getDomainName(), modkonto, AccountTelegram.Action.Debit, null, true);
                            debit(newTelegram, new HasAmountImpl(-1 * amount, rt.getText(),true));
                            Destination accountService1 = AccountServiceLookupFactory.getAccountDestinationLookupByDomainNameInstance().getAccountService(modkonto);
                            rt.setAmount(amount);
                            SendRequestFactory.newInstance().sendRequest(source, accountService1, new AccountTelegram(rt, modkonto, at.getDomainName(), AccountTelegram.Action.Kredit, null, true));
                            return true;
                        }
                    } else {
                        AccountServiceLookupFactory.getAccountLookupByTransactionInstance().removeAccounts(rt.getTransactionid2Rollback());
                        throw new IllegalArgumentException(Translater.CANNOT_ROLLBACK);
                    }
                }
            }
            throw new IllegalArgumentException(Translater.CANNOT_FIND_TRANSACTION, new IllegalStateException(rt.getTransactionid2Rollback()));
        }
    }

    private List<String> getHistoryLines(String domainNameOfAccount, long blockSize) throws Exception {
        File file = FileAccount.getFile(domainNameOfAccount, false);
        List<String> lines = null;
        //update lines
        Lines lines2Read = FileAccount.getLastLines(domainNameOfAccount, file, blockSize);
        if (lines2Read != null) {
            lines = lines2Read.getLines();
            while (lines2Read.getStartingIndex() == 0) {
                File previousFile = FileAccount.getPreviousFile(file);
                if (previousFile == null) {
                    break;
                }
                blockSize = blockSize - file.length();
                lines2Read = FileAccount.getLastLines(domainNameOfAccount, previousFile, blockSize);
                if (lines2Read != null) {
                    List<String> moreLines = lines2Read.getLines();
                    //insert forest
                    for (int i = moreLines.size() - 1; i >= 0; i--) {
                        String line = moreLines.get(i);
                        lines.add(0, line);
                    }
                }
                file = previousFile;
            }
        }
        return (lines == null ? new LinkedList<String>() : lines);
    }

    public String getHistory(HistoryTelegram telegram) throws Exception {
        long maxTime2Show = Math.abs(1000 * 60 * 60 * 24 * 10); //sidste 10 dage
        synchronized (domainNameOfAccount) {
            List<String> lines = getHistoryLines(domainNameOfAccount, telegram.getSize());
            //build json or csv
            StringBuilder history = new StringBuilder();
            if (telegram.getOutputType() == HistoryTelegram.OutputType.csv) {
                history.append("Dato");
                history.append("\t");
                history.append("TransactionId");
                history.append("\t");
                history.append("PostingType");
                history.append("\t");
                history.append("Modkonto");
                history.append("\t");
                history.append("Text");
                history.append("\t");
                history.append("Amount");
                history.append("\t");
                history.append("Sum");
            } else if (telegram.getOutputType() == HistoryTelegram.OutputType.json) {
                history.append("{\"Response\": {");
                history.append("\n\t\"CurrentDate\": \"").append(LoaderService.getDateString1()).append("\",");
                history.append("\n\t\"Account\": \"").append(domainNameOfAccount).append("\",");
                history.append("\n\t\"TelegramType\": \"").append(telegram.getClass().getSimpleName()).append("\",");
                history.append("\n\t\"ResponseType\": \"").append(Translater.TRANSACTION_OK).append("\"");
            } else if (telegram.getOutputType() == HistoryTelegram.OutputType.html) {
                //html
                history.append("<table class=\"table\" style=\"background-color:green;\">").append("<tr>")
                        .append("<th class=\"table__heading\" width=20%>Date</th>")
                        .append("<th class=\"table__heading3\" width=10%>Transaction</th>")
                        .append("<th class=\"table__heading2\" width=10%>IP</th>")
                        .append("<th class=\"table__heading2\" width=10%>PostingType</th>")
                        .append("<th class=\"table__heading2\" width=10%>Counter account</th>")
                        .append("<th class=\"table__heading2\" width=10%>Text</th>")
                        .append("<th class=\"table__heading\" width=10%>Amount</th>")
                        .append("<th class=\"table__heading\" width=10%>Total</th></tr>");
            }
            try {
                long firstEntryTime = 0;
                int lastIndex = 0;
                for (int i = lines.size() - 1; i >= lastIndex; i--) {
                    String line = lines.get(i);
                    StringTokenizer tok = new StringTokenizer(line, Telegram.DELIMITER);
                    if (!tok.hasMoreTokens()) {
                        //empty line
                        continue;
                    }
                    String transactionId = tok.nextToken();
                    String dato = tok.nextToken();
                    if (i == lines.size() - 1) {
                        //first index
                        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM/dd HH:mm:ss");
                        try {
                            Date d = f.parse(dato);
                            firstEntryTime = d.getTime();
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    } else if (firstEntryTime != 0) {
                        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM/dd HH:mm:ss");
                        try {
                            Date d = f.parse(dato);
                            long entryTime = d.getTime();
                            if (!((firstEntryTime - maxTime2Show) < entryTime)) {
                                //vis max en måned
                                break;
                            }
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                    String type = tok.nextToken();
                    String txt = tok.nextToken();
                    String amount = tok.nextToken();
                    String otherDomain = tok.nextToken();
                    String rollbackable = tok.nextToken();//rollbackable
                    String ip = tok.nextToken();//ip
                    tok.nextToken();//admin
                    String sum = tok.nextToken();
                    sum = df.format(new BigDecimal(sum));
                    if (telegram.getOutputType() == HistoryTelegram.OutputType.csv) {
                        history.append("\n");
                        history.append(dato);
                        history.append("\t");
                        history.append(transactionId);
                        history.append("\t");
                        history.append(type);
                        history.append("\t");
                        history.append(otherDomain);
                        history.append("\t");
                        history.append(txt);
                        history.append("\t");
                        history.append(amount);
                        history.append("\t");
                        history.append(sum);
                    } else if (telegram.getOutputType() == HistoryTelegram.OutputType.json) {
                        history.append(",\n\t\"Entry\": {");
                        history.append("\n\t\t\"Date\": \"").append(dato).append("\",");
                        history.append("\n\t\t\"TransactionId\": \"").append(transactionId).append("\",");
                        history.append("\n\t\t\"PostingType\": \"").append(type).append("\",");
                        history.append("\n\t\t\"CounterAccount\": \"").append(otherDomain).append("\",");
                        history.append("\n\t\t\"Text\": \"").append(txt).append("\",");
                        history.append("\n\t\t\"Amount\": \"").append(amount).append("\",");
                        history.append("\n\t\t\"Sum\": \"").append(sum).append("\"\n\t}");
                    } else if (telegram.getOutputType() == HistoryTelegram.OutputType.html) {
                        history.append("\n\t<tr class=\"table__row\">");
                        history.append("<td class=\"table__content\" data-heading=\"Date\">").append(dato).append("</td>");
                        history.append("<td class=\"table__content3\" data-heading=\"Transaction\">").append(transactionId).append("</td>");
                        history.append("<td class=\"table__content2\" data-heading=\"IP\">").append(ip).append("</td>");
                        history.append("<td class=\"table__content2\" data-heading=\"Type\">").append(type).append("</td>");
                        history.append("<td class=\"table__content2\" data-heading=\"Counter Account\">").append(otherDomain).append("</td>");
                        history.append("<td class=\"table__content2\" data-heading=\"Text\">").append(txt).append("</td>");
                        history.append("<td class=\"table__content\" data-heading=\"Amount\">").append(amount).append("</td>");
                        history.append("<td class=\"table__content\" data-heading=\"Total\">").append(sum).append("</td>");
                        if (rollbackable.charAt(0)=='R') {
                            history.append("<td class=\"table__content\" data-heading=\"Rollback\">").append("<a href='/json/rollback?transactionid=").append(transactionId).append("&sessionid=").append(telegram.getSessionId()).append("&redirecturl=%2Fhtml%2Fmenu'>Rollback</a>").append("</td>");
                        }
                        else{
                            history.append("<td class=\"table__content\" data-heading=\"Rollback\">").append("Cannot be rolledback").append("</td>");
                        }
                        history.append("</tr>");
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                //end of file
            }
            if (telegram.getOutputType() == HistoryTelegram.OutputType.json) {
                history.append("\n}}");
            } else if (telegram.getOutputType() == HistoryTelegram.OutputType.html) {
                history.append("\n</table>");
            }
            return history.toString();
        }
    }
}
