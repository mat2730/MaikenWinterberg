/*
 * Martin Alexander Thomsen den 9. December 2024
 */
package com.maikenwinterberg.banker.accountManager;

import com.maikenwinterberg.banker.communication.Destination;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.loader.LoaderService;
import com.maikenwinterberg.banker.util.FileReaderFix;
import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.domainname.DomainHandler;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * This implementation is made for 5.000.000 transactions in memory. When a
 * transaction disapears from memory it can no longer be rolled back.
 * 
 * TODO this implementation is only good in the beginning - must be rewritten.
 */
@Deprecated
public class MemoryAccountLookupByTransaction implements IAccountLookupByTransaction {

    private static HashMap<String, List<Destination>> TRANSACTION2ACCOUNTS = null;
    private static BufferedOutputStream bos = null;
    private static int writeCount = 0;

    public HashMap<String, List<Destination>> getMap() throws Exception{
        if (TRANSACTION2ACCOUNTS == null) {
            TRANSACTION2ACCOUNTS = new HashMap();
            //TODO optimize - current solusion is slow at startup but it works.
            String transactionDirectory = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "transactionDirectory");
            if (new File(transactionDirectory + "/transactions.txt").exists()) {
                // works but its a fix
                FileReaderFix fileReader = new FileReaderFix(new File(transactionDirectory + "/transactions.txt"),1000);
                String transactionAsText = fileReader.readLine();
                int count=0;
                while (transactionAsText != null) {
                    //20241210120204:transactionId 0=[accountService1, accountService2]|||﻿
                    int index1 = transactionAsText.indexOf(":");
                    int index2 = transactionAsText.indexOf("=");
                    int index3 = transactionAsText.indexOf(",");
                    String transactionId = transactionAsText.substring(index1 + 1, index2);
                    String account1 = transactionAsText.substring(index2 + 2, index3);
                    String account2 = transactionAsText.substring(index3 + 2,transactionAsText.length()-1);
                    List<Destination> list = new LinkedList();
                    list.add(new Destination(account1.substring(0,account1.indexOf("/")), Destination.ServiceName.valueOf(account1.substring(account1.indexOf("/")+1))));
                    list.add(new Destination(account2.substring(0,account2.indexOf("/")), Destination.ServiceName.valueOf(account2.substring(account2.indexOf("/")+1))));
                    TRANSACTION2ACCOUNTS.put(transactionId, list);
                    count++;
                    transactionAsText = fileReader.readLine();
                }
                System.out.println("loaded db: " + TRANSACTION2ACCOUNTS.keySet().size()+ " of "+ count);
            }
        }
        return TRANSACTION2ACCOUNTS;
    }

    @Override
    public List<Destination> getAccounts(String transactionId) throws Exception{
        return getMap().get(transactionId); 
    }

    @Override
    public void addAccountServices(String transactionId, List<Destination> accountServices) throws Exception {
        //check if allready exists
        if (TRANSACTION2ACCOUNTS == null) {
            writeCount=0;
        }
        List<Destination> accounts = getMap().get(transactionId);
        if (accounts != null) {
            throw new IllegalStateException("tranactionId " + transactionId + " has allready been stored");
        }
        //write to temp file
        if (bos == null) {
            String transactionDirectory = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "transactionDirectory");
            new File(transactionDirectory).mkdirs();
            bos = new BufferedOutputStream(new FileOutputStream(new File(transactionDirectory + "/transactions.txt"), true));
        }

        bos.write((LoaderService.getDateString2() + ":" + transactionId + "=" + accountServices.toString() + Telegram.NEW_LINE).getBytes(Telegram.ENCODING));
        bos.flush();
        writeCount++;
        //write to mem
        TRANSACTION2ACCOUNTS.put(transactionId, accountServices);
    }

    public static void main(String arg[]) throws Exception {
        System.out.println("starting test");
        DefaultAccountLookupByTransaction accountLookup = new DefaultAccountLookupByTransaction();
        for (int i = 0; i < 5000000; i++) {
            List<Destination> list = new LinkedList();
            list.add(new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountService));
            list.add(new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountService));
            accountLookup.addAccountServices("transactionId " + i, list);
        }
        System.out.println("accountLookup test " + accountLookup.getAccounts("transactionId 456") + " of " + TRANSACTION2ACCOUNTS.keySet().size()+" write counts " + writeCount);
    }

    @Override
    public void removeAccounts(String transactionId) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
