/*
 * Martin Alexander Thomsen den 11. December 2024
 */
package com.maikenwinterberg.banker.communication.event.remote;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class RemoteEventListener {
    public static void main(String arg[]) {
        //TODO start server socket
    }
}
