/*
 * Martin Alexander Thomsen den 7. December 2024
 */
package com.maikenwinterberg.banker.communication.event;


/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public abstract class TelegramResponse {
    public abstract boolean isOk();
    public abstract String getStackTrace();
    public abstract String getMessage();
    public abstract String getTransactionId();
};
