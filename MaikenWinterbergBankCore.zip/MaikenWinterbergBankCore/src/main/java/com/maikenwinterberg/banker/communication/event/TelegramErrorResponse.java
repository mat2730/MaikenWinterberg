/*
 * Martin Alexander Thomsen den 7. December 2024
 */
package com.maikenwinterberg.banker.communication.event;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class TelegramErrorResponse extends TelegramResponse {

    private final Throwable throwable;
    private final String transactionId;

    public TelegramErrorResponse(String transactionId, Throwable throwable) {
        this.throwable = throwable;
        this.transactionId = transactionId;
    }

    @Override
    public String getTransactionId() {
        return this.transactionId;
    }

    @Override
    public boolean isOk() {
        return false;
    }

    @Override
    public String getStackTrace() {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        throwable.printStackTrace(pw);
        String sStackTrace = sw.toString();
        return sStackTrace;
    }

    @Override
    public String getMessage() {
        return throwable.getMessage();
    }
}
