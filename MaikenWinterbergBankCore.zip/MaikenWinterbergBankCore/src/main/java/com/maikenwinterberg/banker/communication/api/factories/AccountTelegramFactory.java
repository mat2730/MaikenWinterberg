/*
 * Martin Alexander Thomsen den 12. December 2024
 */
package com.maikenwinterberg.banker.communication.api.factories;

import com.maikenwinterberg.banker.communication.api.BalanceTelegram;
import com.maikenwinterberg.banker.communication.api.HistoryTelegram;
import com.maikenwinterberg.banker.communication.api.LinkTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.api.TrustdomainsTelegram;
import com.maikenwinterberg.banker.communication.api.UnlinkTelegram;
import static com.maikenwinterberg.banker.util.Base64ToFile.toBase64;
import com.maikenwinterberg.config.Config;
import java.io.File;
import java.io.FileOutputStream;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class AccountTelegramFactory {

    public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy");

    public static String doBalanceTelegram(String domainName, String inbox, String transactionId) throws Exception {
        if (inbox == null) {
            inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "inboxDirectory");
        }
        new File(inbox + "/" + domainName).mkdirs();
        if (transactionId == null) {
            transactionId = TransactionIdCreator.getTransactionId();
        }
        File file = new File(inbox + "/" + domainName + "/balance_" + transactionId);
        FileOutputStream fos = new FileOutputStream(file);
        String csv = "getBalance(" + domainName + ")";
        fos.write(csv.getBytes(Telegram.ENCODING));
        fos.flush();
        fos.close();
        file.renameTo(new File(file.getAbsolutePath() + ".csv"));
        return csv;
    }

    public static Telegram createBalanceTelegram(String ip, String sessionId, String domainName) throws Exception {
        String inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "telegramFactoryDirectory");
        String transactionId = TransactionIdCreator.getTransactionId();
        String csv = doBalanceTelegram(domainName, inbox, transactionId);
        BalanceTelegram t = new BalanceTelegram();
        t.setDomainName(ip, sessionId, domainName);
        t.setTransactionId(transactionId);
        t.setFile(new File(inbox + "/" + domainName + "/balance_" + transactionId), 0);
        t.setCsvLine(csv);
        return t;
    }

    public static String doTrushTelegram(String domainName, String trustedDomains, boolean append, boolean reversed, String inbox, String transactionId) throws Exception {
        if (inbox == null) {
            inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "inboxDirectory");
        }
        new File(inbox + "/" + domainName).mkdirs();
        if (transactionId == null) {
            transactionId = TransactionIdCreator.getTransactionId();
        }
        File file = new File(inbox + "/" + domainName + "/trustdomains_" + transactionId);
        FileOutputStream fos = new FileOutputStream(file);
        StringBuilder b = new StringBuilder();
        b.append(trustedDomains);
        b.append(Telegram.DELIMITER);
        b.append(append);
        b.append(Telegram.DELIMITER);
        b.append(reversed);
        String csv = b.toString();
        fos.write(csv.getBytes(Telegram.ENCODING));
        fos.flush();
        fos.close();
        file.renameTo(new File(file.getAbsolutePath() + ".csv"));
        return csv;
    }

    public static Telegram createTrustTelegram(String ip, String sessionId, String domainName, String trustedDomains, boolean append, boolean reversed) throws Exception {
        String inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "telegramFactoryDirectory");
        String transactionId = TransactionIdCreator.getTransactionId();
        String csv = doTrushTelegram(domainName, trustedDomains, append, reversed, inbox, transactionId);
        TrustdomainsTelegram t = new TrustdomainsTelegram();
        t.setDomainName(ip, sessionId, domainName);
        t.setTransactionId(transactionId);
        t.setFile(new File(inbox + "/" + domainName + "/trustdomains_" + transactionId), 0);
        t.setCsvLine(csv);
        return t;
    }

    public static String doHistoryTelegram(String domainName, String inbox, String transactionId, HistoryTelegram.OutputType type, long size) throws Exception {
        if (inbox == null) {
            inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "inboxDirectory");
        }
        new File(inbox + "/" + domainName).mkdirs();
        if (transactionId == null) {
            transactionId = TransactionIdCreator.getTransactionId();
        }
        File file = new File(inbox + "/" + domainName + "/history_" + transactionId);
        FileOutputStream fos = new FileOutputStream(file);
        String csv = type.toString()+Telegram.DELIMITER+size;
        fos.write(csv.getBytes(Telegram.ENCODING));
        fos.flush();
        fos.close();
        file.renameTo(new File(file.getAbsolutePath() + ".csv"));
        return csv;
    }

    public static Telegram createHistoryTelegram(String ip, String sessionId, String domainName, HistoryTelegram.OutputType type, long size) throws Exception {
        String inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "telegramFactoryDirectory");
        String transactionId = TransactionIdCreator.getTransactionId();
        String csv = doHistoryTelegram(domainName, inbox, transactionId, type, size);
        HistoryTelegram t = new HistoryTelegram();
        t.setDomainName(ip, sessionId, domainName);
        t.setFile(new File(inbox + "/" + domainName + "/history_" + transactionId), 0);
        t.setTransactionId(transactionId);
        t.setCsvLine(csv);
        return t;
    }

    public static String doLinkTelegram(String domainName, String passportnumber, List<File> attachments, String inbox, String transactionId) throws Exception {
        StringBuilder builder = new StringBuilder();
        builder.append(passportnumber);
        if (attachments != null) {
            for (Iterator<File> i = attachments.iterator(); i.hasNext();) {
                File f = i.next();
                builder.append(Telegram.DELIMITER);
                builder.append(f.getName());
                builder.append(Telegram.DELIMITER);
                builder.append(toBase64(f));
            }
        }
        //SAVE
        if (inbox == null) {
            inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "inboxDirectory");
        }
        new File(inbox + "/" + domainName).mkdirs();
        if (transactionId == null) {
            transactionId = TransactionIdCreator.getTransactionId();
        }
        File file = new File(inbox + "/" + domainName + "/link_" + transactionId);
        try (FileOutputStream fos = new FileOutputStream(file)) {
            fos.write(builder.toString().getBytes(Telegram.ENCODING));
            fos.flush();
        }
        file.renameTo(new File(file.getAbsolutePath() + ".csv"));
        return builder.toString();
    }

    public static Telegram createLinkTelegram(String ip, String sessionId, String domainName, String passportnumber, List<File> attachments) throws Exception {
        String inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "telegramFactoryDirectory");
        String transactionId = TransactionIdCreator.getTransactionId();
        String csv = doLinkTelegram(domainName, passportnumber, attachments, inbox, transactionId);
        LinkTelegram t = new LinkTelegram();
        t.setDomainName(ip, sessionId, domainName);
        t.setFile(new File(inbox + "/" + domainName + "/link_" + transactionId), 0);
        t.setTransactionId(transactionId);
        t.setCsvLine(csv);
        return t;
    }

    public static String doUnlinkTelegram(String domainName, String passportnumber, String inbox, String transactionId) throws Exception {
        StringBuilder builder = new StringBuilder();
        builder.append(passportnumber);
        //SAVE
        if (inbox == null) {
            inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "inboxDirectory");
        }
        new File(inbox + "/" + domainName).mkdirs();
        if (transactionId == null) {
            transactionId = TransactionIdCreator.getTransactionId();
        }
        File file = new File(inbox + "/" + domainName + "/unlink_" + transactionId);
        try (FileOutputStream fos = new FileOutputStream(file)) {
            fos.write(builder.toString().getBytes(Telegram.ENCODING));
            fos.flush();
        }
        file.renameTo(new File(file.getAbsolutePath() + ".csv"));
        return builder.toString();
    }

    public static Telegram createUnlinkTelegram(String ip, String sessionId, String domainName, String passportnumber) throws Exception {
        String inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "telegramFactoryDirectory");
        String transactionId = TransactionIdCreator.getTransactionId();
        String csv = doUnlinkTelegram(domainName, passportnumber, inbox, transactionId);
        UnlinkTelegram t = new UnlinkTelegram();
        t.setDomainName(ip, sessionId, domainName);
        t.setFile(new File(inbox + "/" + domainName + "/unlink_" + transactionId), 0);
        t.setTransactionId(transactionId);
        t.setCsvLine(csv);
        return t;
    }
}
