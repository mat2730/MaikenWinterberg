/*
 * Martin Alexander Thomsen den 5. December 2024
 */
package com.maikenwinterberg.banker.account;

import com.maikenwinterberg.banker.communication.Destination;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.IReceiveRequest;
import com.maikenwinterberg.banker.communication.api.AccountTelegram;
import com.maikenwinterberg.banker.communication.api.HasAmount;
import com.maikenwinterberg.banker.communication.api.HistoryTelegram;
import com.maikenwinterberg.banker.communication.event.CommunicationEvent;
import com.maikenwinterberg.banker.communication.event.LocalEvents;
import com.maikenwinterberg.banker.communication.event.TelegramOKResponse;
import com.maikenwinterberg.banker.communication.translate.JsonConverter;
import com.maikenwinterberg.banker.communication.translate.Translater;
import com.maikenwinterberg.domainname.DomainHandler;
import java.io.File;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * Each AccountService is responsible for administrating x number of accounts
 *
 * @see
 * https://stackoverflow.com/questions/28953928/how-to-set-cursor-at-the-beginning-of-the-txt-file
 */
public class AccountService implements IReceiveRequest {

    @Override
    public String receiveRequest(Telegram telegram) throws Throwable {
        if (telegram instanceof AccountTelegram) {
            //init bean
            AccountTelegram at = (AccountTelegram) telegram;
            String domainName = at.getDomainName();
            AccountBean bean = new AccountBean(domainName);
            //init amount
            HasAmount hmt = null;
            Telegram originalTelegram = at.getOriginalTelegram();
            if (originalTelegram instanceof HasAmount) {
                hmt = (HasAmount) originalTelegram;
            }
            //update bean
            if (at.getAction() == AccountTelegram.Action.Debit) {
                bean.debit(at, hmt);
            } else if (at.getAction() == AccountTelegram.Action.Kredit) {
                bean.kredit(at, hmt);
            } else if (at.getAction() == AccountTelegram.Action.Balance) {
                Destination source = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountService);
                Destination destination = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.loaderService);
                File f = FileAccount.getFile(domainName, false);
                String balance = AccountBean.df.format(AccountBean.getOriginalBalance(domainName, f));
                String text = Translater.translate(Translater.SHOW_SALDO, balance);
                text = JsonConverter.toJson(telegram, true, text);
                CommunicationEvent ce = new CommunicationEvent(source, destination, at, new TelegramOKResponse(at.getTransactionId(),text));
                LocalEvents.fireEvent(ce);
                return text;
            } else if (at.getAction() == AccountTelegram.Action.History) {
                Destination source = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountService);
                Destination destination = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.loaderService);
                String text = bean.getHistory((HistoryTelegram) originalTelegram);
                CommunicationEvent ce = new CommunicationEvent(source, destination, at, new TelegramOKResponse(at.getTransactionId(),text));
                LocalEvents.fireEvent(ce);
                //is allready a json
                return text;
            } else if (at.getAction() == AccountTelegram.Action.Rollback) {
                bean.rollback(at, hmt);
            }
            String text = Translater.translate(Translater.TRANSACTION_OK);
            return text;
        }
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
