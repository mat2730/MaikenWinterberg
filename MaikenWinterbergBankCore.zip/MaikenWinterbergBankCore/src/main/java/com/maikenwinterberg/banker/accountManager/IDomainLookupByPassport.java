/*
 * Martin Alexander Thomsen den 11. December 2024
 */
package com.maikenwinterberg.banker.accountManager;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IDomainLookupByPassport {
    public String getDomainName(String passportNumber)throws Exception;
    public String getDomainName(String passportNumber, boolean forcelookup) throws Exception;
    public void link(String passportNumber, String domainName) throws Exception;
    public void unLink(String passportNumber, String domainName) throws Exception;;
}
