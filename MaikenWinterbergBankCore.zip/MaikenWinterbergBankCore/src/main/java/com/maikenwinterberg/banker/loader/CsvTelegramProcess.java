/*
 * Martin Alexander Thomsen den 18. December 2024
 */
package com.maikenwinterberg.banker.loader;

import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.api.factories.TelegramFactory;
import com.maikenwinterberg.banker.communication.event.CommunicationEvent;
import com.maikenwinterberg.banker.communication.event.TelegramErrorResponse;
import com.maikenwinterberg.banker.communication.event.TelegramResponse;
import static com.maikenwinterberg.banker.loader.LoaderService.appendDate2FileName;
import com.maikenwinterberg.banker.util.FileReaderFix;
import com.maikenwinterberg.config.Config;
import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.Callable;
import javafixes.concurrency.Runner;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class CsvTelegramProcess implements Runnable, Callable<Object> {

    public static Runner executor;

    static {
        int number = 10;
        try {
            String numberOfSendHandlerThreads = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "numberOfThreadsInLoader");
            number = Integer.parseInt(numberOfSendHandlerThreads);
        } catch (Exception ex) {
            //ignore
        }
        executor = Runner.runner(number);
    }
    private final File processedDirectory;
    private final String domainName;
    private final File csvFile;

    public CsvTelegramProcess(File processedDirectory, String domainName, File csvFile) {
        this.processedDirectory = processedDirectory;
        this.domainName = domainName;
        this.csvFile = csvFile;
    }

    @Override
    public Object call() throws Exception {
        run();
        return null;
    }

    @Override
    public void run() {
        int telegramIndex = 0;
        try {
            FileReaderFix fileReader = new FileReaderFix(csvFile);
            String tiffanyLine = fileReader.readLine();
            while (tiffanyLine != null) {
                Telegram telegram = null;
                try {
                    telegram = TelegramFactory.getBankRequest("127.0.0.1", null, domainName, csvFile, telegramIndex, tiffanyLine);
                    LoadBalancer.handleRequest(telegram);
                    tiffanyLine = fileReader.readLine();
                } catch (Exception exe) {
                    if (telegram != null) {
                        log(processedDirectory, domainName, csvFile, new TelegramErrorResponse(telegram.getTransactionId(), exe), telegramIndex);
                    } else {
                        log(processedDirectory, domainName, csvFile, new TelegramErrorResponse(LoaderService.getDateString2(), exe), telegramIndex);
                    }
                } finally {
                    telegramIndex++;
                }
            }
        } catch (Throwable ex) {
            //TODO only on callback
            log(processedDirectory, domainName, csvFile, new TelegramErrorResponse(LoaderService.getDateString2(), ex), telegramIndex);
        }
        try {
            if (processedDirectory != null) {
                String deleteProcessedFiles = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "deleteProcessedFiles");
                if (deleteProcessedFiles != null && deleteProcessedFiles.equalsIgnoreCase("true")) {
                    csvFile.delete();
                } else {
                    new File(processedDirectory.getAbsolutePath() + "/" + domainName + "/" + Telegram.getDateString()).mkdirs();
                    File newFileName = new File(processedDirectory.getAbsolutePath() + "/" + domainName + "/" + Telegram.getDateString() + "/" + appendDate2FileName(csvFile.getName()));
                    //Files.move(newFile.toPath(), newFileName.toPath());
                    csvFile.renameTo(newFileName);
                }
            }
        } catch (Exception ex) {
            log(processedDirectory, domainName, csvFile, new TelegramErrorResponse(LoaderService.getDateString2(), ex), -1);
        }
    }

    public static void log(File processedDirectory, String domainName, File telegramFile, TelegramResponse response, int index) {
        if (domainName == null) {
            return;
        }
        if (response == null || response.getTransactionId() == null) {
            //only log if the response contains a transactionId
            return;
        }
        boolean disableLog = false;
        try {
            disableLog = Boolean.parseBoolean(Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "disableTransactions"));
        } catch (Exception ex) {
        }
        if (disableLog) {
            return;
        }
        //handle log
        int index2 = response.getTransactionId().lastIndexOf("_");
        int index1 = response.getTransactionId().substring(0, index2).lastIndexOf("_");
        String timestamp = response.getTransactionId().substring(index1 + 1);
        String fist6 = timestamp.substring(0, 6);
        File logFile = new File(processedDirectory.getAbsolutePath() + "/" + fist6 + "/private/" + domainName + "/" + timestamp + ".json");
        //File logFile = new File(processedDirectory.getAbsolutePath() + "/" + domainName + "/" + response.getTransactionId() + ".json");
        String newLine = "";
        if (!logFile.exists()) {
            try {
                logFile.getParentFile().mkdirs();
                logFile.createNewFile();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        if (logFile.exists()) {
            if (logFile.length() != 0) {
                newLine = "\n";
            }
            try (FileOutputStream fos = new FileOutputStream(logFile, true)) {
                //String fileName2Show = telegramFile.getParentFile().getName() + "/" + telegramFile.getName();
                if (response instanceof TelegramErrorResponse) {
                    TelegramErrorResponse r = (TelegramErrorResponse) response;
                    fos.write(r.getMessage().getBytes(Telegram.ENCODING));
                    //fos.write((newLine + getDateString1() + ": " + r.getMessage() + " of file:" + fileName2Show + " of index " + index).getBytes(Telegram.ENCODING));
                    fos.flush();
                } else {
                    fos.write(response.getMessage().getBytes(Telegram.ENCODING));
                    fos.flush();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void log(File processedDirectory, String domainName, File telegramFile, CommunicationEvent event) {
        log(processedDirectory, domainName, telegramFile, event.getResponse(), event.getTelegram().getTelegramIndex());
    }

    public static void processCsv(File processedDirectory, String domainName, File csvFile) throws Throwable {
        executor.run(new CsvTelegramProcess(processedDirectory, domainName, csvFile));
    }
}
