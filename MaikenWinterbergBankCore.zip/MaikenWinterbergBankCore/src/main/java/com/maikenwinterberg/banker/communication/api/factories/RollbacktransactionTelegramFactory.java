/*
 * Martin Alexander Thomsen den 18. December 2024
 */
package com.maikenwinterberg.banker.communication.api.factories;

import com.maikenwinterberg.banker.communication.api.RollbacktransactionTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.translate.Translater;
import com.maikenwinterberg.config.Config;
import java.io.File;
import java.io.FileOutputStream;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class RollbacktransactionTelegramFactory {

    private final File file;
    private final FileOutputStream fos;
    private boolean first = true;
    private final String transactionId;

    public RollbacktransactionTelegramFactory(String domainName, String inbox) throws Exception {
        if (inbox == null) {
            inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "inboxDirectory");
        }
        new File(inbox + "/" + domainName).mkdirs();
        this.transactionId = TransactionIdCreator.getTransactionId();
        file = new File(inbox + "/" + domainName + "/rollbacktransaction_" + transactionId);
        fos = new FileOutputStream(file);
    }

    public static Telegram createRollbackTelegram(String ip,  String sessionId, String domainName, String transactionId2BeRolledBack) throws Exception {
        String inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "telegramFactoryDirectory");
        RollbacktransactionTelegramFactory f = new RollbacktransactionTelegramFactory(domainName, inbox);
        String csv = f.addRollbackLine(transactionId2BeRolledBack, Translater.ROLLBACK);
        RollbacktransactionTelegram gt = new RollbacktransactionTelegram();
        gt.setDomainName(ip, sessionId, domainName);
        gt.setFile(new File(inbox + "/" + domainName + "/rollbacktransaction_" + f.transactionId), 0);
        gt.setTransactionId(f.transactionId);
        gt.setCsvLine(csv);
        return gt;
    }

    public String addRollbackLine(String transactionId, String text) throws Exception {
        StringBuilder builder = new StringBuilder();
        if (!first) {
            builder.append(Telegram.NEW_LINE);
        }
        first = false;
        builder.append(transactionId);
        builder.append(Telegram.DELIMITER);
        if (text == null) {
            text = " ";
        }
        builder.append(text);
        fos.write(builder.toString().getBytes(Telegram.ENCODING));
        return builder.toString();
    }

    public void commit() throws Exception {
        fos.flush();
        fos.close();
        file.renameTo(new File(file.getAbsolutePath() + ".csv"));
    }
}
