/*
 * Martin Alexander Thomsen den 19 December 2024
 */
package com.maikenwinterberg.banker.http;

import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.translate.JsonConverter;
import com.maikenwinterberg.config.Config;
import java.io.File;
import java.util.Map;

import org.veryquick.embweb.EmbeddedServer;
import org.veryquick.embweb.Response;
import org.veryquick.embweb.handlers.FileBasedRequestHandler;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.StringTokenizer;
import javax.swing.filechooser.FileSystemView;
import org.veryquick.embweb.HttpRequestHandler;
import org.veryquick.embweb.handlers.MimeTypeParser;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class StartHttps {

    public static void main(String[] args) throws Exception {
        try {
            FileSystemView view = FileSystemView.getFileSystemView();
            String configFolder = view.getHomeDirectory().getAbsolutePath();
            File KEYSTORE_FILE = new File(configFolder + "/config/bankerConfig/KeyStore.jks");
            if (!KEYSTORE_FILE.exists()) {
                KEYSTORE_FILE = new File("config/bankerConfig/KeyStore.jks");
            }
            if (KEYSTORE_FILE.exists()) {
                if (System.getProperty("javax.net.ssl.keyStore") == null) {
                    System.setProperty("javax.net.ssl.keyStore", KEYSTORE_FILE.getAbsolutePath());
                }
                if (System.getProperty("javax.net.ssl.keyStorePassword") == null) {
                    System.setProperty("javax.net.ssl.keyStorePassword", "123456");
                }
            }
        } catch (Exception ex) {
            System.out.println("unable to initialize ssl");
            ex.printStackTrace();
        }
        try {
            int port = 8080;
            try {
                String portAsString = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "port");
                port = Integer.parseInt(portAsString);
            } catch (Exception ex) {
            }
            EmbeddedServer.createInstance(port, new FileBasedRequestHandler(
                    new File("www")) {
                @Override
                public Response handleRequest(HttpRequestHandler.Type type, String hostName, String url,
                        Map<String, String> parameters) {
                    Response response = new Response();
                    String sessionId = parameters.get("GET_sessionid");
                    String ip = parameters.get("REMOTE_IP");
                    if (ip != null) {
                        StringTokenizer tok = new StringTokenizer(ip, "/:");
                        ip = tok.nextToken();
                    }
                    try {
                        url = URLDecoder.decode(url, StandardCharsets.UTF_8.toString());
                        if (url.contains("/json/")) {
                            try {
                                return JsonHandleRequest.newInstance().handleRequest(ip, sessionId, url, parameters);
                            } catch (Throwable t) {
                                t.printStackTrace();
                            }
                        } else if (url.contains("/html/")) {
                            try {
                                return HtmlHandleRequest.newInstance().handleRequest(ip, sessionId, url, parameters);
                            } catch (Throwable t) {
                                t.printStackTrace();
                            }
                        } else {
                            //handle files
                            if (url.trim().isEmpty() || url.equals("/")) {
                                url = "index.html";
                            }
                        }
                        return super.handleRequest(type, hostName, url, parameters);
                    } catch (Throwable ex) {
                        String text = JsonConverter.toJson(null, ex);
                        response.setContentType(MimeTypeParser.getInstance().getType("json"));
                        try {
                            response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                        } catch (Exception exe) {
                            response.setError(exe);
                        }
                        return response;
                    }
                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
