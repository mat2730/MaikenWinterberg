/*
 * Martin Alexander Thomsen den 23. December 2024
 */
package com.maikenwinterberg.banker.communication.api;

import static com.maikenwinterberg.banker.communication.api.Telegram.getDateString;
import com.maikenwinterberg.banker.loader.LoaderService;
import com.maikenwinterberg.banker.util.Base64ToFile;
import com.maikenwinterberg.config.Config;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class ApproveBankTelegram extends Telegram {

    private String accountOfBank;
    private String text;
    private boolean delete;
    private final List images = new LinkedList();

    @Override
    public void setCsvLine(String csvLine) throws Exception {
        StringTokenizer tok = new StringTokenizer(csvLine, Telegram.DELIMITER);
        accountOfBank = tok.nextToken();
        if (tok.hasMoreTokens()) {
            this.text = tok.nextToken();
        }
        if (tok.hasMoreTokens()) {
            delete = Boolean.parseBoolean(tok.nextToken());
        }
        String saveAttachments = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "saveAttachments");
        String imageDirectory = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "imageDirectory");
        while (tok.hasMoreTokens()) {
            String nameOfAttachment = tok.nextToken();
            String base64 = tok.nextToken();
            String fileName = "/" + getDomainName() + "/" + getDateString() + "/" + getClass().getSimpleName() + "/" + LoaderService.appendDate2FileName(nameOfAttachment);
            String fullFileName = imageDirectory + fileName;
            if (saveAttachments != null && saveAttachments.equalsIgnoreCase("false")) {
                continue;
            }
            Base64ToFile.toFile(base64, fullFileName);
            images.add(fullFileName);
        }
    }

    public String getBankAccount() {
        return accountOfBank;
    }

    public boolean isDelete() {
        return delete;
    }

    public List getImages() {
        return images;
    }
    @Override
    public String getTransactionId() {
        return null;
    }

}
