/*
 * Martin Alexander Thomsen den 18. December 2024
 */
package com.maikenwinterberg.banker.communication.api;

import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class RollbacktransactionTelegram extends Telegram implements HasAmount {

    private String transactionid2Rollback;
    private String text;
    private Float value;
    private String counterAccountDomainName;

    public String getCounterAccountDomainName() {
        return counterAccountDomainName;
    }

    public void setCounterAccountDomainName(String counterAccountDomainName) {
        this.counterAccountDomainName = counterAccountDomainName;
    }

    @Override
    public void setCsvLine(String csvLine) throws Exception {
        StringTokenizer tok = new StringTokenizer(csvLine, Telegram.DELIMITER);
        this.transactionid2Rollback = tok.nextToken();
        this.text = tok.nextToken();
    }

    public String getTransactionid2Rollback() {
        return transactionid2Rollback;
    }

    @Override
    public String getText() {
        return text;
    }

    public void setAmount(Float value) {
        this.value = value;
    }

    @Override
    public float getAmount() {
        return value;
    }
    
    @Override
    public boolean isRollback() {
        return true;
    }
}
