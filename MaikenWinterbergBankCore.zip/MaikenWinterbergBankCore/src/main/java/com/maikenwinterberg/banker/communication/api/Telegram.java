/*
 * Martin Alexander Thomsen den 5. December 2024
 */
package com.maikenwinterberg.banker.communication.api;

import com.maikenwinterberg.banker.accountManager.AccountServiceLookupFactory;
import java.io.File;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public abstract class Telegram {

    public static String LOCAL_BANK = "localhost";

    private final static Map<Integer, String> DOMAINNAMES = new HashMap();

    public static enum Destination {
        Loader, AccountManager, AccountCollector, Account
    }

    public static final String DELIMITER = "|";

    public static final String NEW_LINE = "\n"; //the combination '\n' and utf-16 does not work.

    public static final String ENCODING = "ISO-8859-1";

    public static final DateTimeFormatter ZDT_FORMATTER = DateTimeFormatter.ofPattern("yyyyMM");
    private String sessionId;
    private String ip;
    private String domainName;
    private String linkedDomainName;
    private File file;
    private int telegramIndex;
    private String transactionId;

    public void setDomainName(String ip, String sessionId, String domainName) {
        //ensures that the domainName can be use for synchronization
        this.ip = ip;
        this.sessionId = sessionId;
        String CACHED_DOMAINNAME = DOMAINNAMES.get(domainName.hashCode());
        if (CACHED_DOMAINNAME == null) {
            DOMAINNAMES.put(domainName.hashCode(), domainName);
        } else {
            domainName = CACHED_DOMAINNAME;
        }
        String domainName2 = null;
        try {
            domainName2 = AccountServiceLookupFactory.getDomainLookupByPassportInstance().getDomainName(domainName, true);
        } catch (Exception ex) {
        }
        if (domainName2 != null && domainName2.contains(".")) {
            //ensures that the domainName can be use for synchronization
            CACHED_DOMAINNAME = DOMAINNAMES.get(domainName2.hashCode());
            if (CACHED_DOMAINNAME == null) {
                DOMAINNAMES.put(domainName2.hashCode(), domainName2);
            } else {
                domainName2 = CACHED_DOMAINNAME;
            }
            this.linkedDomainName = domainName;
            this.domainName = domainName2;
        } else {
            this.domainName = domainName;
        }
    }

    public String getDomainName() {
        return this.domainName;
    }

    public String getLinkedDomainName() {
        return this.linkedDomainName;
    }

    public void setFile(File file, int telegramIndex) {
        this.file = file;
        this.telegramIndex = telegramIndex;
        String fileName = file.getName();
        int index1 = fileName.indexOf("_");
        int index2 = fileName.indexOf(".");
        if (index1 != -1 && index2 != -1 && index2 > index1) {
            this.transactionId = fileName.substring(index1 + 1, index2);
        } else {
            this.transactionId = "";
        }
    }

    public File getFile() {
        return this.file;
    }

    public int getTelegramIndex() {
        return telegramIndex;
    }

    public void setTransactionId(String simpleTransactionId) {
        this.transactionId = simpleTransactionId;
    }

    public String getTransactionId() {
        if (transactionId == null || transactionId.trim().isEmpty()) {
            return null;
        }
        return domainName + "_" + transactionId + "_" + getTelegramIndex();
    }

    @Override
    public String toString() {
        return "Telegram{" + "domainName=" + domainName + ", file=" + file + ", telegramIndex=" + telegramIndex + ", transactionId=" + transactionId + '}';
    }

    public static String getDateString() {
        return ZDT_FORMATTER.format(ZonedDateTime.now());
    }

    public String getIp() {
        return this.ip;
    }

    public String getSessionId() {
        return sessionId;
    }

    public abstract void setCsvLine(String csvLine) throws Exception;

}
