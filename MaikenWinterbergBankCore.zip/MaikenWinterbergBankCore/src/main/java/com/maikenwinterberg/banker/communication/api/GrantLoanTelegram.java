/*
 * Martin Alexander Thomsen den 23. December 2024
 */
package com.maikenwinterberg.banker.communication.api;

import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class GrantLoanTelegram extends Telegram {

    private String account;
    private Float maxAmount;
    private boolean delete;

    @Override
    public void setCsvLine(String csvLine) throws Exception {
        StringTokenizer tok = new StringTokenizer(csvLine, Telegram.DELIMITER);
        account = tok.nextToken();
        if (tok.hasMoreTokens()) {
            maxAmount = Float.parseFloat(tok.nextToken());
        }
        if (tok.hasMoreTokens()) {
            delete = Boolean.parseBoolean(tok.nextToken());
        }
    }

    public String getAccount() {
        return account;
    }

    public Float getMaxAmount() {
        return maxAmount;
    }

    public boolean isDelete() {
        return delete;
    }
    
}
