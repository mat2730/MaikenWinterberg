/*
 * Martin Alexander Thomsen den 7. December 2024
 */
package com.maikenwinterberg.banker.communication.api.test;

import com.maikenwinterberg.banker.communication.api.HistoryTelegram;
import com.maikenwinterberg.banker.communication.api.factories.AccountTelegramFactory;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class PrintHistoryTestTelegrams {

    public static void main(String arg[]) throws Exception {
        AccountTelegramFactory.doHistoryTelegram("127.0.0.1",null,null, HistoryTelegram.OutputType.json,-1);
        AccountTelegramFactory.doHistoryTelegram("maikenwinterberg.com",null,null, HistoryTelegram.OutputType.json,-1);
        AccountTelegramFactory.doHistoryTelegram("documentnetwork.com",null,null, HistoryTelegram.OutputType.json,-1);
    }
}
