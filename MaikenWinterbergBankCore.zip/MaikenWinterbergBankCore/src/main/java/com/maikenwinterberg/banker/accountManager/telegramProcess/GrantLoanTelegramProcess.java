/*
 * Martin Alexander Thomsen den 23. December 2024
 */
package com.maikenwinterberg.banker.accountManager.telegramProcess;

import com.maikenwinterberg.banker.accountManager.DefaultTrustDomainsImpl;
import com.maikenwinterberg.banker.communication.IReceiveRequest;
import com.maikenwinterberg.banker.communication.api.GrantLoanTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.event.CommunicationEvent;
import com.maikenwinterberg.banker.communication.event.LocalEvents;
import com.maikenwinterberg.banker.communication.event.TelegramErrorResponse;
import com.maikenwinterberg.banker.communication.event.TelegramOKResponse;
import com.maikenwinterberg.banker.communication.translate.JsonConverter;
import com.maikenwinterberg.banker.communication.translate.Translater;
import com.maikenwinterberg.banker.util.DomainVerifier;
import com.maikenwinterberg.config.Config;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class GrantLoanTelegramProcess implements IReceiveRequest {

    @Override
    public String receiveRequest(Telegram telegram) throws Throwable {
        try {
            GrantLoanTelegram gbt = (GrantLoanTelegram) telegram;
            String bankName = gbt.getDomainName();
            String bankdirectory = DefaultTrustDomainsImpl.getDomainDirectory(bankName);
            File f = new File(bankdirectory + "/bank");
            if (!f.exists() && gbt.getLinkedDomainName() != null) {
                bankName = gbt.getLinkedDomainName();
                bankdirectory = DefaultTrustDomainsImpl.getDomainDirectory(bankName);
                f = new File(bankdirectory + "/bank");
            }
            if (!f.exists()) {
                String defaultBank = null;
                try {
                    defaultBank = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "defaultBank");
                } catch (Exception ex) {
                }
                if (defaultBank != null && (defaultBank.equals(gbt.getDomainName()) || defaultBank.equals(gbt.getLinkedDomainName()))) {
                    //its the default bank create it.
                    bankName = defaultBank;
                    f.mkdirs();
                } else {
                    String text = Translater.translate(Translater.NO_PERMISTION);
                    text = JsonConverter.toJson(telegram, false, text);
                    CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(), new IllegalStateException(text)));
                    LocalEvents.fireEvent(ce);
                    return text;
                }
            }
            DomainVerifier.verifyDomain(gbt.getAccount(), false);
            File f2 = new File(f.getAbsolutePath() + "/" + gbt.getAccount() + ".txt");
            String attributes = null;
            try (FileInputStream fis = new FileInputStream(f2)) {
                byte[] d = new byte[fis.available()];
                fis.read(d);
                attributes = new String(d, Telegram.ENCODING);
            } catch (Exception ex) {
            }
            Float maxLoan = Float.valueOf("0");
            Float currentLoan = Float.valueOf("0");
            if (attributes != null) {
                StringTokenizer tok = new StringTokenizer(attributes, Telegram.DELIMITER);
                if (tok.hasMoreTokens()) {
                    try {
                        maxLoan = Float.valueOf(tok.nextToken());
                    } catch (Exception ex) {
                    }
                } else if (tok.hasMoreTokens()) {
                    try {
                        currentLoan = Float.valueOf(tok.nextToken());
                    } catch (Exception ex) {
                    }
                }
            }
            if (gbt.isDelete()) {
                maxLoan = Float.valueOf("0");
            } else {
                maxLoan = gbt.getMaxAmount();
            }
            try (FileOutputStream fos = new FileOutputStream(f2)) {
                fos.write((maxLoan + Telegram.DELIMITER + currentLoan).getBytes(Telegram.ENCODING));
            } catch (Exception ex) {
            }
            if (f2.exists()) {
                String text = Translater.translate(gbt.getMaxAmount(), Translater.LOAN_GRANTED, gbt.getAccount(), Translater.IN_BANK, bankName);
                text = JsonConverter.toJson(telegram, true, text);
                CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramOKResponse(telegram.getTransactionId(), text));
                LocalEvents.fireEvent(ce);
                return text;
            } else {
                String text = Translater.translate(Translater.UNKNOWN_ERROR, telegram.getTransactionId());
                text = JsonConverter.toJson(telegram, false, text);
                CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramOKResponse(telegram.getTransactionId(), text));
                LocalEvents.fireEvent(ce);
                return text;
            }
        } catch (Exception ex) {
            String text = JsonConverter.toJson(telegram, ex);
            CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(), new IllegalStateException(text)));
            LocalEvents.fireEvent(ce);
            return text;
        }
    }
}
