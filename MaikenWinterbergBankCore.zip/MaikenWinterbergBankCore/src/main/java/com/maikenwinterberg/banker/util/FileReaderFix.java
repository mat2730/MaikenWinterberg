/*
 * Martin Alexander Thomsen den 9. December 2024
 */
package com.maikenwinterberg.banker.util;

import com.maikenwinterberg.banker.communication.api.Telegram;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * Made for reading large files with many lines
 */
public class FileReaderFix {

    private final int DEFAULT_MAX_LINE_SIZE = 1000;
    private final int maxLineSize;
    private final File file;
    private final String newLine;
    private final String encoding;

    private BufferedInputStream bis;
    private String rest = "";

    public FileReaderFix(File file) {
        this.file = file;
        this.maxLineSize = DEFAULT_MAX_LINE_SIZE;
        this.newLine = Telegram.NEW_LINE;
        this.encoding = Telegram.ENCODING;
    }

    public FileReaderFix(File file, int maxLineSize) {
        this.file = file;
        this.maxLineSize = maxLineSize;
        this.newLine = Telegram.NEW_LINE;
        this.encoding = Telegram.ENCODING;
    }

    public FileReaderFix(File file, int maxLineSize, String newLine, String encoding) {
        this.file = file;
        this.maxLineSize = maxLineSize;
        this.newLine = newLine;
        this.encoding = encoding;
    }

    public String readLine() {
        try {
            if (bis == null) {
                bis = new BufferedInputStream(new FileInputStream(file));
            }
            int index = rest.indexOf(newLine);
            if (index != -1) {
                //rest contains another line
                String oldRest = rest;
                try {
                    rest = rest.substring(index + newLine.length());
                } catch (Exception ex) {
                    rest = "";
                    ex.printStackTrace();
                }
                return oldRest.substring(0, index);
            }
            int available = bis.available();
            if (available == 0) {
                //nothing more to read
                if (rest.length() > 0) {
                    //if only rest available
                    String oldRest = rest;
                    rest = "";
                    return oldRest;
                } else {
                    return null;
                }
            } else {
                while (available != 0) {
                    byte[] bytes = new byte[Math.min(available, maxLineSize)];
                    bis.read(bytes);
                    String transactionsAsText = new String(bytes, encoding);
                    transactionsAsText = rest + transactionsAsText;
                    index = transactionsAsText.indexOf(newLine);
                    if (index != -1) {
                        rest = transactionsAsText.substring(index + newLine.length());
                        return transactionsAsText.substring(0, index);
                    } else {
                        if (transactionsAsText.trim().isEmpty()) {
                            return null;
                        }
                        rest = transactionsAsText;
                        available = bis.available();
                    }
                }
            }
        } catch (Exception ex) {
            //ex.printStackTrace();
        }
        if (rest == null || rest.trim().isEmpty()) {
            rest = "";
            return null;
        }
        String oldRest = rest;
        rest = "";
        return oldRest;
    }
}
