/*
 * Martin Alexander Thomsen den 7. December 2024
 */
package com.maikenwinterberg.banker.communication.api.test;

import com.maikenwinterberg.banker.communication.api.HistoryTelegram;
import com.maikenwinterberg.banker.communication.api.factories.AccountTelegramFactory;
import com.maikenwinterberg.banker.communication.api.factories.GiveMoneyTelegramFactory;
import com.maikenwinterberg.banker.communication.api.factories.PrintMoneyTelegramFactory;
import com.maikenwinterberg.banker.communication.api.factories.RollbacktransactionTelegramFactory;
import com.maikenwinterberg.banker.communication.api.factories.TakeMoneyTelegramFactory;
import java.io.File;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class CreateTestTelegrams {

    public static void main(String arg[]) throws Exception {
        int i = 0;
        AccountTelegramFactory.doTrushTelegram("maikenwinterberg.com", "dokumentnetwork.com,documentnetwork.com", false, false, null, null);
        AccountTelegramFactory.doTrushTelegram("documentnetwork.com", "dokumentnetwork.com,maikenwinterberg.com", false, false, null, null);
        AccountTelegramFactory.doBalanceTelegram("maikenwinterberg.com", null, null);
        AccountTelegramFactory.doBalanceTelegram("documentnetwork.com", null, null);
        TakeMoneyTelegramFactory firstTm = null;
        while (true) {
            if (i > 1000000) {
                break;
            }
            if (i % 10000 == 0) {
                System.out.println("creating test files: " + i);
            }
            PrintMoneyTelegramFactory printMoney = new PrintMoneyTelegramFactory("127.0.0.1",null);
            printMoney.addPrintMoneyLine("127.0.0.1","passportnumber_1", 1000, "test print", false, null);
            printMoney.commit();

            TakeMoneyTelegramFactory tm = new TakeMoneyTelegramFactory("maikenwinterberg.com", null);
            tm.addTakeMoneyLine("passportnumber_2", 100, "take money test", null);
            tm.commit();
            if (firstTm == null) {
                firstTm = tm;
            }

            GiveMoneyTelegramFactory giveMoney = new GiveMoneyTelegramFactory("maikenwinterberg.com", null);
            List<File> attachments = new LinkedList();
            //attachments.add(new File("src/main/resource/testBilleder/Skærmbillede fra 2024-12-05 16-31-45.png"));
            giveMoney.addGiveMoneyLine("passportnumber_2", 500, "bank.dk", "til documentnetwork", attachments);
            giveMoney.commit();

            i++;
        }
        AccountTelegramFactory.doHistoryTelegram("127.0.0.1", null, null, HistoryTelegram.OutputType.json,-1);
        AccountTelegramFactory.doHistoryTelegram("maikenwinterberg.com", null, null, HistoryTelegram.OutputType.json,-1);
        AccountTelegramFactory.doHistoryTelegram("documentnetwork.com", null, null, HistoryTelegram.OutputType.json,-1);

        if (firstTm != null) {
            RollbacktransactionTelegramFactory r = new RollbacktransactionTelegramFactory("maikenwinterberg.com", null);
            r.addRollbackLine(firstTm.getTransactionId(0), "rollback step 1");
            r.commit();
            r = new RollbacktransactionTelegramFactory("documentnetwork.com", null);
            r.addRollbackLine(firstTm.getTransactionId(0), "rollback step 2");
            r.commit();
        }
        System.out.println("done");
    }
}
