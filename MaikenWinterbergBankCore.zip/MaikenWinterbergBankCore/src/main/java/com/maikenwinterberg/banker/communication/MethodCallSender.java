/*
 * Martin Alexander Thomsen den 7. December 2024
 */
package com.maikenwinterberg.banker.communication;

import com.maikenwinterberg.banker.communication.event.TelegramResponse;
import com.maikenwinterberg.banker.communication.event.TelegramOKResponse;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.account.AccountService;
import com.maikenwinterberg.banker.accountManager.AccountManagerService;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class MethodCallSender implements ISendRequest {

    @Override
    public String sendRequest(Destination source, Destination destination, Telegram telegram) throws Throwable {
        //TODO implement a socket solution that allow multibe destinations if source and destination ip is different
        TelegramResponse response = null;
        if (destination == null) {
            throw new IllegalStateException("Invalid destination " + destination);
        }
        if (destination.getServiceName() == Destination.ServiceName.accountManagerService) {
            return new AccountManagerService().receiveRequest(telegram);
        } else if (destination.getServiceName() == Destination.ServiceName.accountService) {
            return new AccountService().receiveRequest(telegram);
        } else {
            throw new IllegalStateException("Invalid destination " + destination);
        }
    }
}
