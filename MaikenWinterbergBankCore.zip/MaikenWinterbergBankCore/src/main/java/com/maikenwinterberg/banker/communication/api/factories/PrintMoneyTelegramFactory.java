/*
 * Martin Alexander Thomsen den 12. December 2024
 */
package com.maikenwinterberg.banker.communication.api.factories;

import com.maikenwinterberg.banker.communication.api.PrintmoneyTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import static com.maikenwinterberg.banker.util.Base64ToFile.toBase64;
import com.maikenwinterberg.config.Config;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class PrintMoneyTelegramFactory {

    private final File file;
    private final FileOutputStream fos;
    private final String transactionId;
    private boolean first = true;

    public static PrintmoneyTelegram createPrintMoneyTelegram(String ip, String sessionId, String domainName, String bankAccount, String receiverDomain, Float amount, String text, boolean isLoan) throws Exception {
        String inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "telegramFactoryDirectory");
        PrintMoneyTelegramFactory factory = new PrintMoneyTelegramFactory(domainName, inbox);
        String csv = factory.addPrintMoneyLine(bankAccount, receiverDomain, amount, text, isLoan, null);
        factory.commit();
        PrintmoneyTelegram t = new PrintmoneyTelegram();
        t.setDomainName(ip, sessionId, domainName);
        t.setFile(new File(inbox + "/" + domainName + "/printmoney_" + factory.transactionId), 0);
        t.setTransactionId(factory.transactionId);
        t.setCsvLine(csv);
        return t;
    }

    public PrintMoneyTelegramFactory(String domainName, String inbox) throws Exception {
        if (inbox == null) {
            inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "telegramFactoryDirectory");
        }
        new File(inbox + "/" + domainName).mkdirs();
        this.transactionId = TransactionIdCreator.getTransactionId();
        file = new File(inbox + "/" + domainName + "/printmoney_" + transactionId);
        fos = new FileOutputStream(file);
    }

    public String addPrintMoneyLine(String bankAccount, String passportNumberOrDomainName, float amount, String text, boolean isLoan, List<File> attachments) throws Exception {
        StringBuilder builder = new StringBuilder();
        if (!first) {
            builder.append(Telegram.NEW_LINE);
        }
        first = false;
        builder.append(bankAccount);
        builder.append(Telegram.DELIMITER);
        builder.append(passportNumberOrDomainName);
        builder.append(Telegram.DELIMITER);
        builder.append(amount);
        builder.append(Telegram.DELIMITER);
        if (text == null) {
            text = "money print";
        }
        builder.append(text);
        builder.append(Telegram.DELIMITER);
        builder.append(isLoan);
        if (attachments != null) {
            for (Iterator<File> i = attachments.iterator(); i.hasNext();) {
                File f = i.next();
                builder.append(Telegram.DELIMITER);
                builder.append(f.getName());
                builder.append(Telegram.DELIMITER);
                builder.append(toBase64(f));
            }
        }
        fos.write(builder.toString().getBytes(Telegram.ENCODING));
        return builder.toString();
    }

    public void commit() throws Exception {
        try (fos) {
            fos.flush();
        }
        file.renameTo(new File(file.getAbsolutePath() + ".csv"));
    }
}
