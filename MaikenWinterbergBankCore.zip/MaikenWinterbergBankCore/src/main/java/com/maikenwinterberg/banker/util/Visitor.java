package com.maikenwinterberg.banker.util;

/*
 * @see https://stackoverflow.com/questions/3222638/get-all-of-the-classes-in-the-classpath
 */
public interface Visitor<T> {
    /**
     * @return {@code true} if the algorithm should visit more results,
     * {@code false} if it should terminate now.
     */
    public boolean visit(T t);
}