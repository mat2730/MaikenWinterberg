/*
 * Martin Alexander Thomsen den 30 December 2024
 */
package com.maikenwinterberg.banker.http;

import com.maikenwinterberg.banker.accountManager.AccountServiceLookupFactory;
import com.maikenwinterberg.banker.accountManager.DefaultTrustDomainsImpl;
import com.maikenwinterberg.banker.accountManager.telegramProcess.ApproveBankTelegramProcess;
import com.maikenwinterberg.banker.accountManager.telegramProcess.BalanceTelegramProcess;
import com.maikenwinterberg.banker.accountManager.telegramProcess.GivemoneyTelegramProcess;
import com.maikenwinterberg.banker.accountManager.telegramProcess.GrantLoanTelegramProcess;
import com.maikenwinterberg.banker.accountManager.telegramProcess.HistoryTelegramProcess;
import com.maikenwinterberg.banker.accountManager.telegramProcess.LinkTelegramProcess;
import com.maikenwinterberg.banker.accountManager.telegramProcess.PrintmoneyTelegramProcess;
import com.maikenwinterberg.banker.accountManager.telegramProcess.RollbacktransactionTelegramProcess;
import com.maikenwinterberg.banker.accountManager.telegramProcess.TakemoneyTelegramProcess;
import com.maikenwinterberg.banker.accountManager.telegramProcess.TrustdomainsTelegramProcess;
import com.maikenwinterberg.banker.accountManager.telegramProcess.UnlinkTelegramProcess;
import com.maikenwinterberg.banker.communication.api.HistoryTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.api.factories.AccountTelegramFactory;
import com.maikenwinterberg.banker.communication.api.factories.ApproveBankTelegramFactory;
import com.maikenwinterberg.banker.communication.api.factories.GiveMoneyTelegramFactory;
import com.maikenwinterberg.banker.communication.api.factories.GrantLoanTelegramFactory;
import com.maikenwinterberg.banker.communication.api.factories.PrintMoneyTelegramFactory;
import com.maikenwinterberg.banker.communication.api.factories.RollbacktransactionTelegramFactory;
import com.maikenwinterberg.banker.communication.api.factories.TakeMoneyTelegramFactory;
import com.maikenwinterberg.banker.communication.translate.JsonConverter;
import com.maikenwinterberg.banker.communication.translate.Translater;
import com.maikenwinterberg.banker.loader.LoaderService;
import com.maikenwinterberg.banker.util.DomainVerifier;
import com.maikenwinterberg.config.Config;
import java.io.File;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TreeMap;
import org.veryquick.embweb.Response;
import org.veryquick.embweb.handlers.MimeTypeParser;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class JsonHandleRequest implements IHandleRequest {

    public static IHandleRequest newInstance() {
        return new JsonHandleRequest();
    }

    @Override
    public Response handleRequest(String ip, String sessionId, String url, Map<String, String> parameters) throws Throwable {
        Response response = new Response();
        String transactionId = null;
        try {
            if (url.contains("/adminlink/")) {
                String adminDomain = DomainVerifier.validateAdminIP(ip, sessionId);
                int index = url.indexOf("/adminlink/");
                String domainName2BeLinked = null;
                if (index != -1) {
                    try {
                        domainName2BeLinked = url.substring(index + 11);
                    } catch (Exception ex) {
                    }
                }
                if (domainName2BeLinked == null || domainName2BeLinked.trim().isEmpty()) {
                    try {
                        domainName2BeLinked = parameters.get("GET_domainname");
                    } catch (Exception ex) {
                    }
                }
                String linkedDomainName = AccountServiceLookupFactory.getDomainLookupByPassportInstance().getDomainName(adminDomain, true);
                boolean linked = false;
                boolean unlinked = false;
                Exception exception = null;
                if (linkedDomainName != null) {
                    if (linkedDomainName.equalsIgnoreCase(domainName2BeLinked)) {
                        linked = true;
                    } else if (!linkedDomainName.equalsIgnoreCase(domainName2BeLinked)) {
                        try {
                            AccountServiceLookupFactory.getDomainLookupByPassportInstance().unLink(adminDomain, linkedDomainName);
                            unlinked = true;
                            try {
                                AccountServiceLookupFactory.getDomainLookupByPassportInstance().link(adminDomain, domainName2BeLinked);
                                linked = true;
                            } catch (Exception ex) {
                                exception = ex;
                            }
                        } catch (Exception ex) {
                            exception = ex;
                        }
                    }
                } else {
                    try {
                        AccountServiceLookupFactory.getDomainLookupByPassportInstance().link(adminDomain, domainName2BeLinked);
                        linked = true;
                    } catch (Exception ex) {
                        exception = ex;
                    }
                }
                Map attributes = new TreeMap();
                attributes.put("AdminDomain", adminDomain);
                if (unlinked) {
                    attributes.put("PreviousLinkedDomain", linkedDomainName);
                }
                if (linked) {
                    attributes.put("LinkedDomain", domainName2BeLinked);
                }
                if (exception != null) {
                    attributes.put("Message", exception.getMessage().trim());
                }
                String text = JsonConverter.toJson(null, linked, attributes);
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
                return response;
            } else if (url.contains("/insertbank/")) {
                String masterDomain = DomainVerifier.validateAdminIP(ip, sessionId);
                String domainNameOfBank = null;
                try {
                    int index = url.indexOf("/insertbank/");
                    domainNameOfBank = url.substring(index + 12);
                } catch (Exception ex) {
                }
                if (domainNameOfBank == null || domainNameOfBank.trim().isEmpty()) {
                    domainNameOfBank = parameters.get("GET_domainnameofbank");
                }
                Telegram telegram = ApproveBankTelegramFactory.createApproveBankTelegram(ip, sessionId, masterDomain, domainNameOfBank, LoaderService.getDateString1(), false);
                transactionId = telegram.getTransactionId();
                String text = new ApproveBankTelegramProcess().receiveRequest(telegram);
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
            } else if (url.contains("/tax/")) {
                String masterDomain = DomainVerifier.validateAdminIP(ip, sessionId);
                int index = url.indexOf("/tax/");
                String params = url.substring(index + 5);
                StringTokenizer tok = new StringTokenizer(params, "/");
                String domainName = tok.nextToken();
                Float amount = Float.valueOf(tok.nextToken());
                Telegram telegram = GiveMoneyTelegramFactory.createGiveMoneyTelegram(ip, sessionId, domainName, masterDomain, amount, "Tax " + LoaderService.getDateString1());
                transactionId = telegram.getTransactionId();
                String text = new GivemoneyTelegramProcess().receiveRequest(telegram);
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
            } else if (url.contains("/approveloan/")) {
                int index = url.indexOf("/approveloan/");
                String params = url.substring(index + 13);
                StringTokenizer tok = new StringTokenizer(params, "/");
                String domainNameOfBank = null;
                if (tok.hasMoreTokens()) {
                    domainNameOfBank = tok.nextToken();
                }
                domainNameOfBank = DomainVerifier.validateIP(ip, domainNameOfBank, sessionId);
                String domainNameOfBorrower = null;
                if (tok.hasMoreTokens()) {
                    domainNameOfBorrower = tok.nextToken();
                }
                if (domainNameOfBorrower == null) {
                    domainNameOfBorrower = parameters.get("GET_domainnameofborrower");
                }
                Float amount = null;
                if (tok.hasMoreTokens()) {
                    try {
                        amount = Float.valueOf(tok.nextToken());
                    } catch (Exception ex) {
                    }
                }
                if (amount == null) {
                    amount = Float.valueOf(parameters.get("GET_amount"));
                }
                Telegram telegram = GrantLoanTelegramFactory.createGrantLoanTelegram(ip, sessionId, domainNameOfBank, domainNameOfBorrower, amount, false);
                transactionId = telegram.getTransactionId();
                String text = new GrantLoanTelegramProcess().receiveRequest(telegram);
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
            } else if (url.contains("/give/")) {
                int index = url.indexOf("/give/");
                String params = url.substring(index + 6);
                StringTokenizer tok = new StringTokenizer(params, "/");
                String domainName = null;
                if (tok.hasMoreTokens()) {
                    domainName = tok.nextToken();
                }
                domainName = DomainVerifier.validateIP(ip, domainName, sessionId);
                String domainNameOfReceiver = null;
                if (tok.hasMoreTokens()) {
                    domainNameOfReceiver = tok.nextToken();
                }
                if (domainNameOfReceiver == null) {
                    domainNameOfReceiver = parameters.get("GET_domainnameofreceiver");
                }
                if (domainNameOfReceiver == null) {
                    throw new IllegalArgumentException("Domainname of receiver is missing");
                }
                Float amount = null;
                if (tok.hasMoreTokens()) {
                    try {
                        amount = Float.valueOf(tok.nextToken());
                    } catch (Exception ex) {
                    }
                }
                if (amount == null) {
                    try {
                        amount = Float.valueOf(parameters.get("GET_amount"));
                    } catch (Exception ex) {
                    }
                }
                if (domainNameOfReceiver == null) {
                    throw new IllegalArgumentException("Amount to transfere is missing");
                }
                String text = null;
                if (tok.hasMoreTokens()) {
                    try {
                        text = tok.nextToken();
                    } catch (Exception ex) {
                    }
                }
                if (text == null) {
                    text = parameters.get("GET_text");
                }
                if (text == null) {
                    text = "Give money action";
                }
                Telegram telegram = GiveMoneyTelegramFactory.createGiveMoneyTelegram(ip, sessionId, domainName, domainNameOfReceiver, amount, text);
                transactionId = telegram.getTransactionId();
                text = new GivemoneyTelegramProcess().receiveRequest(telegram);
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
            } else if (url.contains("/take/")) {
                int index = url.indexOf("/take/");
                String params = url.substring(index + 6);
                StringTokenizer tok = new StringTokenizer(params, "/");
                String domainName = null;
                if (tok.hasMoreTokens()) {
                    domainName = tok.nextToken();
                }
                domainName = DomainVerifier.validateIP(ip, domainName, sessionId);
                String domainNameOfGiver = null;
                if (tok.hasMoreTokens()) {
                    domainNameOfGiver = tok.nextToken();
                }
                if (domainNameOfGiver == null) {
                    domainNameOfGiver = parameters.get("GET_domainnameofgiver");
                }
                Float amount = null;
                if (tok.hasMoreTokens()) {
                    try {
                        amount = Float.valueOf(tok.nextToken());
                    } catch (Exception ex) {

                    }
                }
                if (amount == null) {
                    try {
                        amount = Float.valueOf(parameters.get("GET_amount"));
                    } catch (Exception ex) {

                    }
                }
                if (amount == null) {
                    throw new IllegalStateException("Please enter amount");
                }
                String text = null;
                if (tok.hasMoreTokens()) {
                    text = tok.nextToken();
                }
                if (text == null) {
                    text = parameters.get("GET_text");
                }
                if (text == null) {
                    text = "Take money action";
                }
                Telegram telegram = TakeMoneyTelegramFactory.createTakeMoneyTelegram(ip, sessionId, domainName, domainNameOfGiver, amount, text);
                transactionId = telegram.getTransactionId();
                text = new TakemoneyTelegramProcess().receiveRequest(telegram);
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
            } else if (url.indexOf("/saldo") != -1) {
                int index = url.indexOf("/saldo/");
                String params = url.substring(index + 7);
                StringTokenizer tok = new StringTokenizer(params, "/");
                String domainName = null;
                if (tok.hasMoreTokens()) {
                    domainName = tok.nextToken();
                }
                domainName = DomainVerifier.validateIP(ip, domainName, sessionId);
                Telegram telegram = AccountTelegramFactory.createBalanceTelegram(ip, sessionId, domainName);
                transactionId = telegram.getTransactionId();
                String text = new BalanceTelegramProcess().receiveRequest(telegram);
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
            } else if (url.indexOf("/balance") != -1) {
                int index = url.indexOf("/balance/");
                String params = url.substring(index + 9);
                StringTokenizer tok = new StringTokenizer(params, "/");
                String domainName = null;
                if (tok.hasMoreTokens()) {
                    domainName = tok.nextToken();
                }
                domainName = DomainVerifier.validateIP(ip, domainName, sessionId);
                Telegram telegram = AccountTelegramFactory.createBalanceTelegram(ip, sessionId, domainName);
                transactionId = telegram.getTransactionId();
                String text = new BalanceTelegramProcess().receiveRequest(telegram);
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
            } else if (url.indexOf("/link/") != -1) {
                int index = url.indexOf("/link/");
                String params = url.substring(index + 6);
                StringTokenizer tok = new StringTokenizer(params, "/");
                String domainName = null;
                if (tok.hasMoreTokens()) {
                    domainName = tok.nextToken();
                }
                domainName = DomainVerifier.validateIP(ip, domainName, sessionId);
                String number = null;
                if (tok.hasMoreTokens()) {
                    number = tok.nextToken().trim();
                }
                if (number == null) {
                    number = parameters.get("GET_number");
                }
                boolean errorInNumber = false;
                if (number.contains(".") || number.contains(Telegram.DELIMITER) || number.contains(Telegram.NEW_LINE)) {
                    errorInNumber = true;
                } else {
                    try {
                        DomainVerifier.verifyDomain(number, true);
                        //not ok. Must not be a domain
                        errorInNumber = true;
                    } catch (Exception ex) {
                        //ok
                    }
                }
                if (errorInNumber) {
                    String text = Translater.translate(Translater.INVALID_NUMBER, number);
                    text = JsonConverter.toJson(null, false, text);
                    throw new IllegalArgumentException(text);
                }
                Telegram telegram = AccountTelegramFactory.createLinkTelegram(ip, sessionId, domainName, number, null);
                transactionId = telegram.getTransactionId();
                String text = new LinkTelegramProcess().receiveRequest(telegram);
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
            } else if (url.indexOf("/unlink/") != -1) {
                int index = url.indexOf("/unlink/");
                String params = url.substring(index + 8);
                StringTokenizer tok = new StringTokenizer(params, "/");
                String domainName = null;
                if (tok.hasMoreTokens()) {
                    domainName = tok.nextToken();
                }
                domainName = DomainVerifier.validateIP(ip, domainName, sessionId);
                String number = null;
                if (tok.hasMoreTokens()) {
                    number = tok.nextToken().trim();
                }
                if (number == null) {
                    number = parameters.get("GET_number");
                }
                Telegram telegram = AccountTelegramFactory.createUnlinkTelegram(ip, sessionId, domainName, number);
                transactionId = telegram.getTransactionId();
                String text = new UnlinkTelegramProcess().receiveRequest(telegram);
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
            } else if (url.indexOf("/trust/") != -1) {
                int index = url.indexOf("/trust/");
                String params = url.substring(index + 7);
                StringTokenizer tok = new StringTokenizer(params, "/");
                String domainName = null;
                if (tok.hasMoreTokens()) {
                    domainName = tok.nextToken();
                }
                String domainName2Trust = null;
                if (tok.hasMoreTokens()) {
                    domainName2Trust = tok.nextToken();
                }
                if (domainName2Trust == null) {
                    domainName2Trust = parameters.get("GET_domainname2trust");
                }
                boolean append = true;
                try {
                    append = Boolean.parseBoolean(tok.nextToken());
                } catch (Exception ex) {
                    try {
                        append = Boolean.parseBoolean(parameters.get("GET_append"));
                    } catch (Exception exe) {
                        append = true;
                    }
                }
                boolean reversed = false;
                domainName = DomainVerifier.validateIP(ip, domainName, sessionId);
                Telegram telegram = AccountTelegramFactory.createTrustTelegram(ip, sessionId, domainName, domainName2Trust, append, reversed);
                transactionId = telegram.getTransactionId();
                String text = new TrustdomainsTelegramProcess().receiveRequest(telegram);
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
            } else if (url.indexOf("/untrust/") != -1) {
                int index = url.indexOf("/untrust/");
                String params = url.substring(index + 9);
                StringTokenizer tok = new StringTokenizer(params, "/");
                String domainName = null;
                if (tok.hasMoreTokens()) {
                    domainName = tok.nextToken();
                }
                domainName = DomainVerifier.validateIP(ip, domainName, sessionId);
                String domainName2Trust = null;
                if (tok.hasMoreTokens()) {
                    domainName2Trust = tok.nextToken();
                }
                if (domainName2Trust == null) {
                    domainName2Trust = parameters.get("GET_domainname2trust");
                }
                boolean append = false;
                boolean reversed = true;
                Telegram telegram = AccountTelegramFactory.createTrustTelegram(ip, sessionId, domainName, domainName2Trust, append, reversed);
                transactionId = telegram.getTransactionId();
                String text = new TrustdomainsTelegramProcess().receiveRequest(telegram);
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
            } else if (url.indexOf("/history") != -1) {
                int index = url.indexOf("/history");
                String domainName = null;
                if (index != -1) {
                    String params = url.substring(index + 8);
                    StringTokenizer tok = new StringTokenizer(params, "/");
                    if (tok.hasMoreTokens()) {
                        domainName = tok.nextToken();
                    }
                }
                domainName = DomainVerifier.validateIP(ip, domainName, sessionId);
                HistoryTelegram.OutputType type = HistoryTelegram.OutputType.json;
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    type = HistoryTelegram.OutputType.html;
                }
                long blockSize = 1500;
                try {
                    blockSize = Long.parseLong(Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "historyBlockSize"));
                } catch (Exception ex) {
                }
                Telegram telegram = AccountTelegramFactory.createHistoryTelegram(ip, sessionId, domainName, type, blockSize);
                transactionId = telegram.getTransactionId();
                String text = new HistoryTelegramProcess().receiveRequest(telegram);
                if (redirecturl != null) {
                    String linkedDomainName = AccountServiceLookupFactory.getDomainLookupByPassportInstance().getDomainName(domainName, true);
                    response.addContent(HtmlHandleRequest.converte("History of " + (linkedDomainName == null ? domainName : linkedDomainName), text));
                    response.setOk();
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
            } else if (url.indexOf("/bankhistory") != -1) {
                int index = url.indexOf("/history");
                String domainName = null;
                if (index != -1) {
                    String params = url.substring(index + 8);
                    StringTokenizer tok = new StringTokenizer(params, "/");
                    if (tok.hasMoreTokens()) {
                        domainName = tok.nextToken();
                    }
                }
                domainName = DomainVerifier.validateIP(ip, domainName, sessionId);
                HistoryTelegram.OutputType type = HistoryTelegram.OutputType.csv;
                Telegram telegram = AccountTelegramFactory.createHistoryTelegram(ip, sessionId, domainName, type, Long.MAX_VALUE);
                transactionId = telegram.getTransactionId();
                String text = new HistoryTelegramProcess().receiveRequest(telegram);
                response.setContentType(MimeTypeParser.getInstance().getType("csv"));
                response.setBinaryContent(text.getBytes(Telegram.ENCODING));
            } else if (url.indexOf("/loan/") != -1) {
                int index = url.indexOf("/loan/");
                String params = url.substring(index + 6);
                StringTokenizer tok = new StringTokenizer(params, "/");
                String domainName = null;
                if (tok.hasMoreTokens()) {
                    domainName = tok.nextToken();
                }
                domainName = DomainVerifier.validateIP(ip, domainName, sessionId);
                Float amount = null;
                if (tok.hasMoreTokens()) {
                    try {
                        amount = Float.valueOf(tok.nextToken());
                    } catch (Exception ex) {
                    }
                }
                if (amount == null) {
                    try {
                        amount = Float.valueOf(parameters.get("GET_amount"));
                    } catch (Exception ex) {
                    }
                }
                if (amount == null) {
                    throw new IllegalArgumentException("Amount to loan cannot be zero");
                }
                if (amount < 0) {
                    throw new IllegalArgumentException("Amount must be positive");
                }
                String bankDomainName = null;
                if (tok.hasMoreTokens()) {
                    bankDomainName = tok.nextToken();
                }
                if (bankDomainName == null) {
                    bankDomainName = parameters.get("GET_bankdomainname");
                }
                if (bankDomainName == null) {
                    try {
                        bankDomainName = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "defaultBank");
                    } catch (Exception ex) {
                    }
                }
                String text = null;
                if (tok.hasMoreTokens()) {
                    text = tok.nextToken();
                }
                if (text == null) {
                    text = parameters.get("GET_text");
                }
                if (text == null) {
                    text = "Loan " + LoaderService.getDateString1();
                }
                String domainName2 = null;
                try {
                    domainName2 = AccountServiceLookupFactory.getDomainLookupByPassportInstance().getDomainName(domainName, true);
                } catch (Exception ex) {
                }
                Telegram telegram = PrintMoneyTelegramFactory.createPrintMoneyTelegram(ip, sessionId, domainName, bankDomainName, (domainName2 == null ? domainName : domainName2), amount, text, true);
                transactionId = telegram.getTransactionId();
                text = new PrintmoneyTelegramProcess().receiveRequest(telegram);
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
            } else if (url.indexOf("/transfere") != -1) {
                int index = url.indexOf("/transfere/");
                String params = url.substring(index + 11);
                StringTokenizer tok = new StringTokenizer(params, "/");
                String domainNameOfBank = null;
                if (tok.hasMoreTokens()) {
                    domainNameOfBank = tok.nextToken();
                }
                String domainName = DomainVerifier.validateIP(ip, domainNameOfBank, sessionId);
                domainNameOfBank = domainName;
                String bankDirectory = DefaultTrustDomainsImpl.getDomainDirectory(domainNameOfBank);
                File f = new File(bankDirectory + "/bank");
                if (!f.exists()) {
                    //is it an admin
                    domainNameOfBank = AccountServiceLookupFactory.getDomainLookupByPassportInstance().getDomainName(domainNameOfBank, true);
                    bankDirectory = DefaultTrustDomainsImpl.getDomainDirectory(domainNameOfBank);
                    f = new File(bankDirectory + "/bank");
                    if (!f.exists()) {
                        throw new IllegalStateException("You must be a bank in order to transfere");
                    }
                }
                Float amount = null;
                if (tok.hasMoreTokens()) {
                    try {
                        amount = Float.valueOf(tok.nextToken());
                    } catch (Exception ex) {
                    }
                }
                if (amount == null) {
                    try {
                        amount = Float.valueOf(parameters.get("GET_amount"));
                    } catch (Exception ex) {
                    }
                }
                if (amount == null) {
                    throw new IllegalArgumentException("Amount to transfere cannot be zero");
                }
                if (amount < 0) {
                    throw new IllegalArgumentException("Amount must be positive");
                }
                String receiverDomainName = null;
                if (tok.hasMoreTokens()) {
                    receiverDomainName = tok.nextToken();
                }
                if (receiverDomainName == null) {
                    receiverDomainName = parameters.get("GET_receiverdomainname");
                }
                String text = null;
                if (tok.hasMoreTokens()) {
                    text = tok.nextToken();
                }
                if (text == null) {
                    text = parameters.get("GET_text");
                }
                if (text == null) {
                    text = "Transfere " + LoaderService.getDateString1();
                }
                Telegram telegram = PrintMoneyTelegramFactory.createPrintMoneyTelegram(ip, sessionId, domainName, domainNameOfBank, receiverDomainName, amount, text, false);
                transactionId = telegram.getTransactionId();
                text = new PrintmoneyTelegramProcess().receiveRequest(telegram);
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
            } else if (url.indexOf("/rollback") != -1) {
                int index = url.indexOf("/rollback/");
                String params = url.substring(index + 10);
                StringTokenizer tok = new StringTokenizer(params, "/");
                String domainName = null;
                if (tok.hasMoreTokens()) {
                    domainName = tok.nextToken();
                }
                domainName = DomainVerifier.validateIP(ip, domainName, sessionId);
                String utransactionId = null;
                if (tok.hasMoreTokens()) {
                    utransactionId = tok.nextToken();
                }
                if (utransactionId == null) {
                    utransactionId = parameters.get("GET_transactionid");
                }
                Telegram telegram = RollbacktransactionTelegramFactory.createRollbackTelegram(ip, sessionId, domainName, utransactionId);
                transactionId = telegram.getTransactionId();
                String text = new RollbacktransactionTelegramProcess().receiveRequest(telegram);
                String redirecturl = parameters.get("GET_redirecturl");
                if (redirecturl != null) {
                    response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
                } else {
                    response.setContentType(MimeTypeParser.getInstance().getType("json"));
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                }
            }
        } catch (Throwable ex) {
            String text = JsonConverter.toJson(transactionId, ex.getMessage(), ex);
            String redirecturl = parameters.get("GET_redirecturl");
            if (redirecturl != null) {
                response.setRedirect(redirecturl + "?text=" + JsonConverter.toMessage(text) + "&sessionid=" + sessionId);
            } else {
                response.setContentType(MimeTypeParser.getInstance().getType("json"));
                try {
                    response.setBinaryContent(text.getBytes(Telegram.ENCODING));
                } catch (Exception exe) {
                    response.setError(exe);
                }
            }
            return response;
        }
        return response;
    }
}
