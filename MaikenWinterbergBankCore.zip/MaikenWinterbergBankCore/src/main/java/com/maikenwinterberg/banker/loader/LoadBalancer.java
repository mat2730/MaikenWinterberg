/*
 * Martin Alexander Thomsen den 5. December 2024
 */
package com.maikenwinterberg.banker.loader;

import com.maikenwinterberg.banker.communication.Destination;
import com.maikenwinterberg.banker.communication.SendRequestFactory;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.event.CommunicationEvent;
import com.maikenwinterberg.banker.communication.event.LocalEvents;
import com.maikenwinterberg.banker.communication.event.TelegramErrorResponse;
import com.maikenwinterberg.domainname.DomainHandler;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class LoadBalancer {

    public static void handleRequest(Telegram telegram) throws Throwable {
        //TODO if link/unlink call all Accountmanagers
        //otherwise select random AccountManager
        Destination source = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.loaderService);
        Destination destination = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountManagerService);
        try {
            SendRequestFactory.newInstance().sendRequest(source, destination, telegram);
        } catch (Throwable ex) {
            CommunicationEvent ce = new CommunicationEvent(source, destination, telegram, new TelegramErrorResponse(telegram.getTransactionId(), ex));
            LocalEvents.fireEvent(ce);
        } finally {
        }
    }
}
