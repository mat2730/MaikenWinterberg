/*
 * Martin Alexander Thomsen den 12. December 2024
 */
package com.maikenwinterberg.banker.communication.api;

import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class HistoryTelegram extends Telegram {

    public enum OutputType {
        csv, json, html;
    }
    private OutputType outputType; //csv, json
    private long blocksize;

    @Override
    public void setCsvLine(String csvLine) throws Exception {
        StringTokenizer tok = new StringTokenizer(csvLine, Telegram.DELIMITER);
        try {
            outputType = OutputType.valueOf(tok.nextToken());
        } catch (Exception ex) {
            outputType = OutputType.html;
        }
        try {
            blocksize = Long.parseLong(tok.nextToken());
        } catch (Exception ex) {
            blocksize = Long.MAX_VALUE;
        }
    }

    public OutputType getOutputType() {
        return outputType;
    }

    public long getSize() {
        return blocksize;
    }
    
    @Override
    public String getTransactionId() {
        return null;
    }
}
