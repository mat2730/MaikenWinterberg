/*
 * Martin Alexander Thomsen den 30 December 2024
 */
package com.maikenwinterberg.banker.http;

import com.maikenwinterberg.account.database.Info;
import com.maikenwinterberg.account.datagram.SessionClientFactory;
import com.maikenwinterberg.banker.accountManager.AccountServiceLookupFactory;
import com.maikenwinterberg.banker.accountManager.DefaultTrustDomainsImpl;
import com.maikenwinterberg.banker.util.DomainVerifier;
import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.htmlwriter.IHtmlWriter;
import com.maikenwinterberg.htmlwriter.TemplateHTMLWriterImpl;
import java.io.File;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.TreeMap;
import org.veryquick.embweb.Response;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class HtmlHandleRequest implements IHandleRequest {
    public static final DateTimeFormatter ZDT_FORMATTER = DateTimeFormatter.ofPattern("yyyyMM");

    public static IHandleRequest newInstance() {
        return new HtmlHandleRequest();
    }

    public static String converte(String headline, String tablerows) throws Exception {
        String resourceUrl = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "resourceurl");
        IHtmlWriter iw = new TemplateHTMLWriterImpl();
        iw.addAttribute("header", headline);
        iw.addAttribute("background", resourceUrl + "/background.jpg");
        iw.addAttribute("tablerows", tablerows);
        String historytemplate = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "historytemplate");
        iw.addAttribute("template", historytemplate);
        String template = Config.loadConfigResource(Config.Group.bankerConfig, historytemplate);
        if (template == null) {
            System.out.println("No templage.service found in conf");
            return null;
        }
        iw.addPostHtml(0, template);
        return iw.toString();
    }

    private static String converte(String headline, String link, String errorMessage, Map<String, String> attributes) throws Exception {
        StringBuilder tablerows = new StringBuilder();
        for (String attributeName : attributes.keySet()) {
            if (attributeName.endsWith(".class")) {
                continue;
            }
            String attributeValue = attributes.get(attributeName);
            String clazz = attributes.get(attributeName+".class");
            tablerows.append("<tr ").append(clazz==null?"":"class='"+clazz+"' ")
                    .append("><td style='vertical-align:top;' class=\"table__content\" data-heading=\"Function\">")
                    .append(attributeName)
                    .append("</td>")
                    .append("<td class=\"table__content\" data-heading=\"Submit\">")
                    .append(attributeValue)
                    .append("</td></tr>");
        }
        String resourceUrl = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "resourceurl");
        IHtmlWriter iw = new TemplateHTMLWriterImpl();
        iw.addAttribute("header", headline);
        if (errorMessage != null) {
            iw.addAttribute("errorMessage", errorMessage);
        }
        iw.addAttribute("background", resourceUrl + "/background.jpg");
        if (link == null || link.trim().isEmpty()) {
            link = "/index.html";
        }
        iw.addAttribute("link", link);
        iw.addAttribute("tablerows", tablerows.toString());
        String defaulttemplate = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "defaulttemplate");
        iw.addAttribute("template", defaulttemplate);
        String template = Config.loadConfigResource(Config.Group.bankerConfig, defaulttemplate);
        if (template == null) {
            System.out.println("No templage.service found in conf");
            return null;
        }
        iw.addPostHtml(0, template);
        return iw.toString();
    }

    private static StringBuilder appendCheckInput(StringBuilder b, String name, String shortDescription, String longDescription, boolean value) {
        b.append("<input type='checkbox' name = '").append(name).append("' placeholder='").append(shortDescription).append("' title='").append(longDescription).append("' CHECKED='true' value='" + value + "'></input>");
        return b;
    }

    private static StringBuilder appendInput(StringBuilder b, String name, String shortDescription, String longDescription) {
        b.append("<input type='text' name = '").append(name).append("' placeholder='").append(shortDescription).append("' title='").append(longDescription).append("' value=''></input>");
        return b;
    }

    private static StringBuilder appendSubmit(StringBuilder b, String text) {
        b.append("<input type='submit' value='").append(text).append("' </input>");
        return b;
    }

    @Override
    public Response handleRequest(String ip, String sessionId, String url, Map<String, String> parameters) throws Throwable {
        Response response = new Response();
        try {
            if (url.contains("/menu")) {
                try {
                    String adminDomain = null;
                    String simpleDomain = null;
                    boolean isBank = false;
                    try {
                        adminDomain = DomainVerifier.validateAdminIP(ip, sessionId);
                    } catch (Exception ex) {
                    }
                    if (adminDomain == null) {
                        simpleDomain = DomainVerifier.validateIP(ip, null, sessionId);
                    }
                    if (simpleDomain == null && adminDomain == null) {
                        throw new IllegalAccessException("No access grated");
                    }
                    String directory = DefaultTrustDomainsImpl.getDomainDirectory((adminDomain != null ? adminDomain : simpleDomain));
                    File f = new File(directory + "/bank");
                    if (f.exists()) {
                        isBank = true;
                    }
                    StringBuilder form;
                    String hidden = "<input type='hidden' name = 'sessionid' value='" + sessionId + "'></input><input type='hidden' name = 'redirecturl' value='/html/menu'></input>";
                    Map a = new TreeMap();
                    if (adminDomain != null) {
                        form = new StringBuilder();
                        form.append("<form action='/html/adminmenu/'>").append(hidden);
                        HtmlHandleRequest.appendSubmit(form, "Goto admin-menu").append("</form>");
                        a.put("Admin-menu", form.toString());
                    }
                    if (isBank) {
                        form = new StringBuilder();
                        form.append("<form action='/html/bankmenu/'>").append(hidden);
                        HtmlHandleRequest.appendSubmit(form, "Goto bank-menu").append("</form>");
                        a.put("Bank-menu", form.toString());
                    }
                    //saldo
                    form = new StringBuilder();
                    form.append("<form action='/json/saldo/'>").append(hidden);
                    HtmlHandleRequest.appendSubmit(form, "Show saldo").append("</form>");
                    a.put("1) Show saldo", form.toString());
                    //loan
                    form = new StringBuilder();
                    form.append("<form action='/json/loan/'>").append(hidden);
                    HtmlHandleRequest.appendInput(form, "amount", "Amount", "Amount to loan");
                    form.append("</br>");
                    HtmlHandleRequest.appendInput(form, "bankdomainname", "Name of bank", "Leave blank for default bank");
                    HtmlHandleRequest.appendSubmit(form, "Loan money").append("</form>");
                    a.put("2) Loan money", form.toString());
                    //give
                    form = new StringBuilder();
                    form.append("<form action='/json/give/'>").append(hidden);
                    HtmlHandleRequest.appendInput(form, "domainnameofreceiver", "Account name", "Account name of receiver");
                    form.append("<br/>");
                    HtmlHandleRequest.appendInput(form, "amount", "Amount", "Amount to give");
                    form.append("<br/>");
                    HtmlHandleRequest.appendInput(form, "text", "Text", "Message to receiver");
                    HtmlHandleRequest.appendSubmit(form, "Give money").append("</form>");
                    a.put("3) Give money", form.toString());
                    //link
                    form = new StringBuilder();
                    form.append("<form action='/json/link/'>").append(hidden);
                    HtmlHandleRequest.appendInput(form, "number", "Number to link", "Select a unique number for your account");
                    HtmlHandleRequest.appendSubmit(form, "Link number").append("</form>");
                    a.put("4) Link number to account", form.toString());
                    //unlink
                    form = new StringBuilder();
                    form.append("<form action='/json/unlink/'>").append(hidden);
                    HtmlHandleRequest.appendInput(form, "number", "Number to unlink", "Type in the number to remove from your account");
                    HtmlHandleRequest.appendSubmit(form, "Unlink number").append("</form>");
                    a.put("5) Unlink number", form.toString());
                    //trust
                    form = new StringBuilder();
                    form.append("<form action='/json/trust/'>").append(hidden);
                    HtmlHandleRequest.appendInput(form, "domainname2trust", "Account number to trust", "This account can take money from your account");
                    form.append("</br>");
                    HtmlHandleRequest.appendCheckInput(form, "append", "Append existing trust accounts", "type false to Start on a frish trust list", true);
                    HtmlHandleRequest.appendSubmit(form, "Trust account").append("</form>");
                    a.put("6) Trust account", form.toString());
                    //untrust
                    form = new StringBuilder();
                    form.append("<form action='/json/untrust/'>").append(hidden);
                    HtmlHandleRequest.appendInput(form, "domainname2trust", "Account number to untrust", "This account can no longer take money from your account");
                    HtmlHandleRequest.appendSubmit(form, "Untrust account").append("</form>");
                    a.put("7) Untrust account", form.toString());
                    //take
                    form = new StringBuilder();
                    form.append("<form action='/json/take/'>").append(hidden);
                    HtmlHandleRequest.appendInput(form, "domainnameofgiver", "Account number to take money from", "This account must trust your account");
                    form.append("</br>");
                    HtmlHandleRequest.appendInput(form, "amount", "Amount", "Amount to take");
                    form.append("</br>");
                    HtmlHandleRequest.appendInput(form, "text", "Text", "You can optional write a message");
                    HtmlHandleRequest.appendSubmit(form, "Take money").append("</form>");
                    a.put("8) Take money", form.toString());
                    //rollback
                    /*
                    form = new StringBuilder();
                    form.append("<form action='/json/rollback/'>").append(hidden);
                    HtmlHandleRequest.appendInput(form, "transactionid", "Transaction id to rollback", "You cannot rollback money that you have giving");
                    HtmlHandleRequest.appendSubmit(form, "Rollback transaction").append("</form>");
                    a.put("9) Rollback transaction", form.toString());*/
                    //history
                    hidden = "<input type='hidden' name = 'sessionid' value='" + sessionId + "'></input><input type='hidden' name = 'redirecturl' value='/html/menu'></input>";
                    form = new StringBuilder();
                    form.append("<form action='/json/history/'>").append(hidden);
                    HtmlHandleRequest.appendSubmit(form, "Show history").append("</form>");
                    a.put("9) Show history", form.toString());
                    //transactions
                    hidden = "<input type='hidden' name = 'sessionid' value='" + sessionId + "'></input>";
                    form = new StringBuilder();
                    String transactionsUrl = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "transactionsUrl");
                    if (transactionsUrl == null) {
                        transactionsUrl = "https://localhost:8090/transactions";
                    }
                    //TODO make configuable
                    transactionsUrl += "/"+ZDT_FORMATTER.format(ZonedDateTime.now())+"/private";
                    form.append("<form class=\"table__heading table2__heading\" action='"+transactionsUrl+"'>").append(hidden);
                    HtmlHandleRequest.appendSubmit(form, "Show transactions").append("</form>");
                    a.put("Show transactions", form.toString());
                    a.put("Show transactions.class", "table__heading table2__heading");
                    //html
                    String text = parameters.get("GET_text");
                    if (text == null) {
                        text = "";
                    }
                    Info info = SessionClientFactory.getSessionClient().getAccountInfo(sessionId);
                    String linkedDomainName = AccountServiceLookupFactory.getDomainLookupByPassportInstance().getDomainName(info.getAccountName(), true);
                    response.addContent(converte("Welcome to " + info.getAccountName() + (linkedDomainName != null ? ", administrating " + linkedDomainName : ""), "", text, a));
                } catch (Exception ex) {
                    response.addContent(converte("No access to the account", "", "Try to enter the account again", new TreeMap()));
                    //response.setError(ex);
                }
                response.setOk();
                return response;
            } else if (url.contains("/adminmenu")) {
                try {
                    //TODO show status
                    Map a = new TreeMap();
                    String hidden = "<input type='hidden' name = 'sessionid' value='" + sessionId + "'></input><input type='hidden' name = 'redirecturl' value='/html/adminmenu'></input>";
                    //create adminlink
                    StringBuilder form = new StringBuilder();
                    form.append("<form action='/json/adminlink/'>").append(hidden);
                    HtmlHandleRequest.appendInput(form, "domainname", "Account name", "Account name to link to");
                    HtmlHandleRequest.appendSubmit(form, "Create admin link").append("</form>");
                    a.put("1) Create admin link", form.toString());
                    //create bank
                    form = new StringBuilder();
                    form.append("<form action='/json/insertbank/'>").append(hidden);
                    HtmlHandleRequest.appendInput(form, "domainnameofbank", "Account name", "Account name of bank");
                    HtmlHandleRequest.appendSubmit(form, "Create bank").append("</form>");
                    a.put("2) Create new bank", form.toString());
                    //menu
                    form = new StringBuilder();
                    form.append("<form action='/html/menu/'>").append(hidden);
                    HtmlHandleRequest.appendSubmit(form, "Goto menu").append("</form>");
                    a.put("3) Menu", form.toString());
                    String text = parameters.get("GET_text");
                    if (text == null) {
                        text = "";
                    }
                    Info info = SessionClientFactory.getSessionClient().getAccountInfo(sessionId);

                    String linkedDomainName = AccountServiceLookupFactory.getDomainLookupByPassportInstance().getDomainName(info.getAccountName(), true);
                    response.addContent(converte("Welcome to " + info.getAccountName() + (linkedDomainName != null ? ", administrating " + linkedDomainName : ""), "", text, a));
                } catch (Exception ex) {
                    response.addContent(converte("No access to the account", "", "Try to enter the account again", new TreeMap()));
                    //ex.printStackTrace();
                    //response.setError(ex);
                }
                response.setOk();
                return response;
            } else if (url.contains("/bankmenu")) {
                try {
                    //TODO show status
                    Map a = new TreeMap();
                    StringBuilder form = new StringBuilder();
                    String hidden = "<input type='hidden' name = 'sessionid' value='" + sessionId + "'></input><input type='hidden' name = 'redirecturl' value='/html/bankmenu'></input>";
                    //approve loan
                    form = new StringBuilder();
                    form.append("<form action='/json/approveloan/'>").append(hidden);
                    HtmlHandleRequest.appendInput(form, "domainnameofborrower", "Account name", "Account name of borrower");
                    form.append("<br/>");
                    HtmlHandleRequest.appendInput(form, "amount", "Amount", "Max amount to loan out");
                    HtmlHandleRequest.appendSubmit(form, "Approve a loan").append("</form>");
                    a.put("3) Approve a loan", form.toString());
                    //transfere money
                    form = new StringBuilder();
                    form.append("<form action='/json/transfere/'>").append(hidden);
                    HtmlHandleRequest.appendInput(form, "receiverdomainname", "Account name", "Account name of receiver");
                    form.append("<br/>");
                    HtmlHandleRequest.appendInput(form, "amount", "Amount", "Max amount to loan out");
                    form.append("<br/>");
                    HtmlHandleRequest.appendInput(form, "text", "Text", "Transfere text (let it be an accountnumber of original account)");
                    HtmlHandleRequest.appendSubmit(form, "Transfere money").append("</form>");
                    a.put("2) Transfere money", form.toString());
                    //history
                    hidden = "<input type='hidden' name = 'sessionid' value='" + sessionId + "'></input><input type='hidden' name = 'redirecturl' value='/html/menu'></input>";
                    form = new StringBuilder();
                    form.append("<form action='/json/bankhistory/'>").append(hidden);
                    HtmlHandleRequest.appendSubmit(form, "Show history").append("</form>");
                    a.put("1) Show history", form.toString());
                    //menu
                    form = new StringBuilder();
                    form.append("<form action='/html/menu/'>").append(hidden);
                    HtmlHandleRequest.appendSubmit(form, "Goto menu").append("</form>");
                    a.put("4) Menu", form.toString());
                    String text = parameters.get("GET_text");
                    if (text == null) {
                        text = "";
                    }
                    Info info = SessionClientFactory.getSessionClient().getAccountInfo(sessionId);

                    String linkedDomainName = AccountServiceLookupFactory.getDomainLookupByPassportInstance().getDomainName(info.getAccountName(), true);
                    response.addContent(converte("Welcome to " + info.getAccountName() + (linkedDomainName != null ? ", administrating " + linkedDomainName : ""), "", text, a));
                } catch (Exception ex) {
                    response.addContent(converte("No access to the account", "", "Try to enter the account again", new TreeMap()));
                    //ex.printStackTrace();
                    //response.setError(ex);
                }
                response.setOk();
                return response;
            }
        } catch (Exception ex) {
            response.setError(ex);
        }
        return response;
    }
}
