/*
 * Martin Alexander Thomsen den 18. December 2024
 */
package com.maikenwinterberg.banker.accountManager.telegramProcess;

import com.maikenwinterberg.banker.accountManager.AccountServiceLookupFactory;
import com.maikenwinterberg.banker.communication.Destination;
import com.maikenwinterberg.banker.communication.IReceiveRequest;
import com.maikenwinterberg.banker.communication.SendRequestFactory;
import com.maikenwinterberg.banker.communication.api.AccountTelegram;
import com.maikenwinterberg.banker.communication.api.RollbacktransactionTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.event.CommunicationEvent;
import com.maikenwinterberg.banker.communication.event.LocalEvents;
import com.maikenwinterberg.banker.communication.event.TelegramErrorResponse;
import com.maikenwinterberg.banker.communication.event.TelegramOKResponse;
import com.maikenwinterberg.banker.communication.translate.JsonConverter;
import com.maikenwinterberg.banker.communication.translate.Translater;
import com.maikenwinterberg.domainname.DomainHandler;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class RollbacktransactionTelegramProcess implements IReceiveRequest {

    @Override
    public String receiveRequest(Telegram telegram) throws Throwable {
        try {
            Destination accountManagerService = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountManagerService);
            Destination loader = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.loaderService);

            try {
                RollbacktransactionTelegram rt = (RollbacktransactionTelegram) telegram;
                //test
                synchronized (RollbacktransactionTelegram.class) {
                    List<Destination> dest = AccountServiceLookupFactory.getAccountLookupByTransactionInstance().getAccounts(rt.getTransactionid2Rollback());
                    if (dest != null && !dest.isEmpty()) {
                        String text = Translater.translate(Translater.ALLREADY_ROLLEDBACK);
                        text = JsonConverter.toJson(telegram, false, text);
                        return text;
                    } else {
                        Destination accountService1 = AccountServiceLookupFactory.getAccountDestinationLookupByDomainNameInstance().getAccountService("rolled back by " + rt.getDomainName());
                        List accounts = new LinkedList();
                        accounts.add(accountService1);
                        AccountServiceLookupFactory.getAccountLookupByTransactionInstance().addAccountServices(rt.getTransactionid2Rollback(), accounts);
                    }
                }
                Destination accountService = AccountServiceLookupFactory.getAccountDestinationLookupByDomainNameInstance().getAccountService(telegram.getDomainName());
                SendRequestFactory.newInstance().sendRequest(accountManagerService, accountService, new AccountTelegram(telegram, telegram.getDomainName(), null, AccountTelegram.Action.Rollback, null, true));
                String text = Translater.translate(Translater.THE_TRANSACTION, rt.getTransactionid2Rollback(), Translater.IS_ROLLEDBACKED_BACK_FROM, rt.getCounterAccountDomainName());
                text = JsonConverter.toJson(telegram, true, text);
                CommunicationEvent ce = new CommunicationEvent(accountManagerService, loader, telegram, new TelegramOKResponse(telegram.getTransactionId(), text));
                LocalEvents.fireEvent(ce);
                return text;
            } catch (Exception ex) {
                String text = JsonConverter.toJson(telegram, ex);
                CommunicationEvent ce = new CommunicationEvent(accountManagerService, loader, telegram, new TelegramErrorResponse(telegram.getTransactionId(), new IllegalStateException(text)));
                LocalEvents.fireEvent(ce);;
                return text;
            }
        } catch (Exception ex) {
            String text = JsonConverter.toJson(telegram, ex);
            CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(), new IllegalStateException(text)));
            LocalEvents.fireEvent(ce);
            return text;
        }
    }
}
