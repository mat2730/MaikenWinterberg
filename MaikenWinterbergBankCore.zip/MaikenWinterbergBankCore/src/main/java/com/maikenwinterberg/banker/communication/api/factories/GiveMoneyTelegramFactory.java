/*
 * Martin Alexander Thomsen den 12. December 2024
 */
package com.maikenwinterberg.banker.communication.api.factories;

import com.maikenwinterberg.banker.communication.api.GivemoneyTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.translate.Translater;
import static com.maikenwinterberg.banker.util.Base64ToFile.toBase64;
import com.maikenwinterberg.config.Config;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class GiveMoneyTelegramFactory {

    private final String transactionId;
    private final OutputStream os;
    private final File file;

    private boolean first = true;

    public GiveMoneyTelegramFactory(String domainName, String inbox) throws Exception {
        if (inbox == null) {
            inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "inboxDirectory");
        }
        new File(inbox + "/" + domainName).mkdirs();
        this.transactionId = TransactionIdCreator.getTransactionId();
        this.file = new File(inbox + "/" + domainName + "/givemoney_" + transactionId);
        this.os = new FileOutputStream(file);
    }

    public static Telegram createGiveMoneyTelegram(String ip, String sessionId, String domainName, String domainNameOrNumberOfReceiver, Float amount, String text) throws Exception {
        String inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "telegramFactoryDirectory");
        GiveMoneyTelegramFactory f = new GiveMoneyTelegramFactory(domainName, inbox);
        String csv = f.addGiveMoneyLine(domainNameOrNumberOfReceiver, amount, Telegram.LOCAL_BANK, text, null);
        GivemoneyTelegram gt = new GivemoneyTelegram();
        gt.setDomainName(ip, sessionId, domainName);
        gt.setFile(new File(inbox + "/" + domainName + "/givemoney_" + f.transactionId), 0);
        gt.setTransactionId(f.transactionId);
        gt.setReceiverPassportNumberOrDomainName(domainNameOrNumberOfReceiver);
        gt.setCsvLine(csv);
        return gt;
    }

    public String addGiveMoneyLine(String passportNumberOrDomainName, float amount, String nationalBank, String text, List<File> attachments) throws Exception {
        StringBuilder builder = new StringBuilder();
        if (!first) {
            builder.append(Telegram.NEW_LINE);
        }
        first = false;
        builder.append(passportNumberOrDomainName);
        builder.append(Telegram.DELIMITER);
        builder.append(amount);
        builder.append(Telegram.DELIMITER);
        builder.append(nationalBank);
        builder.append(Telegram.DELIMITER);
        if (text == null) {
            text = " ";
        }
        builder.append(text);
        if (attachments != null) {
            for (Iterator<File> i = attachments.iterator(); i.hasNext();) {
                File f = i.next();
                builder.append(Telegram.DELIMITER);
                builder.append(f.getName());
                builder.append(Telegram.DELIMITER);
                builder.append(toBase64(f));
            }
        }
        os.write(builder.toString().getBytes(Telegram.ENCODING));
        return builder.toString();
    }

    public void commit() throws Exception {
        os.flush();
        os.close();
        if (file != null) {
            file.renameTo(new File(file.getAbsolutePath() + ".csv"));
        }
    }
}
