/*
 * Martin Alexander Thomsen den 23. December 2024
 */
package com.maikenwinterberg.banker.accountManager.telegramProcess;

import com.maikenwinterberg.banker.accountManager.DefaultTrustDomainsImpl;
import com.maikenwinterberg.banker.communication.IReceiveRequest;
import com.maikenwinterberg.banker.communication.api.ApproveBankTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.event.CommunicationEvent;
import com.maikenwinterberg.banker.communication.event.LocalEvents;
import com.maikenwinterberg.banker.communication.event.TelegramErrorResponse;
import com.maikenwinterberg.banker.communication.event.TelegramOKResponse;
import com.maikenwinterberg.banker.communication.translate.JsonConverter;
import com.maikenwinterberg.banker.communication.translate.Translater;
import com.maikenwinterberg.banker.util.DomainVerifier;
import java.io.File;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class ApproveBankTelegramProcess implements IReceiveRequest {

    @Override
    public String receiveRequest(Telegram telegram) throws Throwable {
        try {
            DomainVerifier.validateAdminIP(telegram.getIp(), telegram.getSessionId());
            ApproveBankTelegram abt = (ApproveBankTelegram) telegram;
            DomainVerifier.verifyDomain(abt.getBankAccount(), false);
            String directory = DefaultTrustDomainsImpl.getDomainDirectory(abt.getBankAccount());
            File f = new File(directory + "/bank");
            if (abt.isDelete()) {
                 DefaultTrustDomainsImpl.deleteDomainDirectory(abt.getBankAccount());
                if (f.exists()) {
                    String text = Translater.translate(Translater.UNKNOWN_ERROR, telegram.getTransactionId());
                    text = JsonConverter.toJson(telegram, false, text);
                    CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramOKResponse(abt.getTransactionId(),text));
                    LocalEvents.fireEvent(ce);
                    return text;
                } else {
                    String text = Translater.translate(Translater.TRANSACTION_OK, abt.getBankAccount());
                    text = JsonConverter.toJson(telegram, true, text);
                    CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramOKResponse(abt.getTransactionId(),text));
                    LocalEvents.fireEvent(ce);
                    return text;
                }
            } else {
                f.mkdirs();
                if (f.exists()) {
                    String text = Translater.translate(Translater.TRANSACTION_OK, abt.getBankAccount());
                    text = JsonConverter.toJson(telegram, true, text);
                    CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramOKResponse(abt.getTransactionId(),text));
                    LocalEvents.fireEvent(ce);
                    return text;
                } else {
                    String text = Translater.translate(Translater.UNKNOWN_ERROR, telegram.getTransactionId());
                    text = JsonConverter.toJson(telegram, false, text);
                    CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramOKResponse(abt.getTransactionId(),text));
                    LocalEvents.fireEvent(ce);
                    return text;
                }

            }
        } catch (Exception ex) {
            String text = JsonConverter.toJson(telegram, ex);
            CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(),new IllegalStateException(text)));
            LocalEvents.fireEvent(ce);
            return text;
        }
    }
}
