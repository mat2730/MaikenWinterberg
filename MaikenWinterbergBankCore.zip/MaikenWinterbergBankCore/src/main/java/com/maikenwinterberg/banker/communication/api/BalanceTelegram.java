/*
 * Martin Alexander Thomsen den 12. December 2024
 */
package com.maikenwinterberg.banker.communication.api;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class BalanceTelegram extends Telegram{

    @Override
    public void setCsvLine(String csvLine) throws Exception {
    }
    
    @Override
    public String getTransactionId() {
        return null;
    }
}
