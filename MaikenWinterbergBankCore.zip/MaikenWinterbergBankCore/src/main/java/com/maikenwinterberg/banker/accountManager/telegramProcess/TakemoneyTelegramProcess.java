/*
 * Martin Alexander Thomsen den 16. December 2024
 */
package com.maikenwinterberg.banker.accountManager.telegramProcess;

import com.maikenwinterberg.banker.accountManager.AccountManagerService;
import com.maikenwinterberg.banker.accountManager.AccountServiceLookupFactory;
import com.maikenwinterberg.banker.communication.Destination;
import com.maikenwinterberg.banker.communication.IReceiveRequest;
import com.maikenwinterberg.banker.communication.SendRequestFactory;
import com.maikenwinterberg.banker.communication.api.AccountTelegram;
import com.maikenwinterberg.banker.communication.api.TakemoneyTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.event.CommunicationEvent;
import com.maikenwinterberg.banker.communication.event.LocalEvents;
import com.maikenwinterberg.banker.communication.event.TelegramErrorResponse;
import com.maikenwinterberg.banker.communication.event.TelegramOKResponse;
import com.maikenwinterberg.banker.communication.translate.JsonConverter;
import com.maikenwinterberg.banker.communication.translate.Translater;
import com.maikenwinterberg.domainname.DomainHandler;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class TakemoneyTelegramProcess implements IReceiveRequest {

    @Override
    public String receiveRequest(Telegram telegram) throws Throwable {
        try {
            TakemoneyTelegram gmtelegram = (TakemoneyTelegram) telegram;
            Destination source = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountManagerService);
            Destination loader = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.loaderService);
            //test amount
            if (gmtelegram.getAmount() < 0) {
                String text = Translater.translate(Translater.NO_NEGATIVE_AMOUNT, gmtelegram.getAmount());
                text = JsonConverter.toJson(telegram, false, text);
                CommunicationEvent ce = new CommunicationEvent(source, loader, telegram, new TelegramErrorResponse(telegram.getTransactionId(),new IllegalStateException(text)));
                LocalEvents.fireEvent(ce);
                return text;
            }
            String passportNumberOrDomainName = gmtelegram.getGiverPassportNumberOrDomainName();
            String domainNameOfGiver = AccountServiceLookupFactory.getDomainLookupByPassportInstance().getDomainName(passportNumberOrDomainName);
            String receiverDomainName = gmtelegram.getDomainName();
            //check if receiver domain name exists
            if (domainNameOfGiver == null) {
                String text = Translater.translate(Translater.NO_RECEIVER_LINK, passportNumberOrDomainName);
                text = JsonConverter.toJson(telegram, false, text);
                CommunicationEvent ce = new CommunicationEvent(source, loader, telegram, new TelegramErrorResponse(telegram.getTransactionId(),new IllegalStateException(text)));
                LocalEvents.fireEvent(ce);
                return text;
            }
            //check if trusteed
            boolean isTrusted = AccountServiceLookupFactory.getTrustDomainsInstance().isTrusted(domainNameOfGiver, receiverDomainName);
            if (!isTrusted) {
                String text = Translater.translate(Translater.NO_PERMISTION);
                text = JsonConverter.toJson(telegram, false, text);
                CommunicationEvent ce = new CommunicationEvent(source, loader, telegram, new TelegramErrorResponse(telegram.getTransactionId(),new IllegalStateException(text)));
                LocalEvents.fireEvent(ce);
                return text;
            }
            Destination accountService1 = AccountServiceLookupFactory.getAccountDestinationLookupByDomainNameInstance().getAccountService(domainNameOfGiver);
            Destination accountService2 = AccountServiceLookupFactory.getAccountDestinationLookupByDomainNameInstance().getAccountService(receiverDomainName);
            if (AccountManagerService.DO_TRANSACTION) {
                List accounts = new LinkedList();
                accounts.add(accountService1);
                accounts.add(accountService2);
                AccountServiceLookupFactory.getAccountLookupByTransactionInstance().addAccountServices(gmtelegram.getTransactionId(), accounts);
            }
            SendRequestFactory.newInstance().sendRequest(source, accountService1, new AccountTelegram(telegram, domainNameOfGiver, receiverDomainName, AccountTelegram.Action.Kredit, 0F,false));
            try {
                SendRequestFactory.newInstance().sendRequest(source, accountService2, new AccountTelegram(telegram, receiverDomainName, domainNameOfGiver, AccountTelegram.Action.Debit, null,false));
                gmtelegram.setGiverPassportNumberOrDomainName(domainNameOfGiver);
                String text = Translater.translate(gmtelegram.getAmount(), Translater.TRANSFERED_FROM, domainNameOfGiver);
                text = JsonConverter.toJson(telegram, true, text);
                CommunicationEvent ce = new CommunicationEvent(source, loader, telegram, new TelegramOKResponse(telegram.getTransactionId(),text));
                LocalEvents.fireEvent(ce);
                return text;
            } catch (Exception ex) {
                SendRequestFactory.newInstance().sendRequest(source, accountService1, new AccountTelegram(telegram, domainNameOfGiver, receiverDomainName, AccountTelegram.Action.Debit, 0F,false));
                String text = JsonConverter.toJson(telegram, ex);
                CommunicationEvent ce = new CommunicationEvent(source, loader, telegram, new TelegramErrorResponse(telegram.getTransactionId(),new IllegalStateException(text)));
                LocalEvents.fireEvent(ce);
                return text;
            }
        } catch (Exception ex) {
            String text = JsonConverter.toJson(telegram, ex);
            CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(),new IllegalStateException(text)));
            LocalEvents.fireEvent(ce);
            return text;
        }
    }
}
