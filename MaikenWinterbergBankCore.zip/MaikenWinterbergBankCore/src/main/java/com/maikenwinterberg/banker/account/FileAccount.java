/*
 * Martin Alexander Thomsen den 11. December 2024
 *
 * Vil du være min i nat (sang i Randers kulturhus den 21 december 2024 kl 10:35)
 * Its coming down christmas (venner)
 */
package com.maikenwinterberg.banker.account;

import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.loader.LoaderService;
import com.maikenwinterberg.banker.util.DomainVerifier;
import com.maikenwinterberg.config.Config;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.WeakHashMap;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileAccount {

    private static Map<String, File> FILES = new WeakHashMap();
    private static int COUNTER = 0;

    private static String dbDirectory;

    public synchronized static File getFile(String domainName, boolean checkSize) throws Exception {
        File f = FILES.get(domainName);
        if (f == null) {
            if (dbDirectory == null) {
                dbDirectory = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "accountDirectory");
            }
            StringBuilder buf = new StringBuilder();
            buf.append(dbDirectory);
            buf.append("/");
            List<String> l = new LinkedList();
            StringTokenizer tok = new StringTokenizer(domainName, ".");
            while (tok.hasMoreTokens()) {
                l.add(0, tok.nextToken());
            }
            int counter = 0;
            for (Iterator<String> i = l.iterator(); i.hasNext();) {
                if (counter > 0) {
                    buf.append("/");
                }
                String part = i.next();
                if (counter == 1) {
                    buf.append(part.charAt(0));
                    buf.append("/");
                }
                buf.append(part);
                counter++;
            }
            buf.append("/").append("account.txt");
            f = new File(buf.toString());
            FILES.put(domainName, f);
        }
        if (!f.exists()) {
            DomainVerifier.verifyDomain(domainName, false);
            f.getParentFile().mkdirs();
            try {
                f.createNewFile();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            insertLine(domainName, f, "Created on " + LoaderService.getDateString1() + Telegram.DELIMITER + "0.0");
            AccountBean.CACHE.put(domainName, new BigDecimal("0"));
        } else {
            long maxAccountSize = -1;
            try {
                maxAccountSize = Long.parseLong(Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "maxAccountSize"));
            } catch (Exception ex) {
            }
            //check if overflow
            if (checkSize && maxAccountSize > 0) {
                if (f.length() > maxAccountSize) {
                    //archive it and create a new file
                    COUNTER++;
                    if (COUNTER >= 100) {
                        COUNTER = 0;
                    }
                    //String lastLine = getLastLine(domainName, f);
                    BigDecimal oldValue = AccountBean.getOriginalBalance(domainName, f);
                    File oldFile = new File(f.getAbsolutePath() + "_"
                            + LoaderService.getDateString2() + "_" + COUNTER + ".old");
                    f.renameTo(oldFile);
                    File newFile = new File(f.getAbsolutePath());
                    insertLine(domainName, newFile, "Previous file " + oldFile.getAbsolutePath() + Telegram.DELIMITER + oldValue);
                    FILES.put(domainName, newFile);
                    return newFile;
                }
            }
        }
        return f;
    }

    public static File getPreviousFile(File file) {
        File f = null;
        try (FileInputStream fis = new FileInputStream(f)) {
            byte[] d = new byte[200];
            fis.read(d);
            String line = new String(d, Telegram.ENCODING);
            StringTokenizer tok = new StringTokenizer(line, Telegram.DELIMITER);
            String fileName = tok.nextToken();
            f = new File(fileName);
            if (f.exists()) {
                return f;
            } else {
                return null;
            }
        } catch (Exception ex) {
            //ex.printStackTrace();
        }
        return f;
    }

    public static String getLastLine(String donaimName, File file) {
        try {
            if (file.exists()) {
                RandomAccessFile rac = new RandomAccessFile(file, "r");
                long index = rac.length() - 200;
                if (index < 0) {
                    index = 0;
                }
                rac.seek(index);
                byte[] data = new byte[(int) Math.min(1000, file.length() - index)];
                rac.read(data);
                StringTokenizer tok = new StringTokenizer(new String(data, Telegram.ENCODING), Telegram.NEW_LINE);
                String lastToken = null;
                while (tok.hasMoreTokens()) {
                    lastToken = tok.nextToken();
                }
                return lastToken;
            }
        } catch (Exception e) {
            //e.printStackTrace();
        }
        return null;
    }

    public static Lines getLastLines(String donaimName, File file, long blockSize) {
        List lines = new LinkedList();
        Lines lines2Return = null;
        try {
            if (file.exists()) {
                RandomAccessFile rac = new RandomAccessFile(file, "r");
                long index = rac.length() - blockSize;
                if (index < 0) {
                    index = 0;
                }
                lines2Return = new Lines(lines, index);
                rac.seek(index);
                byte[] data = new byte[(int) Math.min(blockSize, file.length() - index)];
                rac.read(data);
                StringTokenizer tok = new StringTokenizer(new String(data, Telegram.ENCODING), Telegram.NEW_LINE);
                //if (index == 0) {
                    //skip first line
                    if (tok.hasMoreTokens()) {
                        tok.nextToken();
                    }
                //}
                while (tok.hasMoreTokens()) {
                    lines.add(tok.nextToken());
                }
            }
            /*else {
                file.getParentFile().mkdirs();
                try {
                    file.createNewFile();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }*/
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lines2Return;
    }

    public static void insertLine(String domainName, File file, String line) throws Exception {
        try (FileOutputStream fos = new FileOutputStream(file, true)) {
            fos.write(line.getBytes(Telegram.ENCODING));
            fos.flush();
        }
    }
}
