/*
 * Martin Alexander Thomsen den 12. December 2024
 */
package com.maikenwinterberg.banker.communication.api;

import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class UnlinkTelegram extends Telegram {

    private String passportnumber;
    private String overrideDomainName;

    @Override
    public void setCsvLine(String csvLine) throws Exception {
        StringTokenizer tok = new StringTokenizer(csvLine, Telegram.DELIMITER);
        this.passportnumber = tok.nextToken();
        if (tok.hasMoreTokens()) {
            this.overrideDomainName = tok.nextToken();
        }
    }

    public String getPassportnumber() {
        return passportnumber;
    }

    public String getOverrideDomainName() {
        return overrideDomainName;
    }
}
