/*
 * Martin Alexander Thomsen den 11. December 2024
 */
package com.maikenwinterberg.banker.communication.api;

import java.io.File;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class AccountTelegram extends Telegram implements HasOriginal {

    public static enum Action {
        Debit, Kredit, Rollback, Balance, History;
    }
    private final boolean isRollback;
    private final Telegram originalTelegram;
    private final String domainName;
    private final String domainNameOfOtherAccount;
    private final Action action;
    private final Float balanceRequired; 

    public AccountTelegram(Telegram originalTelegram, String domainNameOfAccountToBeUpdated, String domainNameOfOtherAccount ,Action action, Float balanceRequired, boolean isRollback) {
        this.isRollback = isRollback;
        this.originalTelegram = originalTelegram;
        this.domainName = domainNameOfAccountToBeUpdated;
        this.domainNameOfOtherAccount = domainNameOfOtherAccount;
        this.action = action;
        this.balanceRequired = balanceRequired;
    }

    public Float getBalanceRequired() {
        return this.balanceRequired;
    }
    
    @Override
    public Telegram getOriginalTelegram() {
        return originalTelegram;
    }

    @Override
    public String getDomainName() {
        return domainName;
    }

    public String getDomainNameOfOtherAccount() {
        return domainNameOfOtherAccount;
    }
    
    public Action getAction() {
        return action;
    }

    public boolean isRollback() {
        return isRollback;
    }
    
    @Override
    public void setDomainName(String ip, String sessionId, String domainName) {
        originalTelegram.setDomainName(ip, sessionId, domainName);
    }

    @Override
    public File getFile() {
        return originalTelegram.getFile();
    }

    @Override
    public int getTelegramIndex() {
        return originalTelegram.getTelegramIndex();
    }

    @Override
    public void setFile(File file, int telegramIndexInFile) {
        originalTelegram.setFile(file, telegramIndexInFile);
    }

    @Override
    public String getTransactionId() {
        return originalTelegram.getTransactionId();
    }

    @Override
    public void setCsvLine(String csvLine) throws Exception {
        originalTelegram.setCsvLine(csvLine);
    }
}
