/*
 * Martin Alexander Thomsen den 5. December 2024
 */
package com.maikenwinterberg.banker.accountManager;

import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.IReceiveRequest;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * An AccountManagerService is responsible for finding the right accountServices
 * to call by looking at the passportNumber, domainName or transactonId
 */
public class AccountManagerService implements IReceiveRequest {

    public static boolean DO_TRANSACTION = false;

    @Override
    public String receiveRequest(Telegram telegram) throws Throwable {
        String className = telegram.getClass().getSimpleName();
        IReceiveRequest requestReceiver = (IReceiveRequest) Class.forName("com.maikenwinterberg.banker.accountManager.telegramProcess." + (className.charAt(0) + "").toUpperCase() + className.substring(1) + "Process").newInstance();
        return requestReceiver.receiveRequest(telegram);
    }
}
