/*
 * Martin Alexander Thomsen den 11. December 2024
 */
package com.maikenwinterberg.banker.accountManager;

import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.util.DomainVerifier;
import com.maikenwinterberg.config.Config;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.InetAddress;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class DefaultDomainLookupByPassport implements IDomainLookupByPassport {

    private String dbDirectory;
    private boolean verifyDomainOnLink;

    @Override
    public String getDomainName(String passportNumberOrDomainName) throws Exception {
        verifyDomainOnLink = Boolean.parseBoolean(Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "verifyDomainOnLink"));
        try {
            DomainVerifier.verifyDomain(passportNumberOrDomainName, false);
            return passportNumberOrDomainName;
        } catch (Exception ex) {
            File f = getFile(passportNumberOrDomainName);
            return getDomainName(f);
        }
    }

    public String getDomainName(String passportNumberOrDomainName, boolean forceLookup) throws Exception {
        if (forceLookup) {
            File f = getFile(passportNumberOrDomainName);
            String domainNameOfFile = getDomainName(f);
            return domainNameOfFile;
        } else {
            return getDomainName(passportNumberOrDomainName);
        }
    }

    private String getDomainName(File f) {
        if (!f.exists()) {
            return null;
        }
        try (FileInputStream fis = new FileInputStream(f)) {
            if (fis.available() == 0) {
                return null;
            }
            byte[] data = new byte[fis.available()];
            fis.read(data);
            return new String(data, Telegram.ENCODING);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    private File getFile(String number) throws Exception{
        if (dbDirectory == null) {
            dbDirectory = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "linkDirectory");
        }
        StringBuilder buf = new StringBuilder();
        buf.append(dbDirectory);
        int index = 0;
        while (true) {
            String part;
            try {
                part = number.substring(index, index + 3);
                buf.append("/").append(part);
            } catch (Exception ex) {
                part = number.substring(index);
                if (!part.trim().isEmpty()) {
                    buf.append("/").append(part);
                }
                break;
            }
            index += 3;
        }
        buf.append("/").append("domainName.txt");
        File f = new File(buf.toString());
        return f;
    }

    @Override
    public void link(String passportNumber, String domainName) throws Exception {
        if (verifyDomainOnLink) {
            InetAddress inetAddress = null;
            try {
                inetAddress = InetAddress.getByName(domainName);
            } catch (Exception ex) {
            }
            if (inetAddress.isAnyLocalAddress()) {
                throw new IllegalStateException("The domainname is a local address " + domainName);
            }
            if (inetAddress == null) {
                throw new IllegalArgumentException("Invalid domainname " + domainName);
            }
        }
        File f = getFile(passportNumber);
        String domainNameOfFile = getDomainName(f);
        if (domainNameOfFile == null) {
            f.getParentFile().mkdirs();
            try (FileOutputStream fos = new FileOutputStream(f)) {
                fos.write(domainName.getBytes(Telegram.ENCODING));
                fos.flush();
            }
        } else if (!domainNameOfFile.equalsIgnoreCase(domainName)) {
            throw new IllegalStateException("The passportnumber " + passportNumber + " is allready linked with " + domainNameOfFile);
        }
    }

    @Override
    public void unLink(String passportNumber, String domainName) throws Exception{
        File f = getFile(passportNumber);
        if (f.exists()) {
            f.renameTo(new File(f.getAbsolutePath() + System.currentTimeMillis() + ".unlinked"));
        }
    }
}
