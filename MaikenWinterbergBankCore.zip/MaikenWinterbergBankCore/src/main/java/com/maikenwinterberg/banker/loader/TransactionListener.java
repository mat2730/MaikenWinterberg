/*
 * Martin Alexander Thomsen den 20. December 2024
 */
package com.maikenwinterberg.banker.loader;

import com.maikenwinterberg.banker.communication.api.ApproveBankTelegram;
import com.maikenwinterberg.banker.communication.api.GivemoneyTelegram;
import com.maikenwinterberg.banker.communication.api.HasOriginal;
import com.maikenwinterberg.banker.communication.api.PrintmoneyTelegram;
import com.maikenwinterberg.banker.communication.api.RollbacktransactionTelegram;
import com.maikenwinterberg.banker.communication.api.TakemoneyTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.event.CommunicationEvent;
import com.maikenwinterberg.banker.communication.event.CommunicationListener;
import com.maikenwinterberg.banker.communication.event.LocalEvents;
import com.maikenwinterberg.banker.communication.event.TelegramOKResponse;
import com.maikenwinterberg.config.Config;
import java.io.File;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.
 */
public class TransactionListener {

    public static void addEventListener(File processedDirectory) {
        CommunicationListener listener = new CommunicationListener() {
            @Override
            public void handleEvent(CommunicationEvent event) {
                //update transactions.log
                try {
                    String doLog = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "useProcessedTransactionsLog");
                    if (doLog != null && doLog.equalsIgnoreCase("false")) {
                        return;
                    }
                    Telegram telegram = event.getTelegram();
                    if (telegram ==null) {
                        return;
                    }
                    if (telegram.getTransactionId()==null) {
                        return;//only handle transactions with an id
                    }
                    if (telegram instanceof HasOriginal) {
                        telegram = ((HasOriginal) telegram).getOriginalTelegram();
                    }
                    File telegramFile = telegram.getFile();
                    if (telegramFile == null) {
                        return;
                    }
                    synchronized (telegramFile) {
                        String domainName = event.getTelegram().getDomainName();
                        CsvTelegramProcess.log(processedDirectory, domainName, telegramFile, event);
                        if (event.getResponse() instanceof TelegramOKResponse) {
                            if (telegram instanceof GivemoneyTelegram) {
                                String receiverPassportNumberOrDomainName = ((GivemoneyTelegram) telegram).getReceiverPassportNumberOrDomainName();
                                CsvTelegramProcess.log(processedDirectory, receiverPassportNumberOrDomainName, telegramFile, event);
                            } else if (telegram instanceof TakemoneyTelegram) {
                                String giverPassportNumberOrDomainName = ((TakemoneyTelegram) telegram).getGiverPassportNumberOrDomainName();
                                CsvTelegramProcess.log(processedDirectory, giverPassportNumberOrDomainName, telegramFile, event);
                            } else if (telegram instanceof PrintmoneyTelegram) {
                                String bankAccount = ((PrintmoneyTelegram) telegram).getBankaccount();
                                CsvTelegramProcess.log(processedDirectory, bankAccount, telegramFile, event);
                            } else if (telegram instanceof RollbacktransactionTelegram) {
                                String passportNumberOrDomainName = ((RollbacktransactionTelegram) telegram).getCounterAccountDomainName();
                                CsvTelegramProcess.log(processedDirectory, passportNumberOrDomainName, telegramFile, event);
                            } else if (telegram instanceof ApproveBankTelegram) {
                                String passportNumberOrDomainName = ((ApproveBankTelegram) telegram).getBankAccount();
                                CsvTelegramProcess.log(processedDirectory, passportNumberOrDomainName, telegramFile, event);
                            }
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        LocalEvents.addListener(listener);
    }
}
