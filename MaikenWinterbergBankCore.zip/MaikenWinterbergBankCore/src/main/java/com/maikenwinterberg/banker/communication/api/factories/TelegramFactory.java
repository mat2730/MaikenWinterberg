/*
 * Martin Alexander Thomsen den 5. December 2024
 */
package com.maikenwinterberg.banker.communication.api.factories;

import com.maikenwinterberg.banker.communication.api.Telegram;
import java.io.File;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class TelegramFactory {

    public static Telegram getBankRequest(String ip, String sessionId, String domainName, File csvFile, int telegramIndex, String telegramLine) throws Exception {
        String requestName;
        String csvFileName = csvFile.getName();
        int index1 = csvFileName.indexOf(".");
        int index2 = csvFileName.indexOf("_");
        if (index1 != -1 && index2 != -1) {
            requestName = csvFileName.substring(1, Math.min(index1, index2));
        } else {
            requestName = csvFileName.substring(1, index1);
        }
        Telegram request = (Telegram) Class.forName("com.maikenwinterberg.banker.communication.api." + (csvFileName.charAt(0) + "").toUpperCase() + requestName + "Telegram").newInstance();
        request.setDomainName(ip, sessionId, domainName);
        request.setFile(csvFile, telegramIndex);
        request.setCsvLine(telegramLine);
        return request;
    }
}
