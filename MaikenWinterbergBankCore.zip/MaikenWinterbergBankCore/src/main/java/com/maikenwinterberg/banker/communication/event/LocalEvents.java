/*
 * Martin Alexander Thomsen den 11. December 2024
 */
package com.maikenwinterberg.banker.communication.event;

import com.maikenwinterberg.banker.loader.LoadBalancer;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class LocalEvents {

    private static List<CommunicationListener> listeners = new LinkedList();

    public static void addListener(CommunicationListener listener) {
        listeners.add(listener);
    }

    public static void fireEvent(CommunicationEvent event) {
        for (Iterator<CommunicationListener> i = listeners.iterator(); i.hasNext();) {
            CommunicationListener listener = i.next();
            listener.handleEvent(event);
        }
    }
}
