/*
 * Martin Alexander Thomsen den 17. December 2024
 */
package com.maikenwinterberg.banker.accountManager;

import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.util.DomainVerifier;
import com.maikenwinterberg.banker.util.FileReaderFix;
import com.maikenwinterberg.config.Config;
import java.io.File;
import java.io.FileOutputStream;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class DefaultTrustDomainsImpl implements ITrustDomains {

    public static void deleteDomainDirectory(String domainName) {

    }

    public static String getDomainDirectory(String domainName) {
        String dbDirectory = null;
        if (dbDirectory == null) {
            dbDirectory = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "domainDirectory");
        }
        domainName = domainName.replace(".", "");
        domainName = domainName.replace("/", "");
        StringBuilder buf = new StringBuilder();
        buf.append(dbDirectory);
        int index = 0;
        while (true) {
            String part;
            try {
                part = domainName.substring(index, index + 3);
                buf.append("/").append(part);
            } catch (Exception ex) {
                part = domainName.substring(index);
                if (!part.trim().isEmpty()) {
                    buf.append("/").append(part);
                }
                break;
            }
            index += 3;
        }
        return buf.toString();
    }

    private File getFile(String domainName) {
        StringBuilder buf = new StringBuilder();
        buf.append(getDomainDirectory(domainName));
        buf.append("/").append("trusteddomains.txt");
        File f = new File(buf.toString());
        return f;
    }

    @Override
    public void addTrustDomains(String domainName, List<String> trustDomains, boolean append) {
        addTrustDomains(domainName, trustDomains, append, false);
    }

    public void addTrustDomains(String domainName, List<String> trustDomains, boolean append, boolean delete) {
        File f = getFile(domainName);
        StringBuilder builder = new StringBuilder();
        if (append || delete) {
            if (trustDomains != null && trustDomains.size() >= 1) {
                List<String> currentTrustDomains = getTrustDomains(domainName);
                if (delete) {
                    for (String trustDomain : trustDomains) {
                        currentTrustDomains.remove(trustDomain);
                    }
                    trustDomains = currentTrustDomains;
                }
                trustDomains.sort(null);

                for (String trustDomain : trustDomains) {
                    if (append) {
                        if (currentTrustDomains.contains(trustDomain)) {
                            continue;
                        }
                    }
                    if (!builder.toString().isEmpty()) {
                        builder.append(",");
                    }
                    DomainVerifier.verifyDomain(trustDomain, false);
                    builder.append(trustDomain);
                }
                if (append) {
                    if (builder.toString().isEmpty()) {
                        return; //nothing new to add
                    }
                }
            } else {
                //nothing to add
                return;
            }
        } else {
            //delete all trust domains
            f.renameTo(new File(f.getAbsolutePath() + "_" + System.currentTimeMillis() + ".old"));
            for (String trustDomain : trustDomains) {
                if (!builder.toString().isEmpty()) {
                    builder.append(",");
                }
                DomainVerifier.verifyDomain(trustDomain, false);
                builder.append(trustDomain);
            }
        }
        //append or add to file
        if (!f.getParentFile().exists()) {
            f.getParentFile().mkdirs();
        }
        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (Exception ex) {
            }
        }
        String line;
        if (!(f.length() == 0) && append) {
            line = Telegram.NEW_LINE + builder.toString();
        } else {
            line = builder.toString();
        }
        try (FileOutputStream fos = new FileOutputStream(f, append)) {
            fos.write(line.getBytes(Telegram.ENCODING));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public boolean isTrusted(String domainName, String trustDomain) {
        File f = getFile(domainName);
        FileReaderFix reader = new FileReaderFix(f);
        String line = reader.readLine();
        while (line != null) {
            if (line.contains(trustDomain)) {
                return true;
            }
            line = reader.readLine();
        }
        return false;
    }

    @Override
    public List<String> getTrustDomains(String domainName) {
        List<String> trustDomains = new LinkedList();
        File f = getFile(domainName);
        FileReaderFix reader = new FileReaderFix(f);
        String line = reader.readLine();
        while (line != null) {
            StringTokenizer tok = new StringTokenizer(line, ",");
            while (tok.hasMoreTokens()) {
                trustDomains.add(tok.nextToken());
            }
            line = reader.readLine();
        }
        return trustDomains;
    }

    @Override
    public void removeTrustDomains(String domainName, List<String> trustDomains2Delete) {
        addTrustDomains(domainName, trustDomains2Delete, false, true);
    }
}
