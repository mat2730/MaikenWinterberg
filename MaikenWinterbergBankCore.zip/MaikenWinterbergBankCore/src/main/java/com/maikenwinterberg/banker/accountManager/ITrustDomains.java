/*
 * Martin Alexander Thomsen den 17. December 2024
 */
package com.maikenwinterberg.banker.accountManager;

import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface ITrustDomains {

    public void addTrustDomains(String domainName, List<String> trustDomains, boolean append);

    public void removeTrustDomains(String domainName, List<String> trustDomains2Delete);

    public boolean isTrusted(String domainName, String trustDomain);

    public List<String> getTrustDomains(String domainName);
}
