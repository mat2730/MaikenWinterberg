/*
 * Martin Alexander Thomsen den 5. December 2024
 */
package com.maikenwinterberg.banker.communication;

import com.maikenwinterberg.config.Config;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class SendRequestFactory {

    private static ISendRequest instance;

    public static ISendRequest newInstance() {
        if (instance == null) {
            try {
                String sendRequestImpl = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "ISendRequestImpl");
                instance = (ISendRequest) Class.forName(sendRequestImpl).newInstance();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        }
        if (instance == null) {
            instance = new MethodCallSender();
        }
        return instance;
    }
}
