/*
 * Martin Alexander Thomsen den 23. December 2024
 */
package com.maikenwinterberg.banker.communication.api.factories;

import com.maikenwinterberg.banker.communication.api.GrantLoanTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import static com.maikenwinterberg.banker.util.Base64ToFile.toBase64;
import com.maikenwinterberg.config.Config;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class GrantLoanTelegramFactory {

    private final String transactionId;
    private final OutputStream os;
    private final File file;
    private boolean first = true;

    public static GrantLoanTelegram createGrantLoanTelegram(String ip, String sessionId, String domainName, String domainNameOrNumberOfLender, Float maxAmount, boolean delete) throws Exception {
        String inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "telegramFactoryDirectory");
        GrantLoanTelegramFactory factory = new GrantLoanTelegramFactory(domainName, inbox);
        String csv = factory.addGranLoanLine(domainNameOrNumberOfLender, maxAmount, delete, null);
        factory.commit();
        GrantLoanTelegram t = new GrantLoanTelegram();
        t.setDomainName(ip, sessionId, domainName);
        t.setFile(new File(inbox + "/" + domainName + "/GrantLoan_" + factory.transactionId), 0);
        t.setTransactionId(factory.transactionId);
        t.setCsvLine(csv);
        return t;
    }

    public GrantLoanTelegramFactory(String domainName, String inbox) throws Exception {
        if (inbox == null) {
            inbox = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "inputDirectory");
        }
        new File(inbox + "/" + domainName).mkdirs();
        this.transactionId = TransactionIdCreator.getTransactionId();
        file = new File(inbox + "/" + domainName + "/GrantLoan_" + transactionId);
        os = new FileOutputStream(file); 
   }

    public String addGranLoanLine(String domainNameOrNumberOfLender, Float maxAmount, boolean delete, List<File> attachments) throws Exception {
        StringBuilder builder = new StringBuilder();
        if (!first) {
            builder.append(Telegram.NEW_LINE);
        }
        first = false;
        builder.append(domainNameOrNumberOfLender);
        builder.append(Telegram.DELIMITER);
        builder.append(maxAmount);
        builder.append(Telegram.DELIMITER);
        builder.append(delete);
        if (attachments != null) {
            for (Iterator<File> i = attachments.iterator(); i.hasNext();) {
                File f = i.next();
                builder.append(Telegram.DELIMITER);
                builder.append(f.getName());
                builder.append(Telegram.DELIMITER);
                builder.append(toBase64(f));
            }
        }
        os.write(builder.toString().getBytes(Telegram.ENCODING));
        return builder.toString();
    }

    public void commit() throws Exception {
        os.flush();
        os.close();
        if (file != null) {
            file.renameTo(new File(file.getAbsolutePath() + ".csv"));
        }
    }
}
