/*
 * Martin Alexander Thomsen den 11. December 2024
 */
package com.maikenwinterberg.banker.communication.event;

import com.maikenwinterberg.banker.communication.Destination;
import com.maikenwinterberg.banker.communication.api.Telegram;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class CommunicationEvent {

    private Destination source;
    private Destination destination;
    private final Telegram telegram;
    private final TelegramResponse response;

    public CommunicationEvent(Telegram telegram, TelegramResponse response) {
        this.telegram = telegram;
        this.response = response;
    }

    public CommunicationEvent(Destination source, Destination destination, Telegram telegram, TelegramResponse response) {
        this.source = source;
        this.destination = destination;
        this.telegram = telegram;
        this.response = response;
    }

    public Destination getDestination() {
        return destination;
    }

    public Destination getSource() {
        return source;
    }

    public Telegram getTelegram() {
        return telegram;
    }

    public TelegramResponse getResponse() {
        return response;
    }
}
