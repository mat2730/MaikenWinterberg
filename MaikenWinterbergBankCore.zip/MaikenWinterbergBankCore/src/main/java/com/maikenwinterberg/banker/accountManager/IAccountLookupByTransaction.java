/*
 * Martin Alexander Thomsen den 11. December 2024
 */
package com.maikenwinterberg.banker.accountManager;

import com.maikenwinterberg.banker.communication.Destination;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IAccountLookupByTransaction {
    public List<Destination> getAccounts(String transactionId) throws Exception;
    public void addAccountServices(String transactionId, List<Destination> accountServices) throws Exception;
    public void removeAccounts(String transactionId) throws Exception;
}