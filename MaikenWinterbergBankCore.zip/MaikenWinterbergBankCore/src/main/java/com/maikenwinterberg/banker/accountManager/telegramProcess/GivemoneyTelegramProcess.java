/*
 * Martin Alexander Thomsen den 12. December 2024
 */
package com.maikenwinterberg.banker.accountManager.telegramProcess;

import com.maikenwinterberg.banker.accountManager.AccountServiceLookupFactory;
import com.maikenwinterberg.banker.communication.Destination;
import com.maikenwinterberg.banker.communication.IReceiveRequest;
import com.maikenwinterberg.banker.communication.SendRequestFactory;
import com.maikenwinterberg.banker.communication.api.AccountTelegram;
import com.maikenwinterberg.banker.communication.api.GivemoneyTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.event.CommunicationEvent;
import com.maikenwinterberg.banker.communication.event.LocalEvents;
import com.maikenwinterberg.banker.communication.event.TelegramErrorResponse;
import com.maikenwinterberg.banker.communication.event.TelegramOKResponse;
import com.maikenwinterberg.banker.communication.translate.JsonConverter;
import com.maikenwinterberg.banker.communication.translate.Translater;
import com.maikenwinterberg.domainname.DomainHandler;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class GivemoneyTelegramProcess implements IReceiveRequest {

    @Override
    public String receiveRequest(Telegram telegram) throws Throwable {
        try {
            Destination source = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountManagerService);
            Destination loader = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.loaderService);
            //test beløb
            GivemoneyTelegram gmtelegram = (GivemoneyTelegram) telegram;
            if (gmtelegram.getAmount() < 0) {
                String text = Translater.translate(Translater.NO_NEGATIVE_AMOUNT, gmtelegram.getAmount());
                text = JsonConverter.toJson(telegram, false, text);
                CommunicationEvent ce = new CommunicationEvent(source, loader, telegram, new TelegramErrorResponse(telegram.getTransactionId(),new IllegalStateException(text)));
                LocalEvents.fireEvent(ce);
                return text;
            }
            String domainNameOfGiver = gmtelegram.getDomainName();
            String passportNumberOrDomainName = gmtelegram.getReceiverPassportNumberOrDomainName();
            String receiverDomainName = AccountServiceLookupFactory.getDomainLookupByPassportInstance().getDomainName(passportNumberOrDomainName);
            if (receiverDomainName == null) {
                String text = Translater.translate(Translater.NO_RECEIVER_LINK, passportNumberOrDomainName);
                text = JsonConverter.toJson(telegram, false, text);
                CommunicationEvent ce = new CommunicationEvent(source, loader, telegram, new TelegramErrorResponse(telegram.getTransactionId(),new IllegalStateException(text)));
                LocalEvents.fireEvent(ce);
                return text;
            }
            Destination accountService1 = AccountServiceLookupFactory.getAccountDestinationLookupByDomainNameInstance().getAccountService(domainNameOfGiver);
            Destination accountService2 = AccountServiceLookupFactory.getAccountDestinationLookupByDomainNameInstance().getAccountService(receiverDomainName);
            SendRequestFactory.newInstance().sendRequest(source, accountService1, new AccountTelegram(telegram, domainNameOfGiver, receiverDomainName, AccountTelegram.Action.Kredit, 0F,false));
            try {
                SendRequestFactory.newInstance().sendRequest(source, accountService2, new AccountTelegram(telegram, receiverDomainName, domainNameOfGiver, AccountTelegram.Action.Debit, null,false));
                gmtelegram.setReceiverPassportNumberOrDomainName(receiverDomainName);
                String text = Translater.translate(gmtelegram.getAmount(), Translater.TRANSFER_TO, receiverDomainName);
                text = JsonConverter.toJson(telegram, true, text);
                CommunicationEvent ce = new CommunicationEvent(source, loader, telegram, new TelegramOKResponse(telegram.getTransactionId(),text));
                LocalEvents.fireEvent(ce);
                return text;
            } catch (Exception ex) {
                String text = JsonConverter.toJson(telegram, ex);
                SendRequestFactory.newInstance().sendRequest(source, accountService1, new AccountTelegram(telegram, domainNameOfGiver, receiverDomainName, AccountTelegram.Action.Debit, 0F,false));
                CommunicationEvent ce = new CommunicationEvent(source, loader, telegram, new TelegramErrorResponse(telegram.getTransactionId(),new IllegalStateException(text)));
                LocalEvents.fireEvent(ce);
                return text;
            }
        } catch (Exception ex) {
            String text = JsonConverter.toJson(telegram, ex);
            CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(),new IllegalStateException(text)));
            LocalEvents.fireEvent(ce);
            return text;
        }
    }
}
