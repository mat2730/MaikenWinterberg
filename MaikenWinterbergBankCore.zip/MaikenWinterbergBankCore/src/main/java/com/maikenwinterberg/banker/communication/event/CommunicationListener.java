/*
 * Martin Alexander Thomsen den 11. December 2024
 */
package com.maikenwinterberg.banker.communication.event;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface CommunicationListener {
    public void handleEvent (CommunicationEvent event);
}
