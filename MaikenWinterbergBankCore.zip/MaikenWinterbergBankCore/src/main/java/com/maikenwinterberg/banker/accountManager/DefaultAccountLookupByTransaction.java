/*
 * Martin Alexander Thomsen den 11. December 2024
 */
package com.maikenwinterberg.banker.accountManager;

import com.maikenwinterberg.banker.communication.Destination;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.domainname.DomainHandler;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class DefaultAccountLookupByTransaction implements IAccountLookupByTransaction {

    private String dbDirectory;

    private File getFile(String transactionId) {
        if (dbDirectory == null) {
            dbDirectory = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "transactionDirectory");
        }
        transactionId = transactionId.replace(".", "");
        transactionId = transactionId.replace("/", "");
        StringBuilder buf = new StringBuilder();
        buf.append(dbDirectory);
        int index = 0;
        while (true) {
            String part;
            try {
                part = transactionId.substring(index, index + 3);
                buf.append("/").append(part);
            } catch (Exception ex) {
                part = transactionId.substring(index);
                if (!part.trim().isEmpty()) {
                    buf.append("/").append(part);
                }
                break;
            }
            index += 3;
        }
        buf.append("/").append("accounts.txt");
        File f = new File(buf.toString());
        return f;
    }

    private String getAccountsAsString(File f) {
        if (!f.exists()) {
            return null;
        }
        try (FileInputStream fis = new FileInputStream(f)) {
            if (fis.available() == 0) {
                return null;
            }
            byte[] data = new byte[fis.available()];
            fis.read(data);
            return new String(data, Telegram.ENCODING);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Destination> getAccounts(String transactionId) throws Exception {
        File f = getFile(transactionId);
        String accountsAsString = getAccountsAsString(f);
        if (accountsAsString == null) return null;
        //[127.0.1.1/accountService, 127.0.1.1/accountService]
        StringTokenizer tok = new StringTokenizer(accountsAsString, ",[]");
        List<Destination> list = new LinkedList();
        while (tok.hasMoreTokens()) {
            String accountService = tok.nextToken();
            list.add(new Destination(accountService.substring(0, accountService.indexOf("/")).trim(), Destination.ServiceName.valueOf(accountService.substring(accountService.indexOf("/") + 1))));
        }
        /*
        if (list.isEmpty()) {
            list.add(new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountService));
            list.add(new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountService));
            saveAccounts(f, list);
             
        }*/
        return list;
    }

    @Override
    public void addAccountServices(String transactionId, List<Destination> accountServices) throws Exception {
        File f = getFile(transactionId);
        String accountsAsString = getAccountsAsString(f);
        if (accountsAsString != null) {
            throw new IllegalStateException("The transactionId exists allready " + transactionId);
        }
        saveAccounts(f, accountServices);
    }

    private void saveAccounts(File f, List<Destination> accountServices) throws Exception {
        if (f.getParentFile().mkdirs());
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write(accountServices.toString().getBytes(Telegram.ENCODING));
            fos.flush();
        }
    }

    public static void main(String arg[]) {
        List<Destination> list = new LinkedList();
        list.add(new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountService));
        list.add(new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountService));
        System.out.println(list);
    }

    @Override
    public void removeAccounts(String transactionId) throws Exception {
        getFile(transactionId).delete();
    }
}