/*
 * Martin Alexander Thomsen den 12. December 2024
 */
package com.maikenwinterberg.banker.communication.api;

import static com.maikenwinterberg.banker.communication.api.Telegram.getDateString;
import com.maikenwinterberg.banker.loader.LoaderService;
import com.maikenwinterberg.banker.util.Base64ToFile;
import com.maikenwinterberg.config.Config;
import java.util.List;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class PrintmoneyTelegram extends Telegram implements HasAmount {

    private String bankaccount;
    private String passportnumberOrDomainName;
    private float amount;
    private String text;
    private boolean isLoan;
    private List<String> images;

    @Override
    public void setCsvLine(String csvLine) throws Exception {
        StringTokenizer tok = new StringTokenizer(csvLine, Telegram.DELIMITER);
        this.bankaccount = tok.nextToken();
        this.passportnumberOrDomainName = tok.nextToken();
        this.amount = Float.parseFloat(tok.nextToken());
        this.text = tok.nextToken();
        try {
            this.isLoan = Boolean.parseBoolean(tok.nextToken());
        } catch (Exception ex) {
            this.isLoan = true;
        }
        String saveAttachments = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "saveAttachments");
        if (saveAttachments != null && saveAttachments.equalsIgnoreCase("false")) {
            return;
        }
        String imageDirectory = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "imageDirectory");
        while (tok.hasMoreTokens()) {
            String nameOfAttachment = tok.nextToken();
            String base64 = tok.nextToken();
            String fileName = "/" + getDomainName() + "/" + getDateString() + "/" + getClass().getSimpleName() + "/" + LoaderService.appendDate2FileName(nameOfAttachment);
            String fullFileName = imageDirectory + fileName;
            Base64ToFile.toFile(base64, fullFileName);
            images.add(fullFileName);
        }
    }
    public void setBankAccount(String bankAccount) {
        this.bankaccount = bankAccount;
    }

    public String getBankaccount() {
        return bankaccount;
    }

    public String getPassportnumberOrDomainName() {
        return passportnumberOrDomainName;
    }

    public void setPassportnumberOrDomainName(String domainName) {
        this.passportnumberOrDomainName = domainName;
    }

    @Override
    public boolean isRollback() {
        return false;
    }

    public boolean isLoan() {
        return this.isLoan;
    }
    
    @Override
    public float getAmount() {
        return amount;
    }

    @Override
    public String getText() {
        return text;
    }

    public List<String> getImages() {
        return images;
    }
}
