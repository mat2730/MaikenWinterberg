/*
 * Martin Alexander Thomsen den 22. December 2024
 */
package com.maikenwinterberg.banker.util;

import com.maikenwinterberg.account.database.Info;
import com.maikenwinterberg.account.datagram.GetAccountNameBySessionIdClient;
import com.maikenwinterberg.account.datagram.ISessionClient;
import com.maikenwinterberg.account.datagram.SessionClientFactory;
import com.maikenwinterberg.banker.communication.translate.JsonConverter;
import com.maikenwinterberg.banker.communication.translate.Translater;
import com.maikenwinterberg.config.Config;
import java.net.InetAddress;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.
 */
public class DomainVerifier {

    public static String validateIP(String ip, String domainName, String sessionId) throws Exception {
        if (sessionId != null) {
            //green konto
            ISessionClient sessionClient = SessionClientFactory.getSessionClient();
            Info info = sessionClient.getAccountInfo(sessionId);
            if (info == null) {
                throw new IllegalAccessException("The session is no longer valid - try to enter the account again.");
            }
            if (info.getCurrentIP().equals(ip)) {
                if (domainName != null) {
                    String accountDomainName = info.getAccountName();
                    int index = accountDomainName.lastIndexOf("@");
                    if (index != -1) {
                        accountDomainName = accountDomainName.substring(0, index);
                    }
                    if (accountDomainName.contains(".")) {
                        //must be verified
                        if (!accountDomainName.equals(domainName)) {
                            throw new IllegalAccessException("Invalid domain " + domainName);
                        }
                    }
                }
                return info.getAccountName();
            }
        } else {
            throw new IllegalAccessException("SessionId is missing");
        }
        throw new IllegalAccessException("Invalid ip "+ip);
    }

    public static String validateAdminIP(String ip, String sessionId) throws Exception {
        if (ip != null) {
            String ips = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "adminDomains");
            StringTokenizer tok = new StringTokenizer(ips, ";");
            Info info = SessionClientFactory.getSessionClient().getAccountInfo(sessionId);
            while (tok.hasMoreTokens()) {
                String token = tok.nextToken();
                if (sessionId != null) {
                    //green konto
                    if (info != null && info.getCurrentIP().equals(ip) && token.equals(info.getAccountName())) {
                        return info.getAccountName();
                    }
                } else {
                    //static ip
                    try {
                        return validateIP(ip, token, sessionId);
                    } catch (Exception ex) {
                    }
                }
            }
            String text = JsonConverter.toJson(null, false, Translater.translate(ip, Translater.INVALID_DOMAIN3));
            throw new IllegalAccessException(text);
        } else {
            String text = JsonConverter.toJson(null, false, Translater.translate(ip, Translater.INVALID_DOMAIN3));
            throw new IllegalAccessException(text);
        }
    }

    public static void verifyDomain(String accountName, boolean isLocalOK)
            throws IllegalArgumentException {
        try {
            String domainName = accountName;
            int index = accountName.lastIndexOf("@");
            if (index != -1) {
                domainName = accountName.substring(0, index);
            }
            if (domainName.contains(".")) {
                //must be verified
                try {
                    InetAddress inetAddress = InetAddress.getByName(domainName);
                    if (!isLocalOK) {
                        if (inetAddress.isAnyLocalAddress()) {
                            throw new IllegalArgumentException(Translater.translate(Translater.IS_LOCAL_DOMAIN, domainName));
                        }
                    }
                    if (inetAddress != null) {
                        return;
                    } else {
                    }
                } catch (Exception ex) {
                }
            } else {
                String accountUrl = Config.getValue(Config.Group.accountConfig, Config.Property.account, "accountHost");
                if (accountName.endsWith(accountUrl)) {
                    //its a green domain
                    return;
                }
            }
        } catch (Exception ex) {
        }
        throw new IllegalArgumentException(Translater.translate(Translater.INVALID_DOMAIN, accountName));
    }
}
