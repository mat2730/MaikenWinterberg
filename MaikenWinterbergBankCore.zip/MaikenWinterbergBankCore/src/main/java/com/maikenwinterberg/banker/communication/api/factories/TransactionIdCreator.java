/*
 * Martin Alexander Thomsen den 20. December 2024
 */
package com.maikenwinterberg.banker.communication.api.factories;

import com.maikenwinterberg.banker.loader.LoaderService;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class TransactionIdCreator {

    private static int counter;

    public static String getTransactionId() {
        if (counter >= 10) {
            counter = 0;
        }
        return LoaderService.getDateString2() + counter++;
    }
}
