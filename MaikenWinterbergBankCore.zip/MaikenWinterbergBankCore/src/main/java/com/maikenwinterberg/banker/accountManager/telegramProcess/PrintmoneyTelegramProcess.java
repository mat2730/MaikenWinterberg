/*
 * Martin Alexander Thomsen den 16. December 2024
 */
package com.maikenwinterberg.banker.accountManager.telegramProcess;

import com.maikenwinterberg.banker.accountManager.AccountServiceLookupFactory;
import com.maikenwinterberg.banker.accountManager.DefaultTrustDomainsImpl;
import com.maikenwinterberg.banker.communication.Destination;
import com.maikenwinterberg.banker.communication.IReceiveRequest;
import com.maikenwinterberg.banker.communication.SendRequestFactory;
import com.maikenwinterberg.banker.communication.api.AccountTelegram;
import com.maikenwinterberg.banker.communication.api.PrintmoneyTelegram;
import com.maikenwinterberg.banker.communication.api.Telegram;
import com.maikenwinterberg.banker.communication.event.CommunicationEvent;
import com.maikenwinterberg.banker.communication.event.LocalEvents;
import com.maikenwinterberg.banker.communication.event.TelegramErrorResponse;
import com.maikenwinterberg.banker.communication.event.TelegramOKResponse;
import com.maikenwinterberg.banker.communication.translate.JsonConverter;
import com.maikenwinterberg.banker.communication.translate.Translater;
import com.maikenwinterberg.config.Config;
import com.maikenwinterberg.domainname.DomainHandler;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * you can print both negativ and positiv amount
 */
public class PrintmoneyTelegramProcess implements IReceiveRequest {

    @Override
    public String receiveRequest(Telegram telegram) throws Throwable {
        //TODO verify domainname - are you allowed to print
        try {
            Destination source = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.accountManagerService);
            Destination loader = new Destination(DomainHandler.getLocalIp(), Destination.ServiceName.loaderService);

            PrintmoneyTelegram pt = (PrintmoneyTelegram) telegram;
            String passportNumberOrDomainName = pt.getPassportnumberOrDomainName();
            String receiverDomainName = AccountServiceLookupFactory.getDomainLookupByPassportInstance().getDomainName(passportNumberOrDomainName);
            if (receiverDomainName == null) {
                String text = Translater.translate(Translater.NO_RECEIVER_LINK);
                text = JsonConverter.toJson(telegram, false, text);
                CommunicationEvent ce = new CommunicationEvent(source, loader, telegram, new TelegramErrorResponse(telegram.getTransactionId(), new IllegalStateException(text)));
                LocalEvents.fireEvent(ce);
                return text;
            }
            String domainNameOfBank = pt.getBankaccount();
            String directory = DefaultTrustDomainsImpl.getDomainDirectory(domainNameOfBank);
            File directoryOfBank = new File(directory + "/bank");
            if (pt.isLoan()) {
                String defaultBank = null;
                try {
                    defaultBank = Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "defaultBank");
                } catch (Exception ex) {
                }
                if (!directoryOfBank.exists()) {
                    //use the default bank
                    if (defaultBank != null) {
                        //use the default bank.
                        directory = DefaultTrustDomainsImpl.getDomainDirectory(defaultBank);
                        directoryOfBank = new File(directory + "/bank");
                        domainNameOfBank = defaultBank;
                        directoryOfBank.mkdirs();
                    } else {
                        String text = Translater.translate(Translater.UNKNOWN_BANK, domainNameOfBank);
                        text = JsonConverter.toJson(telegram, false, text);
                        CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(), new IllegalStateException(text)));
                        LocalEvents.fireEvent(ce);
                        return text;
                    }
                }
                if (!directoryOfBank.exists()) {
                    String text = Translater.translate(Translater.UNKNOWN_BANK, domainNameOfBank);
                    text = JsonConverter.toJson(telegram, false, text);
                    CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(), new IllegalStateException(text)));
                    LocalEvents.fireEvent(ce);
                    return text;
                }
                //init maxLoan and currentLoan
                Float maxLoan = Float.valueOf("0");
                Float currentLoan = Float.valueOf("0");
                File f2 = new File(directoryOfBank.getAbsolutePath() + "/" + receiverDomainName + ".txt");
                String attributes = null;
                if (f2.exists()) {
                    try (FileInputStream fis = new FileInputStream(f2)) {
                        byte[] d = new byte[fis.available()];
                        fis.read(d);
                        attributes = new String(d, Telegram.ENCODING);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
                if (attributes != null) {
                    try {
                        StringTokenizer tok = new StringTokenizer(attributes, Telegram.DELIMITER);
                        maxLoan = Float.valueOf(tok.nextToken());
                        currentLoan = Float.valueOf(tok.nextToken());
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
                //if default bank set defaultBankMaxLoanAmount
                if (maxLoan == 0 && defaultBank != null && defaultBank.equalsIgnoreCase(domainNameOfBank)) {
                    //set max loan for default loan bank
                    maxLoan = Float.valueOf(Config.getValue(Config.Group.bankerConfig, Config.Property.banker, "defaultBankMaxLoanAmount"));
                }
                //loan or fail
                if (maxLoan - pt.getAmount() - currentLoan < 0) {
                    String text = Translater.translate(pt.getAmount(), Translater.AMOUNT_IS_TO_BIG, maxLoan - currentLoan);
                    text = JsonConverter.toJson(telegram, false, text);
                    CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(), new IllegalStateException(text)));
                    LocalEvents.fireEvent(ce);
                    return text;
                } else {
                    currentLoan += pt.getAmount();
                    try (FileOutputStream fos = new FileOutputStream(f2)) {
                        fos.write((maxLoan + Telegram.DELIMITER + currentLoan).getBytes(Telegram.ENCODING));
                    } catch (Exception ex) {
                        String text = Translater.translate(pt.getAmount(), Translater.UNKNOWN_ERROR, maxLoan - currentLoan);
                        text = JsonConverter.toJson(telegram, false, text);
                        CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(), new IllegalStateException(text, ex)));
                        LocalEvents.fireEvent(ce);
                        //f2.delete();
                        return text;
                    }
                }
            } else {
                if (!directoryOfBank.exists()) {
                    String text = Translater.translate(Translater.UNKNOWN_BANK, domainNameOfBank);
                    text = JsonConverter.toJson(telegram, false, text);
                    CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(), new IllegalStateException(text)));
                    LocalEvents.fireEvent(ce);
                    return text;
                }
            }
            //print money
            Destination accountService1 = AccountServiceLookupFactory.getAccountDestinationLookupByDomainNameInstance().getAccountService(domainNameOfBank);
            Destination accountService2 = AccountServiceLookupFactory.getAccountDestinationLookupByDomainNameInstance().getAccountService(receiverDomainName);
            /*
            if (AccountManagerService.DO_TRANSACTION) {
                List accounts = new LinkedList();
                accounts.add(accountService1);
                accounts.add(accountService2);
                AccountServiceLookupFactory.getAccountLookupByTransactionInstance().addAccountServices(pt.getTransactionId(), accounts);
            }*/
            //domainname account Skal gå i minus
            SendRequestFactory.newInstance().sendRequest(source, accountService1, new AccountTelegram(telegram, domainNameOfBank, receiverDomainName, AccountTelegram.Action.Kredit, null, false));
            try {
                pt.setPassportnumberOrDomainName(receiverDomainName);
                pt.setBankAccount(domainNameOfBank);
                String text = Translater.translate(pt.getAmount(), Translater.PRINTET_TO, receiverDomainName, Translater.FROM_BANK, domainNameOfBank);
                text = JsonConverter.toJson(telegram, true, text);
                SendRequestFactory.newInstance().sendRequest(source, accountService2, new AccountTelegram(telegram, receiverDomainName, domainNameOfBank, AccountTelegram.Action.Debit, null, false));
                CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramOKResponse(telegram.getTransactionId(), text));
                LocalEvents.fireEvent(ce);
                return text;
            } catch (Exception ex) {
                pt.setPassportnumberOrDomainName(receiverDomainName);
                pt.setBankAccount(domainNameOfBank);
                String text = Translater.translate(Translater.UNKNOWN_ERROR, pt.getTransactionId());
                text = JsonConverter.toJson(telegram, false, text);
                SendRequestFactory.newInstance().sendRequest(source, accountService1, new AccountTelegram(telegram, domainNameOfBank, receiverDomainName, AccountTelegram.Action.Debit, null, false));
                CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(), new IllegalStateException(text)));
                LocalEvents.fireEvent(ce);
                return text;
            }
        } catch (Exception ex) {
            String text = JsonConverter.toJson(telegram, ex);
            CommunicationEvent ce = new CommunicationEvent(telegram, new TelegramErrorResponse(telegram.getTransactionId(), new IllegalStateException(text)));
            LocalEvents.fireEvent(ce);
            return text;
        }
    }
}
