/*
 * Martin Alexander Thomsen den 17. December 2024
 */
package com.maikenwinterberg.banker.communication.api;

import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * Domains that are allowed to take money from your account. Can be used for:
 * Automatic payments For passport only payments when you only have a passport
 * without a mobil phone or a computer. (manual task??)
 */
public class TrustdomainsTelegram extends Telegram {

    private boolean append;  //new list or append to old list of trusted domains
    private boolean reversed;
    private final List<String> trustedDomainNames = new LinkedList();

    @Override
    public void setCsvLine(String csvLine) throws Exception {
        StringTokenizer tok = new StringTokenizer(csvLine, Telegram.DELIMITER);
        String domainsSeperatedBySemicolon = tok.nextToken();
        StringTokenizer tok2 = new StringTokenizer(domainsSeperatedBySemicolon, ",");
        while (tok2.hasMoreTokens()) {
            trustedDomainNames.add(tok2.nextToken());
        }
        try {
            this.append = Boolean.parseBoolean(tok.nextToken());
        } catch (Exception ex) {
            append = true;
        }
        try {
            this.reversed = Boolean.parseBoolean(tok.nextToken());
        } catch (Exception ex) {
            reversed = true;
        }
    }

    public List<String> getTrustedDomainNames() {
        return this.trustedDomainNames;
    }

    public boolean isAppend() {
        return this.append;
    }

    public boolean isReversed() {
        return this.reversed;
    }
}
