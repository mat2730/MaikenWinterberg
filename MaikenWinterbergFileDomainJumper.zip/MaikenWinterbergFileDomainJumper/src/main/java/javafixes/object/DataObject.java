package javafixes.object;

/**
 * {@link DataObject} is intended as a base class for domain objects.
 * It adds reflection based methods {@code equals()}, {@code hashCode()}
 * and {@code toString()} so your domain classes can be more readable.
 *
 * @author mtymes
 */
public abstract class DataObject {

}
