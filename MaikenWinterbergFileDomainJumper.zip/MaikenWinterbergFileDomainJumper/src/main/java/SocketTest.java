
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author martin
 */
public class SocketTest extends Thread {

    private String host;
    private int port;

    public SocketTest(String host, int port) {
        this.host = host;
        this.port = port;
    }

    @Override
    public void run() {
        try {
            System.err.println("Listening on port " + this + "...");
            ServerSocket SERVER_SOCKET = new ServerSocket(port);
            System.err.println("Listening on port " + this);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("error " + this);
        }
        System.out.println("done " + this);
    }

    public void run2() {
        try {
            System.out.println("connecting to " + this);
            //Socket s = new Socket(host, port);
            Socket socket = new Socket();
            SocketAddress socketAddress = new InetSocketAddress(host, port);
            socket.connect(socketAddress, 30000);
            System.out.println("connected to " + this);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("error " + this);
        }
        System.out.println("done " + this);
    }

    public String toString() {
        return host + ":" + port;
    }

    public static void main(String arg[]) throws Exception {
        //do not work
        new SocketTest("0.0.0.0", 4445).start();
        new SocketTest("0.0.0.0", 4554).start();
        new SocketTest("0.0.0.0", 6666).start();
        new SocketTest("0.0.0.0", 6667).start();
        
        //new SocketTest("maikenwinterberg.com", 4445).start();
        //new SocketTest("documentnetwork.com", 4445).start();
        //new SocketTest("dokumentnetwork.com", 4446).start();

        //new SocketTest("dokumentnetwork.com", 6666).start();
        //new SocketTest("dokumentnetwork.com", 6667).start();
        //new SocketTest("maikenwinterberg.com", 6666).start();
        //new SocketTest("documentnetwork.com", 6666).start();
        //new SocketTest("maikenwinterberg.com", 6667).start();
        //new SocketTest("documentnetwork.com", 6667).start();
        //new SocketTest("dr.dk", 6667).start();
    }
}
