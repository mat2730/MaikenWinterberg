/*
 * Martin Alexander Thomsen den 10 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.router;

import java.net.InetAddress;
import java.util.LinkedList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import com.maikenwinterberg.filedomainjumper.FileSender;
import com.maikenwinterberg.documentiterator.IDocumentNode;
import com.maikenwinterberg.domainname.DomainHandler;
import java.io.ByteArrayInputStream;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class XPathDocumentRouter implements IDocumentRouter {

    @Override
    public List<String> getDomainNamesOfRecievers(int index, IDocumentNode documentNode) {
        List<String> domains = new LinkedList();
        int xpathIndex = 1;
        while (true) {
            String xpathConfig = FileSender.getProperty(index + ".xpath." + xpathIndex++);
            if (xpathConfig == null || xpathConfig.trim().isEmpty()) {
                break;
            }
            System.out.println("looking up xpath " + xpathConfig);
            try {
               // FileInputStream fileIS = new FileInputStream(file);
                ByteArrayInputStream bais = new ByteArrayInputStream(documentNode.getBytes());
                DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = builderFactory.newDocumentBuilder();
                Document xmlDocument = builder.parse(bais);
                XPath xPath = XPathFactory.newInstance().newXPath();
                NodeList nodeList = (NodeList) xPath.compile(xpathConfig).evaluate(xmlDocument, XPathConstants.NODESET);
                System.out.println("nodeList: " + nodeList.getLength());
                String domainName = null;
                for (int i = 0; i < nodeList.getLength(); i++) {
                    try {
                        Node n = nodeList.item(i);
                        //domainName = n.getNodeValue();
                        domainName = n.getTextContent();
                        if (domainName == null || domainName.trim().isEmpty()) {
                            domainName = n.getNodeValue();
                        }
                        if (domainName == null || domainName.trim().isEmpty()) {
                            continue;
                        }
                        int sIndex = domainName.indexOf("@");
                        if (sIndex != -1) {
                            //its an email - turn into domainname
                            domainName = domainName.substring(sIndex + 1);
                        }
                        System.out.println("nodvalue " + domainName);
                        if (domainName.toLowerCase().contains("documentnetwork.com") || domainName.toLowerCase().contains("maikenwinterberg.com")) {
                            domains.add(domainName);
                        } else {
                            String hostAddress = DomainHandler.getHostAddress(domainName);
                            if (hostAddress != null) {
                                domains.add(domainName);
                            } else {
                                System.out.println("found " + domainName + " at xpath: " + xpathConfig + ", but its not a valid domainname.");

                            }
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        System.out.println("found " + domainName + " at xpath: " + xpathConfig + ", exception: " + ex.getMessage());
                    }

                }
            } catch (Exception ex) {
                ex.printStackTrace();
                System.out.println("found nothing at xpath: " + xpathConfig + ", exception: " + ex.getMessage());
            }
            if (domains.size() > 0) {
                return domains;
            }
        }
        return domains;
    }
}
