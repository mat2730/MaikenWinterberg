/*
 * Martin Alexander Thomsen den 8 August 2024
 */
package com.maikenwinterberg.filedomainjumper.documentiterator;

import com.maikenwinterberg.filedomainjumper.LookupRegistries;
import com.maikenwinterberg.filedomainjumper.documentprocess.FileProcessUtil;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class DocumentIteratorFactory {

    // private final static Map<Integer, IDocumentIterator> CACHE = new HashMap();
    public static IDocumentIterator getIterator(Map registriesByDomain, String defaultDomainNameOfClient, String serviceName, int index) {
        IDocumentIterator documentIterator = null;//CACHE.get(index);
        if (documentIterator != null) {
            return documentIterator;
        }
        IDocumentTouch touch = null;
        try {
            String fileDocumentIteratorClass = LookupRegistries.PROPERTIES.getProperty(index + ".documentTouch");
            if (fileDocumentIteratorClass == null) {
                fileDocumentIteratorClass = LookupRegistries.PROPERTIES.getProperty("defaultDocumentTouch");
            }
            touch = (IDocumentTouch) Class.forName(fileDocumentIteratorClass).newInstance();
        } catch (Exception ex) {
            //ignore
        }
        if (touch == null) {
            touch = new QueueHandlerTouch();
        }
        try {
            String fileDocumentIteratorClass = LookupRegistries.PROPERTIES.getProperty(index + ".documentIterator");
            if (fileDocumentIteratorClass == null) {
                fileDocumentIteratorClass = LookupRegistries.PROPERTIES.getProperty("defaultDocumentIterator");
            }
            documentIterator = (IDocumentIterator) Class.forName(fileDocumentIteratorClass).newInstance();
        } catch (Exception ex) {
            //ignore
        }
        if (documentIterator == null) {
            documentIterator = new JumperFileDocumentIterator();
        }
        if (documentIterator instanceof JumperFileDocumentIterator fileDocumentIterator) {
            fileDocumentIterator.setRegistriesByDomain(registriesByDomain);
            fileDocumentIterator.setConfigIndex(index);
            fileDocumentIterator.setDomainNameOfClient(defaultDomainNameOfClient);
            fileDocumentIterator.setServiceName(serviceName);
            fileDocumentIterator.setStartingDir(FileProcessUtil.getOutbox(index));
        }
        documentIterator.setTouch(touch);
        return documentIterator;
    }
}
