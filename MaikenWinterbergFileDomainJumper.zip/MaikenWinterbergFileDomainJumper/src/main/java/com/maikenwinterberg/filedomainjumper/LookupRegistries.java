/*
 * Martin Alexander Thomsen den 30 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper;

import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import javax.swing.filechooser.FileSystemView;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class LookupRegistries {

    public static final Properties PROPERTIES = new Properties();
    private static final List<ClientRegistry> DEFAULT_REGISTRIES = new LinkedList();
    private static final Map<String, List<ClientRegistry>> DOMAIN_REGISTRIES = new HashMap();
    private static final Map<Integer, List<ClientRegistry>> OUTBOX_REGISTRIES = new HashMap();
    private static long LAST_MODIFIED = 0;

    public static List<ClientRegistry> getRegistries(String defaultDomainNameOfClient, boolean useExternalID, String registriesAsString) {
        List<ClientRegistry> list = new LinkedList();
        if (registriesAsString != null && !registriesAsString.trim().isEmpty()) {
            StringTokenizer tok = new StringTokenizer(registriesAsString, ";");
            while (tok.hasMoreTokens()) {
                try {
                    String registryConfig = tok.nextToken().toLowerCase();
                    StringTokenizer tok2 = new StringTokenizer(registryConfig, ":");
                    String url = tok2.nextToken();
                    String port = "4554";
                    try {
                        if (tok2.hasMoreTokens()) {
                            port = tok2.nextToken();
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    ClientRegistry clientRegistry = ClientRegistry.getRegistryInstance(defaultDomainNameOfClient, url, Integer.parseInt(port), useExternalID, false);
                    list.add(clientRegistry);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
        return terning(list);
    }

    private static List terning(List<ClientRegistry> list) {
        java.util.Random rand = new java.util.Random();
        LinkedList newList = new LinkedList();
        while (!list.isEmpty()) {
            if (rand.nextBoolean()) {
                ClientRegistry obj = (ClientRegistry) list.get(0);
                newList.add(obj);
                list.remove(obj);
            } else {
                ClientRegistry obj = (ClientRegistry) list.get(list.size() - 1);
                newList.add(obj);
                list.remove(obj);
            }
        }
        return newList;
    }

    private static File getFileSenderFile() throws Exception {
        FileSystemView view = FileSystemView.getFileSystemView();
        String configFolder = view.getHomeDirectory().getAbsolutePath();
        File domainJumperConfig = new File(configFolder + "/config/fileDomainJumperConfig/fileSender.properties");
        if (!domainJumperConfig.exists()) {
            domainJumperConfig = new File("/config/fileDomainJumperConfig/fileSender.properties");
        }
        return domainJumperConfig;
    }

    public static void initIfChanged() throws Exception {
        File f = getFileSenderFile();
        BasicFileAttributes attr = Files.readAttributes(f.toPath(), BasicFileAttributes.class);
        FileTime fileDate = attr.lastModifiedTime();
        if (LAST_MODIFIED != fileDate.toMillis()) {
            init();
        }
    }

    public static void init() throws Exception {
        if (DEFAULT_REGISTRIES != null) {
            for (ClientRegistry cr : DEFAULT_REGISTRIES) {
                cr.close();
            }
            DEFAULT_REGISTRIES.clear();
        }
        if (OUTBOX_REGISTRIES != null) {
            for (List<ClientRegistry> crl : OUTBOX_REGISTRIES.values()) {
                for (ClientRegistry cr : crl) {
                    cr.close();
                }
            }
            OUTBOX_REGISTRIES.clear();
        }
        if (DOMAIN_REGISTRIES != null) {
            for (List<ClientRegistry> crl : DOMAIN_REGISTRIES.values()) {
               for (ClientRegistry cr : crl) {
                    cr.close();
                }
            }
            DOMAIN_REGISTRIES.clear();
        }
        PROPERTIES.clear();
        File f = getFileSenderFile();
        BasicFileAttributes attr = Files.readAttributes(f.toPath(), BasicFileAttributes.class);
        FileTime fileDate = attr.lastModifiedTime();
        LAST_MODIFIED = fileDate.toMillis();
        PROPERTIES.load(new FileInputStream(f));
        String useExternalIDString = PROPERTIES.getProperty("useExternalID", "true");
        boolean useExternalID = true;
        try {
            useExternalID = Boolean.parseBoolean(useExternalIDString);
        } catch (Exception ex) {
        }
        System.out.println("adding default registries");
        String defaultDomainNameOfClient = PROPERTIES.getProperty("defaultDomainNameOfClient");
        String defaultRegistries = PROPERTIES.getProperty("defaultRegistries");
        //for all registries
        try {
            DEFAULT_REGISTRIES.addAll(getRegistries(defaultDomainNameOfClient, useExternalID, defaultRegistries));
        } catch (Exception ex) {
            System.out.println("failed to load default registries");
        }
        int index = 1;
        System.out.println("adding outbox registries");
        while (true) {
            try {
                //init properties
                String outbox = PROPERTIES.getProperty(index + ".outbox");
                if (outbox == null) {
                    //end of config
                    break;
                }
                String registries = PROPERTIES.getProperty(index + ".registries");
                List<ClientRegistry> outboxReigstries = getRegistries(defaultDomainNameOfClient, useExternalID, registries);
                OUTBOX_REGISTRIES.put(index, outboxReigstries);
            } catch (Exception ex) {
                System.out.println("failed to load registries for outbox index " + index);
            }
            index++;
        }
        System.out.println("adding domain registries");
        for (Iterator i = PROPERTIES.keySet().iterator(); i.hasNext();) {
            String key = i.next().toString();
            if (key.startsWith("registries.")) {
                String domain = key.substring(11);
                String registries = PROPERTIES.getProperty(key);
                DOMAIN_REGISTRIES.put(domain, getRegistries(defaultDomainNameOfClient, useExternalID, registries));
            }
        }
        System.out.println("default registries " + DEFAULT_REGISTRIES);
        System.out.println("outbox registries " + OUTBOX_REGISTRIES);
        System.out.println("domain registries " + DOMAIN_REGISTRIES);
    }

    private static void addOven(List list, String domainName) {
        //adding own domain as registry on default port (if exists)
        try {
            String useExternalIDString = PROPERTIES.getProperty("useExternalID", "true");
            boolean useExternalID = true;
            try {
                useExternalID = Boolean.parseBoolean(useExternalIDString);
            } catch (Exception ex) {
            }
            String defaultDomainNameOfClient = PROPERTIES.getProperty("defaultDomainNameOfClient");
            ClientRegistry clientRegistry = ClientRegistry.getRegistryInstance(defaultDomainNameOfClient, domainName, 4554, useExternalID, false);
            list.add(clientRegistry);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static List<ClientRegistry> getLookupRegistries(int index, String domainName) throws Exception {
        initIfChanged();
        List registries = OUTBOX_REGISTRIES.get(index);
        if (registries != null && registries.size() > 1) {
            //this is a subscription registry - only try this one
            System.out.println("subscription registries for domain " + domainName + " of index " + index + " = " + registries);
            return registries;
        }
        List list = new LinkedList();
        addOven(list, domainName);
        //for all domains
        for (String domain : DOMAIN_REGISTRIES.keySet()) {
            System.out.println("checking domain " + domain);
            if (domainName.endsWith(domain)) {
                List<ClientRegistry> alist = DOMAIN_REGISTRIES.get(domain);
                if (alist != null && alist.size() > 0) {
                    list.addAll(alist);
                }
            }
        }
        //default registries
        if (DEFAULT_REGISTRIES != null && !DEFAULT_REGISTRIES.isEmpty()) {
            list.addAll(DEFAULT_REGISTRIES);
        }
        return list;
    }
}
