/*
 * Martin Alexander Thomsen den 8 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.savedocument;

import static com.maikenwinterberg.filedomainjumper.FileReceiverThread.ZDT_FORMATTER;
import com.maikenwinterberg.filedomainjumper.documentprocess.FileProcessUtil;
import com.maikenwinterberg.filedomainjumper.documentprocess.InboxLog;
import com.maikenwinterberg.filedomainjumper.documentprocess.Mkdir;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.time.ZonedDateTime;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileDocumentSaver implements ISaveDocument {

    private int registrationId;
    private File tempFile;
    private File newFile;
    private BufferedOutputStream buf;

    @Override
    public synchronized boolean init(String clientDomainName, String registrationId, String path, String name, int sizeOfFile) throws Exception {
        this.registrationId = Integer.parseInt(registrationId);
        List<String> okList = new LinkedList();
        okList.add(clientDomainName);
        //TODO select node by using plugin
        newFile = FileProcessUtil.processInbox(path, Integer.parseInt(registrationId), okList, new File(name), "");
        if (newFile.exists() && newFile.length() >= sizeOfFile) {
            //do nothing the file is allready there
            System.out.println("Doing nothing file allready exists");
            return false;
        } else {
            //fix: climb over the wall with scripts
            if (!newFile.getParentFile().exists()) {
                boolean ok = Mkdir.mkdirs(newFile.getParentFile());
                System.out.println("crated directory: " + newFile.getParent() + " status: " + ok);
            }
            //@SEE doc/dieletter.pdf
            //@SEE doc/buildALanWithWallByDonald.pdf
            tempFile = new File(newFile.getAbsolutePath() + ".tmp");
            buf = new BufferedOutputStream(new FileOutputStream(tempFile));
            return true;
        }
    }

    @Override
    public synchronized void append(byte[] data) throws Exception {
        if (buf != null) {
            buf.write(data);
        }
    }

    @Override
    public synchronized void commit() {
        if (tempFile != null && newFile != null) {
            try {
                tempFile.renameTo(newFile);
                System.out.println("File received: File created in folder " + newFile.getAbsolutePath());
                String time = ZDT_FORMATTER.format(ZonedDateTime.now());
                try {
                    InboxLog.log(registrationId, time + ": File received at " + newFile.getCanonicalPath());
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                try {
                    buf.close();
                } catch (Exception ex) {
                    //ignore
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
