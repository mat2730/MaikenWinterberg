/*
 * Martin Alexander Thomsen den 8 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper;

import com.maikenwinterberg.filedomainjumper.documentiterator.DocumentIteratorFactory;
import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentIterator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import com.maikenwinterberg.filedomainjumper.documentprocess.ProcessDocument;
import com.maikenwinterberg.socketregistry.api.SocketRegistration;
import com.maikenwinterberg.filedomainjumper.documentprocess.IDocumentProcess;
import com.maikenwinterberg.socketregistry.api.BlockedSocketRegistration;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileSender {

    private static final boolean DEBUG = false;

    public static String getProperty(String name) {
        return LookupRegistries.PROPERTIES.getProperty(name);
    }

    public static void main(String arg[]) throws Exception {
        System.out.println("Starting the file sender");
        LookupRegistries.init();
        //start hfileeartbeat thread with subscription registry info
        new SubscriptionRegistryThread().start();
        while (true) {
            String defaultServiceName = LookupRegistries.PROPERTIES.getProperty("defaultServiceName");
            int index = 1;
            while (true) {
                Map registriesByDomain = new HashMap();
                try {
                    //init properties
                    String outbox = LookupRegistries.PROPERTIES.getProperty(index + ".outbox");
                    if (outbox == null) {
                        //end of config
                        break;
                    }
                    String serviceName = LookupRegistries.PROPERTIES.getProperty(index + ".serviceName");
                    if (serviceName == null || serviceName.trim().isEmpty()) {
                        serviceName = defaultServiceName;
                    }
                    String defaultDomainNameOfClient = LookupRegistries.PROPERTIES.getProperty("defaultDomainNameOfClient");
                    IDocumentIterator documentIterator = DocumentIteratorFactory.getIterator(registriesByDomain, defaultDomainNameOfClient, serviceName, index);
                    documentIterator.iterateDocuments();
                } catch (Exception ex) {
                } finally {
                    QueueHandler.executor.waitTillDone();
                    //close socket connections
                    for (Iterator<SocketRegistration> i = registriesByDomain.values().iterator(); i.hasNext();) {
                        SocketRegistration sr = i.next();
                        if (sr instanceof BlockedSocketRegistration) {
                            continue;
                        }
                        System.out.println("closing socket for " + sr.getIp() + ":" + sr.getPort());
                        sr.close();
                    }
                    if (!registriesByDomain.isEmpty()) {
                        //delete if processed something
                        if (DEBUG) {
                            System.out.println("doneWithBox");
                        }
                        ProcessDocument.processDocument(index, null, null, null, IDocumentProcess.DEST.doneWithBox);
                    }
                    index++;
                }
            }
            long fileSenderSleap = 10000;
            try {
                String fileSenderSleapAsString = FileSender.getProperty("fileSenderSleap");
                fileSenderSleap = Integer.parseInt(fileSenderSleapAsString);
            } catch (Exception ex) {
            }
            try {
                Thread.sleep(fileSenderSleap);
            } catch (Exception ex) {
                //ignore
            }
        }
    }
    /*
    private static void traverseTree(Map registriesByDomain, JumperTask initTask) throws Exception {
        File[] files = initTask.getFile().listFiles();
        for (File childFile : files) {
            try {
                if (childFile.isDirectory()) {
                    traverseTree(registriesByDomain, new JumperTask(initTask.getOutboxIndex(), initTask.getPath() + "/" + initTask.getFile().getName(), childFile, initTask.getDomainNameOfClient(), initTask.getServiceName()));
                } else if (childFile.exists() && childFile.isFile()) {
                    //TODO add task to a queue and have another thread read from the queue
                    QueueHandler.handleTaskInQueue(registriesByDomain, new JumperTask(initTask.getOutboxIndex(), initTask.getPath() + "/" + initTask.getFile().getName(), childFile, initTask.getDomainNameOfClient(), initTask.getServiceName()));
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }*/
}
