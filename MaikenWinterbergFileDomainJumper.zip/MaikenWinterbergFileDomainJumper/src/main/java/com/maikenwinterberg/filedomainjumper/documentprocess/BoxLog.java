/*
 * Martin Alexander Thomsen den 2 August 2024
 */
package com.maikenwinterberg.filedomainjumper.documentprocess;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class BoxLog {

    public static enum TYPE {
        INBOX, OUTBOX;
    }

    private final static Map<String, BufferedWriter> CACHE = new HashMap();

    private static BufferedWriter getWriter(TYPE type, int index) {
        try {
            BufferedWriter bw = CACHE.get(type.toString() + "." + index);
            if (bw != null) {
                return bw;
            }
            File file = null;
            if (type == TYPE.INBOX) {
                file = new File(FileProcessUtil.getInbox(index).getAbsolutePath() + "/inbox.log");
            } else {
                file = new File(FileProcessUtil.getOutbox(index).getParentFile().getAbsolutePath() + "/outbox.log");
            }
            FileWriter fw = new FileWriter(file, true);
            bw = new BufferedWriter(fw);
            CACHE.put(type.toString() + "." + index, bw);
            return bw;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    protected void finalize() throws Throwable {
        try {
            for (Iterator<BufferedWriter> i = CACHE.values().iterator(); i.hasNext();) {
                i.next().close();
            }
        } finally {
            super.finalize();
        }
    }

    public synchronized static void log(TYPE type, int index, String message) {
        try {
            BufferedWriter bw = getWriter(type, index);
            if (bw != null) {
                System.out.println(message);
                bw.write(message);
                bw.write("\n");
                bw.flush();
            } else {
                System.out.println("buffered writer to log not created");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
