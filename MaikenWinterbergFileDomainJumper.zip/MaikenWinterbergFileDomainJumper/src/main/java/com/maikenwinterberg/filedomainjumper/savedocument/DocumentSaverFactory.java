/*
 * Martin Alexander Thomsen den 8 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.savedocument;

import com.maikenwinterberg.filedomainjumper.FileReceiver;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class DocumentSaverFactory {

    private final static Map<String, ISaveDocument> CACHE = new HashMap();

    public static ISaveDocument getSaveDocument(String registrationId) {
        ISaveDocument saver = null;//CACHE.get(registrationId);
        if (saver != null) {
            return saver;
        }
        try {
            String saverClass = FileReceiver.getProperty(registrationId + ".filesaver");
            if (saverClass == null) {
                saverClass = FileReceiver.getProperty("filesaver");
            }
            saver = (ISaveDocument) Class.forName(saverClass).newInstance();
        } catch (Exception ex) {
            //ignore
        }
        if (saver == null) {
            saver = new FileDocumentSaver();
        }
        CACHE.put(registrationId, saver);
        return saver;
    }
}