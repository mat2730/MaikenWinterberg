/*
 * Martin Alexander Thomsen den 13 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper;

import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentNode;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import com.maikenwinterberg.filedomainjumper.documentprocess.ProcessDocument;
import com.maikenwinterberg.filedomainjumper.router.DocumentRouterFactory;
import com.maikenwinterberg.filedomainjumper.router.IDocumentRouter;
import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import com.maikenwinterberg.socketregistry.api.RegistryConnectionFactory;
import com.maikenwinterberg.socketregistry.api.SocketRegistration;
import com.maikenwinterberg.socketregistry.server.ICommand;
import java.net.InetAddress;
import java.util.HashMap;
import mtymes.javafixes.concurrency.Runner;
import com.maikenwinterberg.filedomainjumper.documentprocess.IDocumentProcess;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class QueueHandler implements Runnable {

    private static final boolean DEBUG = false;

    private static final Map FILESINPROGRESS = new HashMap();

    public static Runner executor = Runner.runner(10);

    private final Map<String, SocketRegistration> registriesByDomain;
    private final JumperTask task;

    static {
        int number = 10;
        try {
            String numberOfSendHandlerThreads = FileSender.getProperty("numberOfSendHandlerThreads");
            number = Integer.parseInt(numberOfSendHandlerThreads);
        } catch (Exception ex) {
            //ignore
        }
        executor = Runner.runner(number);
    }

    public QueueHandler(Map<String, SocketRegistration> registriesByDomain, JumperTask task) {
        this.registriesByDomain = registriesByDomain;
        this.task = task;
    }

    public synchronized static void handleTaskInQueue(Map<String, SocketRegistration> registriesByDomain, JumperTask task) throws Exception {
        if (FILESINPROGRESS.get(task.getDocumentNode().getId()) != null) {
            //allready in queue
            return;
        }
        FILESINPROGRESS.put(task.getDocumentNode().getId(), "");
        //@see https://stackoverflow.com/questions/3929361/how-to-wait-for-all-tasks-in-an-threadpoolexecutor-to-finish-without-shutting-do
        executor.run(new QueueHandler(registriesByDomain, task));
        /*
        executor.submit(() -> {
            //do not work
            new QueueHandler(registriesByDomain, task).run();
        });
         */
    }

    @Override
    public void run() {
        try {
            int outboxIndex = task.getOutboxIndex();
            String serviceName = task.getServiceName();
            IDocumentNode documentNode = task.getDocumentNode();
            if (DEBUG) {
                System.out.println("path of file " + documentNode.getName() + " path " + documentNode.getGroupName());
            }
            List<String> okDomains = new LinkedList();
            List<String> notOkDomains = new LinkedList();
            boolean domainsAreMissing = false;
            int numberOfFilesSent = 0;
            try {
                IDocumentRouter router = DocumentRouterFactory.getRouter(outboxIndex, documentNode);
                if (router == null) {
                    System.out.println("router not configureded of index " + outboxIndex);
                    ProcessDocument.processDocument(outboxIndex, okDomains, notOkDomains, documentNode, IDocumentProcess.DEST.outBox);
                    return;
                }
                //for all receiver domainnames
                List<String> receiverDomainNames = router.getDomainNamesOfRecievers(outboxIndex, documentNode);
                okDomains.clear();
                notOkDomains.clear();
                //remove invalid domains
                for (String domainName : receiverDomainNames) {
                    if (domainName.toLowerCase().contains("documentnetwork.com") || domainName.toLowerCase().contains("maikenwinterberg.com")) {
                        continue;
                    }
                    InetAddress inetAddress = null;
                    try {
                        inetAddress = InetAddress.getByName(domainName);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    String hostAddress = inetAddress.getHostAddress();
                    if (hostAddress == null) {
                        System.out.println("invalid host " + domainName);
                        receiverDomainNames.remove(domainName);
                    }
                }
                if (receiverDomainNames.isEmpty()) {
                    domainsAreMissing = true;
                }
                for (String receiverDomainName : receiverDomainNames) {
                    try {
                        if (DEBUG) {
                            System.out.println("file processer " + ProcessDocument.newInstance(outboxIndex, IDocumentProcess.DEST.outBox) + " of file " + documentNode + " to domain " + receiverDomainName);
                        }
                        if (!ProcessDocument.doProcessDocument(outboxIndex, receiverDomainName, documentNode)) {
                            if (DEBUG) {
                                System.out.println("File transfere of file " + documentNode.getId() + " to domain " + receiverDomainName + " is cancelled");
                            }
                            continue;
                        }
                        synchronized (QueueHandler.class) {
                            SocketRegistration socketRegistration = (SocketRegistration) registriesByDomain.get(receiverDomainName);
                            if (socketRegistration == null) {
                                //System.out.println("looking up connection propperties in registry " + lookupRegistries + " of domain " + receiverDomainName);
                                List<ClientRegistry> lookupRegistries = LookupRegistries.getLookupRegistries(task.getOutboxIndex(), receiverDomainName);
                                System.out.println("lookup registries " + lookupRegistries);
                                socketRegistration = RegistryConnectionFactory.getFirstValidSocketRegistration(lookupRegistries, task.getDomainNameOfClient(), receiverDomainName, serviceName);
                                if (socketRegistration != null) {
                                    registriesByDomain.put(receiverDomainName, socketRegistration);
                                } else {
                                    System.out.println("cannot establish a socket connection to " + receiverDomainName);
                                }
                            } else {
                                //socketRegistration.resetSocket();
                            }
                            if (socketRegistration == null) {
                                notOkDomains.add(receiverDomainName);
                                System.out.println("cannot establis a socket connection to " + receiverDomainName + ". a succesfully installed FileDomainJumper on domain is needed.");
                                continue;
                            }
                            String messageFromServer = SendDocument.send(socketRegistration, documentNode);
                            if (messageFromServer == null) {
                                registriesByDomain.remove(receiverDomainName);
                                notOkDomains.add(receiverDomainName);
                            }
                            else if (messageFromServer != null && messageFromServer.contains("status" + ICommand.EQUAL_SEPERATOR + "ok")) {
                                numberOfFilesSent++;
                                okDomains.add(receiverDomainName);
                            } else {
                                notOkDomains.add(receiverDomainName);
                                System.out.println("error from fileserver " + messageFromServer + " of domain " + receiverDomainName);
                            }
                        }
                    } catch (Throwable ex) {
                        ex.printStackTrace();
                        notOkDomains.add(receiverDomainName);
                    } finally {
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            if (domainsAreMissing || !okDomains.isEmpty() || !notOkDomains.isEmpty()) {
                ProcessDocument.processDocument(outboxIndex, okDomains, notOkDomains, documentNode, IDocumentProcess.DEST.outBox);
            }
        } catch (Exception exe) {
            exe.printStackTrace();
        } finally {
            FILESINPROGRESS.remove(task.getDocumentNode().getId());
        }
    }

}
