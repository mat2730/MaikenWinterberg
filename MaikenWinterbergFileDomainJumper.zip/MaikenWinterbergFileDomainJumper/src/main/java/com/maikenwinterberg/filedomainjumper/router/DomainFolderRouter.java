/*
 * Martin Alexander Thomsen den 17 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.router;

import com.maikenwinterberg.filedomainjumper.documentiterator.FileDocumentNode;
import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentNode;
import java.io.File;
import java.net.InetAddress;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class DomainFolderRouter implements IDocumentRouter {

    @Override
    public List<String> getDomainNamesOfRecievers(int index, IDocumentNode documentNode) {
        List<String> l = new LinkedList();
        addParent(l, documentNode);
        return l;
    }

    private void addParent(List<String> domains, IDocumentNode documentNode) {
        File f = null;
        if (documentNode instanceof FileDocumentNode) {
            f = ((FileDocumentNode) documentNode).getFile();
        }
        if (f == null) {
            return;
        }
        File parentFile = f.getParentFile();
        if (parentFile == null) {
            return;
        }
        String domainName = parentFile.getName();
        InetAddress inetAddress = null;
        try {
            if (domainName.toLowerCase().contains("documentnetwork.com") || domainName.toLowerCase().contains("maikenwinterberg.com")) {
                domains.add(domainName);
            } else {
                inetAddress = InetAddress.getByName(domainName);
                if (inetAddress != null) {
                    String hostAddress = inetAddress.getHostAddress();
                    if (hostAddress != null) {
                        domains.add(domainName);
                    }
                    //System.out.println("inetAddress " + inetAddress + " of domain " + domainName);
                }
            }
        } catch (Exception ex) {
            //ignore
        }
        addParent(domains, new FileDocumentNode(null,parentFile));
    }
}
