/*
 * Martin Alexander Thomsen den 31 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.router;

import com.maikenwinterberg.filedomainjumper.FileSender;
import com.maikenwinterberg.documentiterator.FileDocumentNode;
import com.maikenwinterberg.documentiterator.IDocumentNode;
import com.maikenwinterberg.domainname.DomainHandler;
import com.maikenwinterberg.filedomainjumper.documentprocess.ReloadableProperty;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * @see doc/tagrouter.pdf
 * @see https://www.baeldung.com/java-pdf-file-read
 */
public class TagRouter implements IDocumentRouter {

    private static final Map<Integer, ReloadableProperty> PROPERTY_MAP = new HashMap();
    private static final boolean DEBUG = false;

    private String getProperty(int index, String name) {
        try {
            ReloadableProperty reloadProp = PROPERTY_MAP.get(index);
            if (reloadProp == null) {
                String Tag2DomainFile = FileSender.getProperty(index + ".tag2domainpath");
                if (Tag2DomainFile == null || Tag2DomainFile.trim().isEmpty()) {
                    reloadProp = PROPERTY_MAP.get(0);
                    if (reloadProp == null) {
                        Tag2DomainFile = FileSender.getProperty("tag2domainpath");
                        File propertyFile = new File(Tag2DomainFile);
                        reloadProp = new ReloadableProperty(propertyFile);
                        PROPERTY_MAP.put(0, reloadProp);
                        return reloadProp.getProperty(name);
                    }
                }
                if (Tag2DomainFile == null) {
                    //System.out.println("attribute tag2domainpath is not configurated");
                    return null;
                }
                if (reloadProp == null) {
                    File propertyFile = new File(Tag2DomainFile);
                    reloadProp = new ReloadableProperty(propertyFile);
                    PROPERTY_MAP.put(index, reloadProp);
                    return reloadProp.getProperty(name);
                }
            } else {
                return reloadProp.getProperty(name);
            }
        } catch (Exception ex) {
            //ignore
        }
        return null;
    }

    private String getDomainName(int index, String domainName) {
        try {
            String newDomainName = getProperty(index, domainName);
            if (newDomainName != null && !newDomainName.trim().isEmpty()) {
                domainName = newDomainName;
            }
            int sIndex = domainName.indexOf("@");
            if (sIndex != -1) {
                //its an email - turn into domainname
                domainName = domainName.substring(sIndex + 1);
            }
            if (domainName.toLowerCase().contains("documentnetwork.com") || domainName.toLowerCase().contains("maikenwinterberg.com")) {
                return domainName;
            } else {
                String hostAddress = DomainHandler.getHostAddress(domainName);
                if (hostAddress != null) {
                    return domainName;
                }
            }
        } catch (Exception ex) {
            //ex.printStackTrace();
        }
        return null;
    }

    @Override
    public List<String> getDomainNamesOfRecievers(int index, IDocumentNode documentNode) {
        List<String> list = new LinkedList();
        try {
            if (documentNode.getName().toLowerCase().endsWith(".pdf")) {
                return getDomainNamesOfRecieversPDFVersion(index, documentNode);
            }
            //FileReader fr = new FileReader(file);
            ByteArrayInputStream bais = new ByteArrayInputStream(documentNode.getBytes());
            BufferedReader br = new BufferedReader(new InputStreamReader(bais));
            String part = br.readLine();
            while (part != null) {
                int hashIndex = part.indexOf("#");
                while (hashIndex != -1) {
                    String domainName = null;
                    int spaceIndex = part.indexOf(" ");
                    if (spaceIndex != -1) {
                        if (spaceIndex > hashIndex + 1) {
                            domainName = part.substring(hashIndex + 1, spaceIndex);
                        }
                        part = part.substring(spaceIndex).trim();
                    } else {
                        domainName = part.substring(1);
                    }
                    domainName = getDomainName(index, domainName);
                    if (domainName != null) {
                        list.add(domainName);
                    }
                    if (spaceIndex == -1) {
                        break;
                    }
                    hashIndex = part.indexOf("#");
                }
                part = br.readLine();
            }
        } catch (Exception ex) {
            //ex.printStackTrace();
        }
        return list;
    }

    public List<String> getDomainNamesOfRecieversPDFVersion(int index, IDocumentNode file) {
        List list = new LinkedList();
        try {
            PDDocument document = PDDocument.load(file.getBytes());
            PDFTextStripper stripper = new PDFTextStripper();
            String txt = stripper.getText(document);
            System.out.println("pdf text " +txt);
            document.close();
            StringTokenizer tok = new StringTokenizer(txt, "\n");
            while (tok.hasMoreTokens()) {
                String part = tok.nextToken();
                int hashIndex = part.indexOf("#");
                while (hashIndex != -1) {
                    String domainName = null;
                    int spaceIndex = part.indexOf(" ");
                    if (spaceIndex != -1) {
                        if (spaceIndex > hashIndex + 1) {
                            domainName = part.substring(hashIndex + 1, spaceIndex);
                        }
                        part = part.substring(spaceIndex).trim();
                    } else {
                        domainName = part.substring(1);
                    }
                    domainName = getDomainName(index, domainName);
                    if (domainName != null) {
                        list.add(domainName);
                    }
                    if (spaceIndex == -1) {
                        break;
                    }
                    hashIndex = part.indexOf("#");
                }
            }
        } catch (Throwable ex) {
            ex.printStackTrace();
        }
        return list;
    }

    public List<String> getDomainNamesOfRecieversDontWork1(int index, File file) {
        List<String> list = new LinkedList();
        try {
            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
            byte[] data;
            int i = 0;
            int size = 1000;
            int available = bis.available();
            while (true) {
                int count = Math.min(size, available);
                data = new byte[count];
                System.out.println("data " + i + " " + data.length + " " + available);
                bis.read(data, i, data.length);
                available -= size;
                String part = new String(data, "utf-8");
                if (part.trim().length() == 0) {
                    break;
                }
                int hashIndex = part.indexOf("#");
                while (hashIndex != -1) {
                    count = Math.min(size, available);
                    data = new byte[count];
                    bis.read(data, i, data.length);
                    available -= size;
                    if (hashIndex + 20 > part.length()) {
                        //read more
                        i += size;
                        bis.read(data, i, Math.min(size, available));
                        String more = new String(data, "utf-8").trim();
                        part = part + more;
                    }
                    int spaceIndex = part.indexOf(" ");
                    String domainName = part.substring(hashIndex, spaceIndex);
                    domainName = getDomainName(index, domainName);
                    if (domainName != null) {
                        list.add(domainName);
                    }
                    hashIndex = part.indexOf("#");
                }
                //read more
                i += size;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return list;
    }

    public List<String> getDomainNamesOfRecieversDontWork2(int index, File file) {
        List<String> list = new LinkedList();
        try {
            FileReader bis = new FileReader(file);
            char[] data;
            int i = 0;
            int size = 1000;
            int available = (int) file.length();
            while (true) {
                int count = Math.min(size, available);
                data = new char[count];
                System.out.println("data " + i + " " + data.length + " " + available);
                bis.read(data, i, data.length);
                available -= size;
                String part = new String(data);
                if (part.trim().length() == 0) {
                    break;
                }
                int hashIndex = part.indexOf("#");
                while (hashIndex != -1) {
                    count = Math.min(size, available);
                    data = new char[count];
                    bis.read(data, i, data.length);
                    available -= size;
                    if (hashIndex + 20 > part.length()) {
                        //read more
                        i += size;
                        bis.read(data, i, Math.min(size, available));
                        String more = new String(data).trim();
                        part = part + more;
                    }
                    int spaceIndex = part.indexOf(" ");
                    String domainName = part.substring(hashIndex, spaceIndex);
                    domainName = getDomainName(index, domainName);
                    if (domainName != null) {
                        list.add(domainName);
                    }
                    hashIndex = part.indexOf("#");
                }
                //read more
                i += size;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return list;
    }

    //test
    public static void main(String arg[]) throws Exception {
        System.out.println(new TagRouter().getDomainNamesOfRecievers(1, new FileDocumentNode("", new File("license.txt"))));
        System.out.println(new TagRouter().getDomainNamesOfRecievers(1, new FileDocumentNode("", new File("tagRouterTest.pdf"))));
        //System.out.println(new TagRouter().getDomainNamesOfRecievers(1, new File("theBigOne.pdf")));
    }
}
