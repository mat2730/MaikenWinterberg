/*
 * Martin Alexander Thomsen den 22 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.router;

import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentNode;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class DocumentWrapperRouter implements IDocumentRouter {

    @Override
    public List<String> getDomainNamesOfRecievers(int index, IDocumentNode documentNode) {
        List<String> documents = null;
        try {
            documents = new DomainFolderRouter().getDomainNamesOfRecievers(index, documentNode);
        } catch (Exception ex) {
            //ignore
        }
        if (documentNode.getName().toLowerCase().endsWith(".xml")) {
            if (documents == null || documents.isEmpty()) {
                try {
                    documents = new XPathDocumentRouter().getDomainNamesOfRecievers(index, documentNode);
                } catch (Exception ex) {

                }
            }
            if (documents == null || documents.isEmpty()) {
                try {
                    documents = new PropertyByXPathDocumentRouter().getDomainNamesOfRecievers(index, documentNode);
                } catch (Exception ex) {
                }
            }
        }
        if (documents == null || documents.isEmpty()) {
            try {
                documents = new TagRouter().getDomainNamesOfRecievers(index, documentNode);
            } catch (Exception ex) {
            }
        }
        return documents;
    }
}