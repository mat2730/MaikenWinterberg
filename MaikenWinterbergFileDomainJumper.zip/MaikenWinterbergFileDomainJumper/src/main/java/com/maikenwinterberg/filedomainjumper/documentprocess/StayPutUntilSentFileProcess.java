/*
 * Martin Alexander Thomsen den 21 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.documentprocess;

import com.maikenwinterberg.filedomainjumper.documentiterator.FileDocumentNode;
import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentNode;
import com.maikenwinterberg.filedomainjumper.documentprocess.FileProcessUtil;
import com.maikenwinterberg.filedomainjumper.documentprocess.IDocumentProcess;
import static com.maikenwinterberg.filedomainjumper.documentprocess.IDocumentProcess.DEST.doneWithBox;
import java.io.File;
import java.util.List;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 * @see doc/stayPutUntilSent.pdf
 *
 */
public class StayPutUntilSentFileProcess implements IDocumentProcess {

    private static final Map<String, Long> WAIT_FILE = new HashMap();
    private static final long WAIT_TIME = (1000 * 60 * 3);//3 minutes  // (1000 * 60 * 60 * 3); // 3 hours
    private static final boolean DEBUG = true;

    @Override
    public IDocumentNode processDocument(int configurationIndex, List<String> okDomains, List<String> notOkDomains, IDocumentNode documentNode, IDocumentProcess.DEST destination) throws Exception {
        if (destination == doneWithBox) {
            String outboxFolder = FileProcessUtil.getOutbox(configurationIndex).getAbsolutePath();
            System.out.println("deleting outbox " + outboxFolder + " of index " + configurationIndex);
            File directory = new File(outboxFolder);
            for (File childFile : directory.listFiles()) {
                if (childFile.isDirectory()) {
                    //dont delete first level
                    FileProcessUtil.deleteEmptyDir(childFile.getName(), childFile);
                }
            }
            return null;
        }
        FileDocumentNode fdn = (FileDocumentNode) documentNode;
        File file = fdn.getFile();
        String path = FileProcessUtil.getPath(documentNode.getGroupName());
        if (okDomains != null) {
            Map map = new HashMap();
            for (String domain : okDomains) {
                map.put(domain, domain);
            }
            okDomains = new LinkedList(map.values());
        }
        if (notOkDomains != null) {
            Map map = new HashMap();
            for (String domain : notOkDomains) {
                map.put(domain, domain);
            }
            notOkDomains = new LinkedList(map.values());
        }
        if (null != destination) {
            switch (destination) {
                case outBox -> {
                    //init config
                    if (DEBUG) {
                        System.out.println("StayPutUntilSentFileProcess.proccessing file in outbox " + file.getCanonicalPath() + " of path " + path);
                    }

                    String sentFolder = FileProcessUtil.getSentBox(configurationIndex).getAbsolutePath();
                    String outboxFolder = FileProcessUtil.getOutbox(configurationIndex).getAbsolutePath();
                    if (DEBUG) {
                        System.out.println("StayPutUntilSentFileProcess.outbox: " + outboxFolder);
                    }
                    //if no domains found
                    if ((okDomains == null || okDomains.isEmpty()) && (notOkDomains == null || notOkDomains.isEmpty())) {
                        WAIT_FILE.remove(file.getAbsolutePath());
                        File newFile = FileProcessUtil.processDomainNotFound(configurationIndex, path, file);
                        WAIT_FILE.put(newFile.getAbsolutePath(), System.currentTimeMillis());
                        return null;
                    }
                    //for each domains not ok
                    File firstFile = null;
                    if (notOkDomains != null) {
                        for (String domainName : notOkDomains) {
                            String newPath = FileProcessUtil.removeFirstPartIfEqual(domainName, path);
                            new File(outboxFolder + "/" + domainName + newPath).mkdirs();
                            if (firstFile == null) {
                                WAIT_FILE.remove(file.getAbsolutePath());
                                firstFile = new File(outboxFolder + "/" + domainName + newPath + "/" + FileProcessUtil.addIndex(file.getName()));
                                //TODO only rename first call then copy
                                file.renameTo(firstFile);
                                if (DEBUG) {
                                    System.out.println("StayPutUntilSentFileProcess.File Error: File moved to " + firstFile.getAbsolutePath());
                                }
                                WAIT_FILE.put(firstFile.getAbsolutePath(), System.currentTimeMillis());
                            } else {
                                WAIT_FILE.remove(file.getAbsolutePath());
                                File newFile = new File(outboxFolder + "/" + domainName + newPath + "/" + FileProcessUtil.addIndex(file.getName()));
                                boolean ok = FileProcessUtil.copyFile(firstFile, newFile);
                                if (DEBUG) {
                                    System.out.println("StayPutUntilSentFileProcess.File Error: File copied to " + newFile.getAbsolutePath() + ", status=" + ok);
                                }
                                WAIT_FILE.put(newFile.getAbsolutePath(), System.currentTimeMillis());
                            }
                        }
                    }
                    //ok domains
                    if (okDomains != null) {
                        WAIT_FILE.remove(file.getAbsolutePath());
                        processSentTemp(okDomains, path, sentFolder, firstFile, file);
                    }
                    return null;
                }
                case doneWithBox -> {
                    String outboxFolder = FileProcessUtil.getOutbox(configurationIndex).getAbsolutePath();
                    System.out.println("deleting outbox " + outboxFolder + " of index " + configurationIndex);
                    File directory = new File(outboxFolder);
                    for (File childFile : directory.listFiles()) {
                        if (childFile.isDirectory()) {
                            //dont delete first level
                            FileProcessUtil.deleteEmptyDir(childFile.getName(), childFile);
                        }
                    }
                    return null;
                }
                default -> {
                }
            }
        }
        throw new IllegalStateException("folder of file is missing in config");
    }

    protected File processSentTemp(List<String> okDomains, String path, String sentFolder, File firstFile, File file) {
        return processSent(okDomains, path, sentFolder, firstFile, file);
    }

    protected File processSent(List<String> okDomains, String path, String sentFolder, File firstFile, File file) {
        for (String domainName : okDomains) {
            path = FileProcessUtil.removeFirstPartIfEqual(domainName, path);
            new File(sentFolder + "/" + domainName + path).mkdirs();
            if (firstFile == null) {
                firstFile = new File(sentFolder + "/" + domainName + path + "/" + getDateString() + "_" + FileProcessUtil.removeIndex(file.getName()));
                file.renameTo(firstFile);
                if (DEBUG) {
                    System.out.println("StayPutUntilSentFileProcess.File sent: file moved to " + firstFile.getAbsolutePath());
                }
            } else {
                File newFile = new File(sentFolder + "/" + domainName + path + "/" + getDateString() + "_" + FileProcessUtil.removeIndex(file.getName()));
                boolean ok = FileProcessUtil.copyFile(firstFile, newFile);
                if (DEBUG) {
                    System.out.println("StayPutUntilSentFileProcess.File sent: file copied to " + newFile.getAbsolutePath() + ", status=" + ok);
                }
            }
        }
        return firstFile;
    }

    protected String getDateString() {
        return "";
    }

    @Override
    public boolean doProcessDocument(int configurationIndex, String receiverDomainName, IDocumentNode documentNode) throws Exception {
        FileDocumentNode fdn = (FileDocumentNode) documentNode;
        File file = fdn.getFile();
        //@SEE https://www.youtube.com/watch?v=HJF2rtcY08A
        Long time = WAIT_FILE.get(file.getAbsolutePath());
        if (time != null) {
            if (System.currentTimeMillis() - time > WAIT_TIME) {
                WAIT_FILE.remove(file.getAbsolutePath());
                return true;
            }
            return false;
        }
        return true;
    }
}
