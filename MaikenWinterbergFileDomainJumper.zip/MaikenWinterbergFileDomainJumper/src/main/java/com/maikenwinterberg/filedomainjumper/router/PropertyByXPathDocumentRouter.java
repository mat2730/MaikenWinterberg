/*
 * Martin Alexander Thomsen den 10 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.router;

import java.io.File;
import java.io.FileInputStream;
import java.util.LinkedList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import com.maikenwinterberg.filedomainjumper.FileSender;
import com.maikenwinterberg.documentiterator.IDocumentNode;
import com.maikenwinterberg.filedomainjumper.documentprocess.ReloadableProperty;
import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class PropertyByXPathDocumentRouter implements IDocumentRouter {

    private static final Map<Integer, ReloadableProperty> PROPERTY_MAP = new HashMap();

    private String getProperty(int index, String name) {
        try {
            ReloadableProperty reloadProp = PROPERTY_MAP.get(index);
            if (reloadProp == null) {
                String Tag2DomainFile = FileSender.getProperty(index + ".xpathvalue2domainpropertyFileName");
                if (Tag2DomainFile == null || Tag2DomainFile.trim().isEmpty()) {
                    reloadProp = PROPERTY_MAP.get(0);
                    if (reloadProp == null) {
                        Tag2DomainFile = FileSender.getProperty("xpathvalue2domainpropertyFileName");
                        File propertyFile = new File(Tag2DomainFile);
                        reloadProp = new ReloadableProperty(propertyFile);
                        PROPERTY_MAP.put(0, reloadProp);
                        return reloadProp.getProperty(name);
                    }
                }
                if (Tag2DomainFile == null) {
                    System.out.println("attribute tag2domainpath is not configurated");
                    return null;
                }
                if (reloadProp == null) {
                    File propertyFile = new File(Tag2DomainFile);
                    reloadProp = new ReloadableProperty(propertyFile);
                    PROPERTY_MAP.put(index, reloadProp);
                    return reloadProp.getProperty(name);
                }
            } else {
                return reloadProp.getProperty(name);
            }
        } catch (Exception ex) {
            //ignore
        }
        return null;
    }

    @Override
    public List<String> getDomainNamesOfRecievers(int index, IDocumentNode documentNode) {
        List<String> domains = new LinkedList();
        int xpathIndex = 1;
        /*
        Properties properties = PROPERTIES.get(index);
        if (properties == null) {
            properties = new Properties();
            try {
                String propertyName = ClientFileDomainJumper.getProperty(index + ".xpathvalue2domainpropertyFileName");
                if (propertyName == null) {
                    propertyName = ClientFileDomainJumper.getProperty("xpathvalue2domainpropertyFileName");
                }
                properties.load(new FileInputStream(propertyName));
                PROPERTIES.put(index, properties);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }*/
        while (true) {
            String xpathConfig = FileSender.getProperty(index + ".keyxpath." + xpathIndex++);
            if (xpathConfig == null || xpathConfig.trim().isEmpty()) {
                break;
            }
            System.out.println("looking up xpath " + xpathConfig);
            try {
                //FileInputStream fileIS = new FileInputStream(file);
                ByteArrayInputStream bais = new ByteArrayInputStream(documentNode.getBytes());
                DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = builderFactory.newDocumentBuilder();
                Document xmlDocument = builder.parse(bais);
                XPath xPath = XPathFactory.newInstance().newXPath();
                NodeList nodeList = (NodeList) xPath.compile(xpathConfig).evaluate(xmlDocument, XPathConstants.NODESET);
                System.out.println("nodeList: " + nodeList.getLength());
                String propertyKey = null;
                for (int i = 0; i < nodeList.getLength(); i++) {
                    try {
                        Node n = nodeList.item(i);
                        //domainName = n.getNodeValue();
                        propertyKey = n.getTextContent();
                        if (propertyKey == null || propertyKey.trim().isEmpty()) {
                            propertyKey = n.getNodeValue();
                        }
                        if (propertyKey == null || propertyKey.trim().isEmpty()) {
                            continue;
                        }
                        System.out.println("propertyKey " + propertyKey);
                        String domainName = getProperty(index, propertyKey);
                        if (domainName != null) {
                            domains.add(domainName);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        System.out.println("found " + propertyKey + " at xpath: " + xpathConfig + ", exception: " + ex.getMessage());
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                System.out.println("found nothing at xpath: " + xpathConfig + ", exception: " + ex.getMessage());
            }
            if (domains.size() > 0) {
                return domains;
            }
        }
        return domains;
    }
}
