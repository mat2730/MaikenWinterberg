/*
 * Martin Alexander Thomsen den 13 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper;

import com.maikenwinterberg.documentiterator.IDocumentNode;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class JumperTask {

    private final int outboxIndex;
    private final IDocumentNode documentNode;
    private final String domainNameOfClient; //used for verification 
    private final String serviceName;

    public JumperTask(int outboxIndex, IDocumentNode documentNode, String domainNameOfClient, String serviceName) {
        this.documentNode = documentNode;
        this.domainNameOfClient = domainNameOfClient;
        //this.outboxFile = outboxFile;
        this.serviceName = serviceName;
        this.outboxIndex = outboxIndex;
    }

    public String getDomainNameOfClient() {
        return this.domainNameOfClient;
    }

    public int getOutboxIndex() {
        return this.outboxIndex;
    }
/*
    public String getPath() {
        if (path == null || path.trim().isEmpty()) {
            return ".";
        }
        return path;
    }
*/
    public IDocumentNode getDocumentNode() {
        return documentNode;
    }

    public String getServiceName() {
        return serviceName;
    }

}
