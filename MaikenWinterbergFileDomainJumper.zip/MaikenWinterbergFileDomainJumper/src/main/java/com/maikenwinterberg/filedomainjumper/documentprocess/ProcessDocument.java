/*
 * Martin Alexander Thomsen den 10 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.documentprocess;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.maikenwinterberg.filedomainjumper.FileSender;
import com.maikenwinterberg.filedomainjumper.FileReceiver;
import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentNode;
import static com.maikenwinterberg.filedomainjumper.documentprocess.IDocumentProcess.DEST.outBox;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class ProcessDocument {

    private final static IDocumentProcess DEFAULT_FILE_PROCESSER = new StayPutUntilSentFileProcess();
    private final static Map<Integer, IDocumentProcess> DOCUMENT_PROCESSERS = new HashMap();

    public static IDocumentNode processDocument(int configurationIndex, List<String> okDomains, List<String> notOkDomains, IDocumentNode fileFromInbox, IDocumentProcess.DEST destination) throws Exception {
        return newInstance(configurationIndex, destination).processDocument(configurationIndex, okDomains, notOkDomains, fileFromInbox, destination);
    }

    public static boolean doProcessDocument(int configurationIndex, String receiverDomainName, IDocumentNode file) throws Exception {
        //this method is only called from outbox
        return newInstance(configurationIndex, IDocumentProcess.DEST.outBox).doProcessDocument(configurationIndex, receiverDomainName, file);
    }

    public static IDocumentProcess newInstance(int configurationIndex, IDocumentProcess.DEST destination) throws Exception {
        IDocumentProcess p = DOCUMENT_PROCESSERS.get(configurationIndex);
        if (p != null) {
            return p;
        }
        //inti className
        String className = null;
        if (null != destination) {
            switch (destination) {
                case doneWithBox -> {

                }
                case outBox -> {
                    String defaultDocumentProcesser = FileSender.getProperty("defaultDocumentProcessor");
                    className = FileSender.getProperty(configurationIndex + ".documentProcessor");
                    if (className == null || className.trim().isEmpty()) {
                        className = defaultDocumentProcesser;
                    }
                    break;
                }
            }
        }
        //process class
        if (className != null && !className.trim().isEmpty()) {
            try {
                p = (IDocumentProcess) Class.forName(className).newInstance();
                DOCUMENT_PROCESSERS.put(configurationIndex, p);
                return p;
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        //default
        return DEFAULT_FILE_PROCESSER;
    }
}
