/*
 * Martin Alexander Thomsen den 10 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.documentprocess;

import com.maikenwinterberg.filedomainjumper.FileSender;
import com.maikenwinterberg.documentiterator.FileDocumentNode;
import com.maikenwinterberg.documentiterator.IDocumentNode;
import java.io.File;
import java.util.List;
import com.maikenwinterberg.fileregistry.PersistenceFactory;
import java.util.Iterator;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class SynchronizedFileProcess implements IDocumentProcess {

    @Override
    public IDocumentNode processDocument(int configurationIndex, List<String> okDomains, List<String> notOkDomains, IDocumentNode documentNode, IDocumentProcess.DEST destination) throws Exception {
        if (destination == DEST.doneWithBox) {

        }
        FileDocumentNode fdn = (FileDocumentNode) documentNode;
        File file = fdn.getFile();
        String path = FileProcessUtil.getPath(documentNode.getGroupName());
        if (null != destination) {
            if (destination.equals(DEST.outBox)) {
                //if no domains found
                if ((okDomains == null || okDomains.isEmpty()) && (notOkDomains == null || notOkDomains.isEmpty())) {
                    FileProcessUtil.processDomainNotFound(configurationIndex, path, file);
                    return null;
                }
                //for all okDomains
                //register file
                for (Iterator<String> i = okDomains.iterator(); i.hasNext();) {
                    PersistenceFactory.getFileRegistryDB(
                            null,
                            FileSender.getProperty("driver"),
                            FileSender.getProperty("url"),
                            FileSender.getProperty("username"),
                            FileSender.getProperty("password")
                    ).registerFile(i.next(), true, file);
                }
                return null;
            }

        }
        throw new IllegalStateException("folder of file is missing in config");
    }

    @Override
    public boolean doProcessDocument(int configurationIndex, String receiverDomainName, IDocumentNode documentNode) throws Exception {
        FileDocumentNode fdn = (FileDocumentNode) documentNode;
        File file = fdn.getFile();
        return (PersistenceFactory.getFileRegistryDB(
                null,
                FileSender.getProperty("driver"),
                FileSender.getProperty("url"),
                FileSender.getProperty("username"),
                FileSender.getProperty("password")
        ).isRegistrated(receiverDomainName, file) != null);
    }
}
