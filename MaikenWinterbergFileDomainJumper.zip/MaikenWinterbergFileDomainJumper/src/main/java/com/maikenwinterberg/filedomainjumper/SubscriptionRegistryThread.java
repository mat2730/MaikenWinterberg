/*
 * Martin Alexander Thomsen den 3 August 2024
 */
package com.maikenwinterberg.filedomainjumper;

import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import com.maikenwinterberg.socketregistry.persistence.jdbc.RegistryJDBCDB;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class SubscriptionRegistryThread extends Thread {

    @Override
    public void run() {
        while (true) {
            int index = 1;
            String domainNameOfclient = FileReceiver.getProperty("defaultDomainNameOfClient");
            String useExternalIDString = FileReceiver.getProperty("useExternalID");
            boolean useExternalID = false;
            try {
                useExternalID = Boolean.parseBoolean(useExternalIDString);
            } catch (Exception ex) {
            }
            while (true) {
                String outbox = FileReceiver.getProperty(index + ".outbox");
                if (outbox == null) {
                    break;
                }
                String subscriptionRegistries = FileReceiver.getProperty(index + ".subscriptionregistries");
                String serviceName = FileReceiver.getProperty(index + ".serviceName");
                if (subscriptionRegistries != null) {
                    StringTokenizer tok = new StringTokenizer(subscriptionRegistries, ";");
                    while (tok.hasMoreTokens()) {
                        try {
                            StringTokenizer tok2 = new StringTokenizer(tok.nextToken(), ":");
                            String ip = tok2.nextToken();
                            String port;
                            try {
                                port = "" + Integer.parseInt(tok2.nextToken());
                            } catch (Exception ex) {
                                port = "4554";
                            }
                            ClientRegistry cr = ClientRegistry.getRegistryInstance(domainNameOfclient, ip, Integer.parseInt(port), useExternalID, false);
                            cr.registerSubscription(domainNameOfclient, serviceName, ""+index, ip, port);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                }
                index++;
            }
            try {
                Thread.sleep(RegistryJDBCDB.HEARTBEAT_TIME);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
