/*
 * Martin Alexander Thomsen den 10 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.documentprocess;

import com.maikenwinterberg.documentiterator.IDocumentNode;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IDocumentProcess {

    public static enum DEST {
        outBox, doneWithBox;
    }

    //delete a file or move it into the sentBox, errorBox or inBox
    public IDocumentNode processDocument(int configurationIndex, List<String> okDomains, List<String> notOkDomains, IDocumentNode fileFromInbox, DEST destination) throws Exception;

    public boolean doProcessDocument(int configurationIndex, String receiverDomainName, IDocumentNode file) throws Exception;
}
