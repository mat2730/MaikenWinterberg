/*
 * Martin Alexander Thomsen den 28 August 2024
 */
package com.maikenwinterberg.filedomainjumper.documentiterator;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class TouchNode {

    private Map attributes = new HashMap();

    public void addAttribute(String name, Object value) {
        attributes.put(name, value);
    }

    public Object getValue(String name) {
        return attributes.get(name);
    }
}
