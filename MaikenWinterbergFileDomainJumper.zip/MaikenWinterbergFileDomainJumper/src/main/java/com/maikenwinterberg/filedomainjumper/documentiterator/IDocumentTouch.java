/*
 * Martin Alexander Thomsen den 8 August 2024
 */
package com.maikenwinterberg.filedomainjumper.documentiterator;

import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IDocumentTouch {

    public void touch(Map registriesByDomain, String domainNameOfClient, String serviceName, int configIndex, IDocumentNode documentNode) throws Exception;
}
