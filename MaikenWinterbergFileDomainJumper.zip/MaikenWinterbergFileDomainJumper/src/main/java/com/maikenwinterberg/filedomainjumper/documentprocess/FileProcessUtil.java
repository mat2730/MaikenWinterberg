/*
 * Martin Alexander Thomsen den 22 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.documentprocess;

import com.maikenwinterberg.filedomainjumper.FileSender;
import com.maikenwinterberg.filedomainjumper.FileReceiver;
import com.maikenwinterberg.socketregistry.server.ICommand;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import javax.swing.filechooser.FileSystemView;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileProcessUtil {

    public static String removeFirstPartIfEqual(String firstPart, String fileName) {
        int index = fileName.toLowerCase().indexOf(firstPart.toLowerCase());
        if (index != -1) {
            return "/" + fileName.substring(index + firstPart.length());
        }

        return fileName;
    }

    private static String appendHome(String folder) {
        if (folder.startsWith("/desktop")) {
            FileSystemView view = FileSystemView.getFileSystemView();
            File file = null;
            File dt = new File(view.getHomeDirectory() + "/Skrivebord");
            if (dt.exists()) {
                file = dt;
            } else {
                dt = new File(view.getHomeDirectory() + "/Desktop");
                if (dt.exists()) {
                    file = dt;
                }
            }
            if (file == null) {
                file = view.getHomeDirectory();
            }
            try {
                folder = file.getAbsolutePath() + folder.substring(8);
            } catch (Exception ex) {
                folder = file.getAbsolutePath();
            }
        } else if (folder.startsWith("/home")) {
            FileSystemView view = FileSystemView.getFileSystemView();
            File file = view.getHomeDirectory();
            try {
                folder = file.getAbsolutePath() + folder.substring(5);
            } catch (Exception ex) {
                folder = file.getAbsolutePath();
            }
        }
        return folder;
    }

    public static File getInbox(int index) {
        String inbox = FileReceiver.getProperty(index + ".registration.inboxFolder");
        if (inbox == null || inbox.trim().isEmpty()) {
            inbox = FileReceiver.getProperty("defaultInbox");
        }
        inbox = appendHome(inbox);
        File dir = new File(inbox);
        //dir.mkdirs();
        Mkdir.mkdirs(dir);
        return dir;
    }

    public static File getOutbox(int index) {
        String outbox = FileSender.getProperty(index + ".outbox");
        if (outbox == null || outbox.trim().isEmpty()) {
            return null;
        }
        outbox = appendHome(outbox);
        File dir = new File(outbox);
        //dir.mkdirs();
        Mkdir.mkdirs(dir);
        return dir;
    }

    public static File getErrorBox(int index) {
        String defaultErrorFolder = FileSender.getProperty("defaultErrorFolder");
        String errorFolder = FileSender.getProperty(index + ".errorFolder");
        if (errorFolder == null || errorFolder.trim().isEmpty()) {
            errorFolder = "../box/errorBox";
        }
        errorFolder = appendHome(errorFolder);
        File folder = new File(defaultErrorFolder);
        //folder.mkdirs();
        Mkdir.mkdirs(folder);
        return folder;
    }

    public static File getDomainNotFoundBox(int index) {
        String defaultDomainNotFoundFolder = FileSender.getProperty("defaultDomainNotFoundFolder");
        String domainNotFoundFolder = FileSender.getProperty(index + ".domainNotFoundFolder");
        if (domainNotFoundFolder == null || domainNotFoundFolder.trim().isEmpty()) {
            domainNotFoundFolder = defaultDomainNotFoundFolder;
        }
        if (domainNotFoundFolder == null || domainNotFoundFolder.trim().isEmpty()) {
            domainNotFoundFolder = "../box/domainNotFound";
        }
        domainNotFoundFolder = appendHome(domainNotFoundFolder);
        File folder = new File(domainNotFoundFolder);
        //folder.mkdirs();
        Mkdir.mkdirs(folder);
        return folder;
    }

    public static File processDomainNotFound(int index, String path, File file) {
        String domainNotFoundFolder = FileProcessUtil.getDomainNotFoundBox(index).getAbsolutePath();
        path = FileProcessUtil.removeFirstPartIfEqual("domainNotFound", path);
        //new File(domainNotFoundFolder + path).mkdirs();
        Mkdir.mkdirs(new File(domainNotFoundFolder + path));
        File newFile = new File(domainNotFoundFolder + path + "/" + FileProcessUtil.removeIndex(file.getName()));
        file.renameTo(newFile);
        System.out.println("File moved to error folder: " + newFile.getAbsolutePath());
        return newFile;
    }

    public static File getSentBox(int index) {
        String defaultSentFolder = FileSender.getProperty("defaultSentFolder");
        String sentFolder = FileSender.getProperty(index + ".sendFolder");
        if (sentFolder == null || sentFolder.trim().isEmpty()) {
            sentFolder = defaultSentFolder;
        }
        sentFolder = appendHome(sentFolder);
        File sentFolderFile = new File(sentFolder);
        //sentFolderFile.mkdirs();
        Mkdir.mkdirs(sentFolderFile);
        return sentFolderFile;
    }

    public static File processInbox(String path, int configurationIndex, List<String> okDomains, File file, String preName) throws Exception {
        String domainName = null;
        try {
            domainName = okDomains.get(0);
        } catch (Exception ex) {
        }
        if (domainName == null) {
            domainName = "unknown_sender";
        }
        //rremove domain if same as host
        String defaultDomainNameOfClient = FileReceiver.getProperty("defaultDomainNameOfClient");
        if (defaultDomainNameOfClient != null) {
            int index = path.indexOf(defaultDomainNameOfClient);
            if (index != -1) {
                try {
                    path = path.substring(index + defaultDomainNameOfClient.length());
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
        //remove domain if from localhost 2 locahost
        int index = path.indexOf(domainName);
        if (index != -1) {
            try {
                path = path.substring(domainName.length());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        if (!path.startsWith("/")) {
            path = "/" + path;
        }
        String defaulInboxFolder = FileReceiver.getProperty("defaultInboxFolder");
        String inboxFolder = FileReceiver.getProperty(configurationIndex + ".registration.inboxFolder");
        if (inboxFolder == null || inboxFolder.trim().isEmpty()) {
            inboxFolder = defaulInboxFolder;
        }
        File inboxFolderFile = new File(inboxFolder + "/" + domainName + path);
        //boolean ok = inboxFolderFile.mkdirs();
        boolean ok = Mkdir.mkdirs(inboxFolderFile);
        File newFile = new File(inboxFolder + "/" + domainName + path + "/" + preName + removeIndex(file.getName()));
        return newFile;
    }

    public static void deleteEmptyDir(String nameOfDirNot2Delete, File directory) {
        for (File childFile : directory.listFiles()) {
            if (childFile.isDirectory()) {
                deleteEmptyDir(nameOfDirNot2Delete, childFile);
            }
        }
        if (directory.isDirectory() && directory.list().length == 0) {
            if (!directory.getName().equalsIgnoreCase(nameOfDirNot2Delete)) {
                directory.delete();
                System.out.println("deleting folder " + directory.getAbsolutePath() + ", status " + directory.delete());
            }
        }
    }

    public static String addIndex(String fileName) {
        //name dot index dot extension
        String name = null;
        int numberOfTries = 1;
        String extension = null;

        int loopCounter = 0;
        int dotIndex = fileName.lastIndexOf(".");
        String firstPart = fileName;
        loop:
        while (dotIndex != -1) {
            String lastPart = firstPart.substring(dotIndex + 1);
            firstPart = firstPart.substring(0, dotIndex);
            name = firstPart;
            switch (loopCounter) {
                case 0 -> {
                    extension = lastPart;
                    break;
                }
                case 1 -> {
                    String numberOfTriesAsString = lastPart;
                    try {
                        numberOfTries = Integer.parseInt(numberOfTriesAsString);
                        numberOfTries++;
                    } catch (Exception ex) {
                        //not an index its a name
                        break loop;
                    }
                    break;
                }
                case 2 -> {
                    break loop;
                }
            }
            dotIndex = firstPart.lastIndexOf(".");
            loopCounter++;
        }
        return name + "." + numberOfTries++ + "." + extension;
    }

    public static String removeIndex(String fileName) {
        //name dot index dot extension
        String name = null;
        int numberOfTries = 1;
        String extension = null;

        int loopCounter = 0;
        int dotIndex = fileName.lastIndexOf(".");
        String firstPart = fileName;
        loop:
        while (dotIndex != -1) {
            String lastPart = firstPart.substring(dotIndex + 1);
            firstPart = firstPart.substring(0, dotIndex);
            name = firstPart;
            switch (loopCounter) {
                case 0 -> {
                    extension = lastPart;
                    break;
                }
                case 1 -> {
                    String numberOfTriesAsString = lastPart;
                    try {
                        numberOfTries = Integer.parseInt(numberOfTriesAsString);
                        numberOfTries++;
                    } catch (Exception ex) {
                        //not an index its a name
                        break loop;
                    }
                    break;
                }
                case 2 -> {
                    break loop;
                }
            }
            dotIndex = firstPart.lastIndexOf(".");
            loopCounter++;
        }
        return name + "." + extension;
    }

    public static boolean copyFile(File fromFile, File toFile) {
        try {
            InputStream in = new BufferedInputStream(
                    new FileInputStream(fromFile));
            OutputStream out = new BufferedOutputStream(
                    new FileOutputStream(toFile));

            byte[] buffer = new byte[1024];
            int lengthRead;
            while ((lengthRead = in.read(buffer)) > 0) {
                out.write(buffer, 0, lengthRead);
                out.flush();
            }
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public static String getPath(String path) {
        if (path == null || path.trim().equalsIgnoreCase(".") || path.trim().equals("")) {
            path = "";
        } else {
            if (path.startsWith(".")) {
                path = path.substring(1);
            }
            if (path.startsWith(".")) {
                path = path.substring(1);
            }
            if (!path.startsWith("/")) {
                path = "/" + path;
            }
            if (path.endsWith("/")) {
                path = path.substring(0, path.length() - 1);
            }
        }
        int i = path.indexOf("/");
        if (i != -1) {
            //remove first path
            path = path.substring(i);
        }
        path = path.replaceAll(ICommand.SPACE_SEPERATOR, " ");
        return path;
    }
}
