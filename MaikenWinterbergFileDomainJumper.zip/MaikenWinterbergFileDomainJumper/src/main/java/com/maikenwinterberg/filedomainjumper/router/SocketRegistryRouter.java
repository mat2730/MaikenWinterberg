/*
 * Martin Alexander Thomsen den 17 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.router;

import com.maikenwinterberg.filedomainjumper.FileSender;
import com.maikenwinterberg.documentiterator.IDocumentNode;
import com.maikenwinterberg.socketregistry.api.GetDomainnamesOfRegistry;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * @SEE doc/fetchMedHarris.pdf
 */
public class SocketRegistryRouter implements IDocumentRouter {

    @Override
    public List<String> getDomainNamesOfRecievers(int index, IDocumentNode documentNode) {
        String defaultDomainNameOfClient = FileSender.getProperty("defaultDomainNameOfClient");
        String domainNameOfClient = FileSender.getProperty(index + ".domainNameOfClient");
        String registries = FileSender.getProperty(index + ".registries");
        String type = FileSender.getProperty(index + ".type");
        String serviceName = FileSender.getProperty(index + ".serviceName");
        if (domainNameOfClient != null && !domainNameOfClient.isEmpty()) {
            defaultDomainNameOfClient = domainNameOfClient;
        }
        String fetchloopAsString = FileSender.getProperty("fetchloop");
        boolean fetchloop = true;
        try {
            fetchloop = Boolean.parseBoolean(fetchloopAsString);
        } catch (Exception ex) {
            //ignore
        }
        return GetDomainnamesOfRegistry.getDomainNamesOfRecievers(defaultDomainNameOfClient, registries, type, null, serviceName, fetchloop);
    }
}
