/*
 * Martin Alexander Thomsen den 17 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.documentprocess;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class DomainFileProcess extends DomainAndTimeFileProces {

    @Override
    protected String getDateString() {
        return "";
    }

}
