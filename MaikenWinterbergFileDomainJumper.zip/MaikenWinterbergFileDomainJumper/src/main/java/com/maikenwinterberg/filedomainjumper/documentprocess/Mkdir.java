/*
 * Martin Alexander Thomsen den 28 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.documentprocess;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.attribute.PosixFilePermission;
import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * @SEE doc/dieletter.pdf
 * @SEE doc/buildALanWithWallByDonald.pdf
 *
 * TODO fixme:  I get a problem when I move the box to the home folder. mkdirs do not work there. I dont know if its Java or the OS thats the problem. 
 * nor can I use ../.. as a path and go back to home that way.
 * I am using https://linuxmint.com/ and java version "17.0.11" 2024-04-16 LTS
 * https://www.youtube.com/watch?v=1vrEljMfXYo
 */
public class Mkdir {

    public static boolean mkdirs(File f) {
        boolean ok = f.mkdirs();
        try {
            if (!ok) {
                ok = jumpOverWindowsWall(false, f);
            }
            if (!ok) {
                ok = jumpOverLinuxAndMacWall(false, f);
            }
            if (!ok) {
                ok = jumpOverWindowsWall(true, f);
            }
            if (!ok) {
                ok = jumpOverLinuxAndMacWall(true, f);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return ok;
    }

    public static boolean touch(File f) throws Exception {
        try {
            boolean ok = touchTheGround(false, f);
            if (!ok) {
                ok = touchTheGround(true, f);
            }
            return ok;
        } catch (Exception ex) {
        }
        return false;
    }

    private static boolean touchTheGround(boolean withScript, File f) throws Exception {
        try {
            return invokeCmd(withScript, "touch " + f.getAbsolutePath());
        } catch (Exception ex) {
        }
        return false;
    }

    private static boolean jumpOverWindowsWall(boolean withScript, File f) throws Exception {
        return jumpOverWallWithScript(withScript, "md", f);
    }

    private static boolean jumpOverLinuxAndMacWall(boolean withScript, File f) throws Exception {
        return jumpOverWallWithScript(withScript, "mkdir", f);
    }

    private static boolean jumpOverWallWithScript(boolean withScript, String mkDir, File f) throws Exception {
        String path = f.getAbsolutePath();
        StringTokenizer tok = new StringTokenizer(path, "/");
        StringBuilder b = new StringBuilder();
        boolean ok = true;
        while (tok.hasMoreTokens()) {
            b.append("/");
            b.append(tok.nextToken());
            if (!new File(b.toString()).exists()) {
                String cmd = mkDir + " " + b.toString();
                if (!invokeCmd(withScript, cmd)) {
                    ok = false;
                }
            }
        }
        return ok;
    }

    private static boolean invokeCmd(boolean withScript, String cmd) throws Exception {
        if (withScript) {
            return invokeCmd1(cmd);
        } else {
            return invokeCmd2(cmd);
        }
    }

    private static boolean invokeCmd1(String cmd) throws Exception {
        boolean ok = false;
        //String[] command = {"/bin/bash", "-c", cmd};
        //System.out.println("command " + Arrays.toString(command));
        try {
            Process pb = new ProcessBuilder(cmd).start();
            int exitValue = pb.waitFor();
            if (exitValue == 0) {
                ok = true;
            }
            System.out.println("invoke with script " + ok + " cmd:" + cmd);
        } catch (Exception ex) {
        }
        return ok;
    }

    private static boolean invokeCmd2(String cmd) throws Exception {
        boolean ok = false;
        try {
            File temp = save("temp.sh", cmd);
            //String[] command = {"/bin/bash", "-c", temp.getAbsolutePath()};
            //System.out.println("command " + Arrays.toString(command));
            Process pb = new ProcessBuilder(cmd).start();
            int exitValue = pb.waitFor();
            if (exitValue == 0) {
                ok = true;
            }
            new File("temp.sh").delete();
            System.out.println("invoke scripted file " + ok + " cmd:" + cmd);
        } catch (Exception ex) {
        }
        return ok;
    }

    private static File save(String fileName, String text2Save) throws Exception {
        File f = new File(fileName);
        FileOutputStream fos = new FileOutputStream(f);
        BufferedOutputStream bos = new BufferedOutputStream(fos);
        bos.write(text2Save.getBytes("utf-8"));
        bos.close();
        Set<PosixFilePermission> perms = new HashSet<>();
        perms.add(PosixFilePermission.GROUP_EXECUTE);
        perms.add(PosixFilePermission.GROUP_READ);
        perms.add(PosixFilePermission.GROUP_WRITE);
        perms.add(PosixFilePermission.OTHERS_EXECUTE);
        perms.add(PosixFilePermission.OTHERS_READ);
        perms.add(PosixFilePermission.OTHERS_WRITE);
        perms.add(PosixFilePermission.OWNER_READ);
        perms.add(PosixFilePermission.OWNER_WRITE);
        perms.add(PosixFilePermission.OWNER_EXECUTE);
        Files.setPosixFilePermissions(f.toPath(), perms);
        return f;
    }
}
