/*
 * Martin Alexander Thomsen den 8 August 2024
 */
package com.maikenwinterberg.filedomainjumper.documentiterator;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IDocumentNode {
    public String getId();

    public String getGroupName();

    public String getName();

    public long getLength();

    public byte[] getBytes() throws Exception;
}
