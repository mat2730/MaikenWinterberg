/*
 * Martin Alexander Thomsen den 8 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.documentiterator;

import java.io.File;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileDocumentIterator implements IDocumentIterator {

    private IDocumentTouch touch;
    private File startingDir;
    private Map registriesByDomain;
    private int configIndex;
    private String domainNameOfClient;
    private String serviceName;
    private int count;

    public FileDocumentIterator() {
    }

    @Override
    public void setTouch(IDocumentTouch touch) {
        this.touch = touch;
    }

    public void setStartingDir(File startingDir) {
        this.startingDir = startingDir;
    }

    @Override
    public void setRegistriesByDomain(Map registriesByDomain) {
        this.registriesByDomain = registriesByDomain;
    }

    @Override
    public void setConfigIndex(int configIndex) {
        this.configIndex = configIndex;
    }

    @Override
    public void setDomainNameOfClient(String domainNameOfClient) {
        this.domainNameOfClient = domainNameOfClient;
    }

    @Override
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    @Override
    public int iterateDocuments() {
        File files[] = startingDir.listFiles();
        if (files != null && files.length > 0) {
            for (File childFile : files) {
                try {
                    if (childFile.isDirectory()) {
                        traverseTree("", childFile);
                    } else if (childFile.isFile()) {
                        touch.touch(registriesByDomain, domainNameOfClient, serviceName, configIndex, new FileDocumentNode("", childFile));
                        count++;
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
        return count;
    }

    private void traverseTree(String path, File parentFile) throws Exception {
        File[] files = parentFile.listFiles();
        for (File childFile : files) {
            try {
                if (childFile.isDirectory()) {
                    traverseTree(path + "/" + parentFile.getName(), childFile);
                } else if (childFile.exists() && childFile.isFile()) {
                    touch.touch(registriesByDomain, domainNameOfClient, serviceName, configIndex, new FileDocumentNode(path, childFile));
                    count++;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
