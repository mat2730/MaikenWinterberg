/*
 * Martin Alexander Thomsen den 28 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.documentiterator;

import java.io.File;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileDocumentIterator implements IDocumentIterator {

    protected IDocumentTouch touch;
    protected File startingDir;
    private int count;

    @Override
    public void setTouch(IDocumentTouch touch) {
        this.touch = touch;
    }

    public void setStartingDir(File startingDir) {
        this.startingDir = startingDir;
    }

    protected TouchNode getTouchNode(String path, File file) {
        TouchNode node = new TouchNode();
        node.addAttribute(IDocumentNode.class.getName(), new FileDocumentNode(path, file));
        return node;
    }

    @Override
    public int iterateDocuments() {
        File files[] = startingDir.listFiles();
        if (files != null && files.length > 0) {
            for (File childFile : files) {
                try {
                    if (childFile.isDirectory()) {
                        traverseTree("", childFile);
                    } else if (childFile.isFile()) {
                        touch.touch(getTouchNode("",childFile));
                        count++;
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
        return count;
    }

    private void traverseTree(String path, File parentFile) throws Exception {
        File[] files = parentFile.listFiles();
        for (File childFile : files) {
            try {
                if (childFile.isDirectory()) {
                    traverseTree(path + "/" + parentFile.getName(), childFile);
                } else if (childFile.exists() && childFile.isFile()) {
                    touch.touch(getTouchNode(path, childFile));
                    count++;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
