/*
 * Martin Alexander Thomsen den 2 August 2024
 */
package com.maikenwinterberg.filedomainjumper.documentprocess;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class InboxLog {

    private static Map<Integer, BufferedWriter> CACHE = new HashMap();

    private static BufferedWriter getWriter(int index) {
        try {
            BufferedWriter bw = CACHE.get(index);
            if (bw != null) {
                return bw;
            }
            File inboxFile = FileProcessUtil.getInbox(index);
            File file = new File(inboxFile.getAbsoluteFile() + "/inbox.log");
            FileWriter fw = new FileWriter(file, true);
            bw = new BufferedWriter(fw);
            CACHE.put(index, bw);
            return bw;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    protected void finalize() throws Throwable {
        for (Iterator<BufferedWriter> i = CACHE.values().iterator(); i.hasNext();) {
            i.next().close();
        }
    }

    public synchronized static void log(int index, String message) {
        try {
            BufferedWriter bw = getWriter(index);
            if (bw != null) {
                System.out.println(message);
                bw.write(message);
                bw.write("\n");
                bw.flush();
            } else {
                System.out.println("buffered writer to log not created");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
