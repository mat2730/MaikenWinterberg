/*
 * Martin Alexander Thomsen den 6 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper;

import com.maikenwinterberg.socketregistry.api.AbstractRegisration;
import java.io.FileInputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import com.maikenwinterberg.socketregistry.api.ClientRegistryAddress;
import com.maikenwinterberg.socketregistry.api.SubscriptionRegistration;
import com.maikenwinterberg.socketregistry.persistence.jdbc.RegistryJDBCDB;
import com.maikenwinterberg.security.IRegistrySecurity;
import com.maikenwinterberg.security.RegistrySecurity;
import com.maikenwinterberg.security.StaticRegistrySecurity;
import java.io.File;
import java.net.SocketException;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;
import javax.swing.filechooser.FileSystemView;
import javafixes.concurrency.Runner;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileReceiver extends Thread implements Callable {

    private final static Map<String, ClientRegistry> CLIENT_REGISTRIES = new HashMap();
    public static int COUNTER = 0;

    private static final Properties PROPERTIES = new Properties();
    private static Properties VALID_DOMAINS = null;
    private static Properties IN_VALID_DOMAINS = null;
    private static long IN_VALID_DOMAINS_LAST_MODIFIED;
    private static long VALID_DOMAINS_LAST_MODIFIED;
    //private static long PROPERTIES_LAST_MODIFIED;
    private static File invalidDomainFile;
    private static File validDomainFile;
    private static File domainJumperConfigFile;

    public static final boolean DEBUG = false;
    public boolean connected = false;

    private static ServerSocket SERVER_SOCKET;

    @Override
    public void run() {
        try {
            while (true) {
                Thread.sleep(RegistryJDBCDB.HEARTBEAT_TIME);
                try {
                    int c = register();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static String getProperty(String name) {
        return (String) PROPERTIES.get(name);

    }

    public static Properties getInValidDomains() throws Exception {
        if (invalidDomainFile == null) {
            FileSystemView view = FileSystemView.getFileSystemView();
            String configFolder = view.getHomeDirectory().getAbsolutePath();
            invalidDomainFile = new File(configFolder + "/config/fileDomainJumperConfig/inValidDomains.cfg");
            if (!invalidDomainFile.exists()) {
                invalidDomainFile = new File("config/fileDomainJumperConfig/inValidDomains.cfg");
            }
        }
        BasicFileAttributes attr = Files.readAttributes(invalidDomainFile.toPath(), BasicFileAttributes.class);
        FileTime fileDate = attr.lastModifiedTime();
        if (IN_VALID_DOMAINS != null) {
            if (IN_VALID_DOMAINS_LAST_MODIFIED == fileDate.toMillis()) {
                return IN_VALID_DOMAINS;
            }
        }
        IN_VALID_DOMAINS_LAST_MODIFIED = fileDate.toMillis();
        IN_VALID_DOMAINS = new Properties();
        IN_VALID_DOMAINS.load(new FileInputStream(invalidDomainFile));
        return IN_VALID_DOMAINS;
    }

    public static Properties getValidDomains() throws Exception {
        if (validDomainFile == null) {
            FileSystemView view = FileSystemView.getFileSystemView();
            String configFolder = view.getHomeDirectory().getAbsolutePath();
            validDomainFile = new File(configFolder + "/config/fileDomainJumperConfig/validDomains.cfg");
            if (!validDomainFile.exists()) {
                validDomainFile = new File("config/fileDomainJumperConfig/validDomains.cfg");
            }
        }
        BasicFileAttributes attr = Files.readAttributes(validDomainFile.toPath(), BasicFileAttributes.class);
        FileTime fileDate = attr.lastModifiedTime();
        if (VALID_DOMAINS != null) {
            if (VALID_DOMAINS_LAST_MODIFIED == fileDate.toMillis()) {
                return VALID_DOMAINS;
            }
        }
        VALID_DOMAINS_LAST_MODIFIED = fileDate.toMillis();
        VALID_DOMAINS = new Properties();
        VALID_DOMAINS.load(new FileInputStream(validDomainFile));
        return VALID_DOMAINS;
    }

    public static String getSecurityImpl() {
        try {
            String c = getProperty("securityimpl");
            IRegistrySecurity rs = (IRegistrySecurity) Class.forName(c).newInstance();
            return rs.getClass().getName();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return StaticRegistrySecurity.class.getName();
    }

    private int register() throws Exception {
        if (CLIENT_REGISTRIES != null) {
            for (ClientRegistry cr : CLIENT_REGISTRIES.values()) {
                cr.close();
            }
            CLIENT_REGISTRIES.clear();
        }
        connected = true;
        //use home directory if present otherwise look in local path
        FileSystemView view = FileSystemView.getFileSystemView();
        String configFolder = view.getHomeDirectory().getAbsolutePath();
        domainJumperConfigFile = new File(configFolder + "/config/fileDomainJumperConfig/fileReceiver.properties");
        if (!domainJumperConfigFile.exists()) {
            domainJumperConfigFile = new File("config/fileDomainJumperConfig/fileReceiver.properties");
        }
        List DEFAULT_REGISTRIES = new LinkedList();

        PROPERTIES.clear();
        PROPERTIES.load(new FileInputStream(domainJumperConfigFile));
        //BasicFileAttributes attr = Files.readAttributes(domainJumperConfigFile.toPath(), BasicFileAttributes.class);
        //FileTime fileDate = attr.lastModifiedTime();
        //PROPERTIES_LAST_MODIFIED = fileDate.toMillis();
        String defaultDomainNameOfClient = PROPERTIES.getProperty("defaultDomainNameOfClient");
        String defaultRegistries = PROPERTIES.getProperty("defaultRegistries");
        String useExternalIDString = PROPERTIES.getProperty("useExternalID", "true");
        boolean useExternalID = true;
        try {
            useExternalID = Boolean.parseBoolean(useExternalIDString);
        } catch (Exception ex) {
        }
        int count = 0;
        //for all registries
        StringTokenizer tok = new StringTokenizer(defaultRegistries, ";");
        while (tok.hasMoreTokens()) {
            try {
                String registryConfig = tok.nextToken();
                if (FileReceiver.DEBUG) {
                    System.out.println("Init default registry: " + registryConfig);
                }
                StringTokenizer tok2 = new StringTokenizer(registryConfig, ":");
                String url = tok2.nextToken();
                String port = null;
                try {
                    port = tok2.nextToken();
                } catch (Exception ex) {
                    port = "4554";
                }
                ClientRegistry clientRegistry = ClientRegistry.getRegistryInstance(defaultDomainNameOfClient, url, Integer.parseInt(port), useExternalID, false);
                CLIENT_REGISTRIES.put(registryConfig, clientRegistry);
                DEFAULT_REGISTRIES.add(clientRegistry);
            } catch (Exception ex) {
                ex.printStackTrace();
                connected = false;
            }
        }
        if (FileReceiver.DEBUG) {
            System.out.println("registries: " + CLIENT_REGISTRIES);
        }
        //for all registrations -> register
        int index = 1;
        //for all registrations
        while (true) {
            try {
                if (FileReceiver.DEBUG) {
                    System.out.println("Init registration index " + index);
                }
                String type = PROPERTIES.getProperty(index + ".registration.type");
                if (type == null || type.trim().isEmpty()) {
                    break;
                }
                String domainName = PROPERTIES.getProperty(index + ".registration.domainName");
                String serviceName = PROPERTIES.getProperty(index + ".registration.serviceName");
                String ip = PROPERTIES.getProperty(index + ".registration.ip");
                String port = PROPERTIES.getProperty("port");
                //String secure = PROPERTIES.getProperty(index + ".registration.secure");
                String id = PROPERTIES.getProperty(index + ".registration.id");
                String registries = PROPERTIES.getProperty(index + ".registration.registries");
                if (Integer.parseInt(id) != index) {
                    throw new IllegalStateException("Invalid id. The ID must match the index");
                }
                if (ip == null || ip.trim().isEmpty()) {
                    ip = defaultDomainNameOfClient;
                }
                if (domainName == null || domainName.trim().isEmpty()) {
                    domainName = defaultDomainNameOfClient;
                }
                String publicKeyAsBase64 = RegistrySecurity.toBase64(getSecurityImpl(), RegistrySecurity.getKeyPair(getSecurityImpl(), this, false).getPublic()); //RSAUtil.toBase64(RSAUtil.getRSAKeyPar(this).getPublic());
                /*
                if (secure != null && secure.equalsIgnoreCase("false")) {
                    //do nothing
                } else {
                    publicKeyAsBase64 = RegistrySecurity.toBase64(getSecurityImpl(), RegistrySecurity.getKeyPair(getSecurityImpl(), this).getPublic()); //RSAUtil.toBase64(RSAUtil.getRSAKeyPar(this).getPublic());
                }*/

                if (FileReceiver.DEBUG) {
                    System.out.println("propertiy registration " + id + " " + ip + ":" + port + "/" + serviceName + "." + domainName);
                }
                if (registries == null || registries.isEmpty()) {
                    //for all default Registries
                    for (Iterator<ClientRegistry> i = DEFAULT_REGISTRIES.iterator(); i.hasNext();) {
                        ClientRegistry clientRegistry = i.next();
                        ClientRegistryAddress registryAddress = clientRegistry.registerSocket(domainName, serviceName, id, ip, port, publicKeyAsBase64, getSecurityImpl());
                        if (registryAddress != null) {
                            System.out.println("Default registration " + index + " at: " + registryAddress + " is completed of registry: " + clientRegistry);
                            count++;
                        } else {
                            connected = false;
                        }
                    }
                } else {
                    //for all registries
                    tok = new StringTokenizer(registries, ";");
                    while (tok.hasMoreTokens()) {
                        try {
                            String registryConfig = tok.nextToken();
                            ClientRegistry clientRegistry = CLIENT_REGISTRIES.get(registryConfig);
                            if (clientRegistry == null) {
                                StringTokenizer tok2 = new StringTokenizer(registryConfig, ":");
                                if (FileReceiver.DEBUG) {
                                    System.out.println("Init registry at: " + tok2);
                                }
                                String registryurl = tok2.nextToken();
                                String registryport = tok2.nextToken();
                                clientRegistry = ClientRegistry.getRegistryInstance(defaultDomainNameOfClient, registryurl, Integer.parseInt(registryport), useExternalID, false);
                                CLIENT_REGISTRIES.put(registryConfig, clientRegistry);
                            }
                            ClientRegistryAddress registryAddress = clientRegistry.registerSocket(domainName, serviceName, id, ip, port, publicKeyAsBase64, getSecurityImpl());
                            if (registryAddress != null) {
                                count++;
                                System.out.println("index registration " + index + " at: " + registryAddress + " is completed of registry: " + clientRegistry);
                            } else {
                                connected = false;
                            }
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            connected = false;
                        }
                    }
                    try {
                        Properties VIP_IP = new Properties();
                        view = FileSystemView.getFileSystemView();
                        configFolder = view.getHomeDirectory().getAbsolutePath();
                        File vipIpFile = new File(configFolder + "/config/fileDomainJumperConfig/vip_ip.properties");
                        if (!vipIpFile.exists()) {
                            vipIpFile = new File("config/fileDomainJumperConfig/vip_ip.properties");
                        }
                        if (vipIpFile.exists()) {
                            VIP_IP.load(new FileInputStream(vipIpFile));
                        }

                        int maxsubscriptions = 1000;
                        try {
                            maxsubscriptions = Integer.parseInt(PROPERTIES.getProperty(index + ".registration.maxsubscriptions"));
                        } catch (Exception ex) {
                        }
                        String subscriptionRegistries = PROPERTIES.getProperty(index + ".registration.subscriptionregistries");
                        boolean vipOnly = false;
                        if (subscriptionRegistries != null) {
                            List<ClientRegistry> sregistries = LookupRegistries.getRegistries(defaultDomainNameOfClient, useExternalID, subscriptionRegistries);
                            for (ClientRegistry cr : sregistries) {
                                int offset = 0;
                                int fetchsize = RegistryJDBCDB.MAXFETCHSIZE;
                                while (true) {
                                    List<AbstractRegisration> l = cr.lookup(ClientRegistry.TYPE.subscription, defaultDomainNameOfClient, null, null, offset, fetchsize);
                                    if (l == null || l.isEmpty()) {
                                        break;
                                    }
                                    if (fetchsize >= maxsubscriptions) {
                                        vipOnly = true;
                                    }
                                    for (AbstractRegisration r : l) {
                                        try {
                                            SubscriptionRegistration subr = (SubscriptionRegistration) r;
                                            if (vipOnly) {
                                                if (!VIP_IP.contains(subr.getRegistryIp())) {
                                                    continue;
                                                }
                                            }
                                            ClientRegistry clientRegistry = ClientRegistry.getRegistryInstance(defaultDomainNameOfClient, subr.getRegistryIp(), Integer.parseInt(subr.getRegistryPort()), useExternalID, false);
                                            ClientRegistryAddress registryAddress = clientRegistry.registerSocket(domainName, serviceName, id, ip, port, publicKeyAsBase64, getSecurityImpl());
                                            System.out.println("subsription registration " + index + " at: " + registryAddress + " is completed of registry: " + clientRegistry);
                                        } catch (Exception ex) {
                                            ex.printStackTrace();
                                        }
                                    }
                                    offset += fetchsize;
                                }
                            }
                        }
                    } catch (Exception exe) {
                        exe.printStackTrace();
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            index++;

            if (count == 0) {
                connected = false;
                throw new IllegalStateException("Nothing registrated");
            }
        }
        return count;
    }

    public static void main(String[] args) throws Exception {
        try {
            System.out.println("Starting up fileReceiver");
            FileReceiver jumper = new FileReceiver();
            try {
                int numberOfReg = jumper.register();
                System.out.println("Done with " + numberOfReg + " registrations, Status " + jumper.connected);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            int port = Integer.parseInt(PROPERTIES.getProperty("port"));
            int max1 = 10;
            try {
                max1 = Integer.parseInt(PROPERTIES.getProperty("limit1_number_of_threads"));
            } catch (Exception ex) {
            }
            int max2 = 20;
            try {
                max2 = Integer.parseInt(PROPERTIES.getProperty("max_number_of_threads"));
            } catch (Exception ex) {
            }
            max1 = Math.min(max1, max2);
            System.out.println("port from porperty " + port);
            String bindAddr = PROPERTIES.getProperty("bindaddr");
            InetAddress addr = InetAddress.getByName(bindAddr);
            int backlog = 10;
            SERVER_SOCKET = new ServerSocket(port, backlog, addr);
            System.out.println("Listening on port " + addr + ":" + port + "...");
            new Thread(jumper).start();//update configuration when change
            Runner executor = Runner.runner(max1);
            Properties VIP_IP = new Properties();
            FileSystemView view = FileSystemView.getFileSystemView();
            String configFolder = view.getHomeDirectory().getAbsolutePath();
            File vipIpFile = new File(configFolder + "/config/fileDomainJumperConfig/vip_ip.properties");
            if (!vipIpFile.exists()) {
                vipIpFile = new File("config/fileDomainJumperConfig/vip_ip.properties");
            }
            if (vipIpFile.exists()) {
                VIP_IP.load(new FileInputStream(vipIpFile));
            }
            while (true) {
                Socket clientSocket;
                try {
                    clientSocket = SERVER_SOCKET.accept();
                } catch (SocketException ex) {
                    try {
                        SERVER_SOCKET.close();
                    } catch (Exception exe) {
                        //ignore
                    }
                    SERVER_SOCKET = new ServerSocket(port);
                    clientSocket = SERVER_SOCKET.accept();
                }
                clientSocket.setSoTimeout(1800000);
                COUNTER++;
                if (COUNTER > max2) {
                    clientSocket.close();
                    continue;
                }
                if (COUNTER > max1) {
                    if (!VIP_IP.contains(clientSocket.getRemoteSocketAddress().toString())) {
                        clientSocket.close();
                        continue;
                    }
                }
                FileReceiverThread thread = new FileReceiverThread(clientSocket, jumper);
                executor.run(thread);
            }
        } catch (Throwable ex) {
            ex.printStackTrace();
            throw ex;
        }
    }

    @Override
    public Object call() throws Exception {
        run();
        return null;
    }
}
