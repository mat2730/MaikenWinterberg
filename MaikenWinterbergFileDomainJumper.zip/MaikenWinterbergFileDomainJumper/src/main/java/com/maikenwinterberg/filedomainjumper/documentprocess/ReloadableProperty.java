/*
 * Martin Alexander Thomsen den 31 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.documentprocess;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.Properties;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class ReloadableProperty {

    private Properties PROPERTIES;
    private long PROPERTIES_LAST_MODIFIED;
    private File propertyFile = null;

    public ReloadableProperty(File propertyFile) {
        this.propertyFile = propertyFile;
    }

    public String getProperty(String name) {
        try {
            if (PROPERTIES == null) {
                if (propertyFile.exists()) {
                    try {
                        PROPERTIES = new Properties();
                        PROPERTIES.load(new FileInputStream(propertyFile));
                        BasicFileAttributes attr = Files.readAttributes(propertyFile.toPath(), BasicFileAttributes.class);
                        FileTime fileDate = attr.lastModifiedTime();
                        PROPERTIES_LAST_MODIFIED = fileDate.toMillis();
                    } catch (Exception ex) {
                        PROPERTIES = null;
                        PROPERTIES_LAST_MODIFIED = 0;
                    }
                }
            } else {
                try {
                    BasicFileAttributes attr = Files.readAttributes(propertyFile.toPath(), BasicFileAttributes.class);
                    FileTime fileDate = attr.lastModifiedTime();
                    if (PROPERTIES_LAST_MODIFIED != 0 && PROPERTIES_LAST_MODIFIED != fileDate.toMillis()) {
                        PROPERTIES = null;
                        PROPERTIES_LAST_MODIFIED = 0;
                        return getProperty(name);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    return null;
                }
            }
            if (PROPERTIES != null) {
                return PROPERTIES.getProperty(name);
            }
        } catch (Exception ex) {
            //ignore
        }
        return null;
    }
}
