/*
 * Martin Alexander Thomsen den 24 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.documentprocess;

import com.maikenwinterberg.documentiterator.FileDocumentNode;
import com.maikenwinterberg.documentiterator.IDocumentNode;
import java.io.File;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 * @see doc/stayPutUntilSent.pdf
 */
public class StayPutUntilSentNoSentFileProcess extends StayPutUntilSentFileProcess {

    @Override
    public IDocumentNode processDocument(int configurationIndex, List<String> okDomains, List<String> notOkDomains, IDocumentNode documentNode, IDocumentProcess.DEST destination) throws Exception {
        if (destination == IDocumentProcess.DEST.outBox) {
            FileDocumentNode fdn = (FileDocumentNode) documentNode;
            File file = fdn.getFile();
            if (okDomains != null && !okDomains.isEmpty() && file != null && file.exists()) {
                file.delete();
                return null;
            }
        }
        return new StayPutUntilSentFileProcess().processDocument(configurationIndex, okDomains, notOkDomains, documentNode, destination);
    }
}
