/*
 * Martin Alexander Thomsen den 8 August 2024
 */
package com.maikenwinterberg.filedomainjumper;

import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentNode;
import com.maikenwinterberg.socketregistry.api.SocketRegistration;
import com.maikenwinterberg.socketregistry.security.RegistrySecurity;
import com.maikenwinterberg.socketregistry.server.ICommand;
import com.maikenwinterberg.socketregistry.server.Registry;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.net.URLDecoder;
import java.security.PublicKey;
import javax.crypto.SecretKey;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.comin
 * @see maikenwinterberg.com
 */
public class SendDocument {

    private static final byte[] SKELVANGSVEJ_BLOCK = new byte[8900];
    private static final boolean DEBUG = false;

    static {
        for (int i = 0; i < SKELVANGSVEJ_BLOCK.length; i++) {
            SKELVANGSVEJ_BLOCK[i] = (byte) ' ';
        }
    }

    public static String send(SocketRegistration socketRegistration, IDocumentNode documentNode) throws Exception {
        return send(0, socketRegistration, documentNode);
    }

    private static String send(int count, SocketRegistration socketRegistration, IDocumentNode documentNode) throws Exception {
        Socket socket = socketRegistration.getSocket();
        try {
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());

            String base64PublicKey = (String) socketRegistration.getBase64PublicKey();
            if (DEBUG) {
                System.out.println("socketRegistration: " + socketRegistration);
            }
            if (socketRegistration.publicKeySent(socket)) {
                String data;
                if (base64PublicKey == null) {
                    data = Registry.PROTOCOL;
                } else {
                    PublicKey publicKey = RegistrySecurity.fromBase642SPublicKey(socketRegistration.getSecurityImpl(), base64PublicKey);// RSAUtil.fromBase64(base64PublicKey);
                    SecretKey secretKey = RegistrySecurity.getSecretKey(socketRegistration.getSecurityImpl(), FileSender.class.getName());// AESUtil.getProjectKey(ClientFileDomainJumper.class.getName());
                    byte[] encryptedSecretKey = RegistrySecurity.publicKeyEncryptSecretKey(socketRegistration.getSecurityImpl(), publicKey, secretKey);// RSAUtil.encrypt(publicKey, secretKey.getEncoded());
                    data = Registry.PROTOCOL + RegistrySecurity.toBase64(socketRegistration.getSecurityImpl(), encryptedSecretKey);
                }
                //DO NOT CHANGE THE PROTOCOL - see license.txt 
                byte[] b = data.getBytes("utf-8");
                byte[] block = new byte[SKELVANGSVEJ_BLOCK.length];
                System.arraycopy(SKELVANGSVEJ_BLOCK, 0, block, 0, SKELVANGSVEJ_BLOCK.length);
                System.arraycopy(b, 0, block, 341, b.length);
                if (DEBUG) {
                    System.out.println("writing encryptedSecretKey " + data);
                }
                out.write(block);
                //out.writeInt(b.length);
                //out.write(b);
            }
            //sending attributes
            String attr = "registrationid" + ICommand.EQUAL_SEPERATOR + socketRegistration.getAttributes().get("registrationid")
                    + ICommand.ATTR_SEPERATOR + "clientdomainname" + ICommand.EQUAL_SEPERATOR + socketRegistration.getClientDomainName()
                    + ICommand.ATTR_SEPERATOR + "filename" + ICommand.EQUAL_SEPERATOR + URLDecoder.decode(documentNode.getName(), "utf-8")
                    + ICommand.ATTR_SEPERATOR + "filelength" + ICommand.EQUAL_SEPERATOR + documentNode.getLength() + ICommand.ATTR_SEPERATOR
                    + "path" + ICommand.EQUAL_SEPERATOR + documentNode.getGroupName().trim().replaceAll(" ", ICommand.SPACE_SEPERATOR);
            //DO NOT CHANGE THE PROTOCOL - see license.txt 
            String encryptedAttributes = Registry.PROTOCOL + RegistrySecurity.textEncrypt(socketRegistration.getSecurityImpl(), FileSender.class.getName(), attr);
            if (DEBUG) {
                System.out.println("writing encryptedAttributes " + encryptedAttributes);
            }
            //encryptedAttributes = Registry.PROTOCOL + RegistrySecurity.toBase64(socketRegistration.getSecurityImpl(), encryptedAttributes.getBytes("utf-8"));
            byte[] b = encryptedAttributes.getBytes("utf-8");
            byte[] block = new byte[SKELVANGSVEJ_BLOCK.length];
            System.arraycopy(SKELVANGSVEJ_BLOCK, 0, block, 0, SKELVANGSVEJ_BLOCK.length);
            System.arraycopy(b, 0, block, 341, b.length);
            if (DEBUG) {
                System.out.println("sending attributes long " + b.length);
            }
            out.write(block);
            //out.write(b.length);
            //out.write(b);
            //sending file
            byte[] byteArray = documentNode.getBytes();
            int max = (22222222);
            int lenghtLeft = byteArray.length;
            System.out.println("starting sending file " + documentNode.getName());
            //out.writeLong(byteArray.length);
            for (int index = 0; index < byteArray.length;) {
                int size2Send = Math.min(max, lenghtLeft);
                byte[] data2Send = new byte[size2Send];
                System.arraycopy(byteArray, index, data2Send, 0, size2Send);
                index += size2Send;
                lenghtLeft -= size2Send;
                if (DEBUG) {
                    System.out.println("writing data2Send length " + data2Send.length);
                }
                byte[] encryptedData2Send = RegistrySecurity.byteEncrypt(socketRegistration.getSecurityImpl(), FileSender.class.getName(), data2Send);// AESUtil.simpleEncrypt(ClientFileDomainJumper.class.getName(), byteArray);
                out.writeInt(encryptedData2Send.length);
                out.write(encryptedData2Send);
                if (DEBUG) {
                    System.out.println("written builder.toBytes() " + encryptedData2Send.length);
                }
            }
            out.writeInt(-1);
            System.out.println("done writing file to client");
            String messageFromServer = in.readUTF();
            System.out.println("messageFromServer " + messageFromServer);
            if (messageFromServer.startsWith("encrypted=false")) {
                messageFromServer = messageFromServer.substring(15);
            } else {
                messageFromServer = RegistrySecurity.textDecrypt(socketRegistration.getSecurityImpl(), FileSender.class.getName(), messageFromServer);// AESUtil.simpleDecrypt(ClientFileDomainJumper.class.getName(), messageFromServer);
            }
            return messageFromServer;
        } catch (Exception ex) {
            try {
                socket.close();
            } catch (Exception exe) {
                //ignore
            }
            if (count <= 1) {
                return send(count++, socketRegistration, documentNode);
            } else {
                ex.printStackTrace();
            }
        } finally {
            if (!socket.isClosed()) {
                socketRegistration.releaseSocket(socket);
            }
        }
        return null;
    }
}
