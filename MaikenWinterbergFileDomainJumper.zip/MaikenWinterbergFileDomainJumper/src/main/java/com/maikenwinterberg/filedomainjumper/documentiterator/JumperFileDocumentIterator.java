/*
 * Martin Alexander Thomsen den 8 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.documentiterator;

import java.io.File;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class JumperFileDocumentIterator extends FileDocumentIterator {

    private Map registriesByDomain;
    private int configIndex;
    private String domainNameOfClient;
    private String serviceName;

    public JumperFileDocumentIterator() {
    }

    public void setRegistriesByDomain(Map registriesByDomain) {
        this.registriesByDomain = registriesByDomain;
    }

    public void setConfigIndex(int configIndex) {
        this.configIndex = configIndex;
    }

    public void setDomainNameOfClient(String domainNameOfClient) {
        this.domainNameOfClient = domainNameOfClient;
    }

    public TouchNode getTouchNode(File file) {
        return new JumperTouchNode(registriesByDomain, domainNameOfClient, serviceName, configIndex, new FileDocumentNode("", file));
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

}
