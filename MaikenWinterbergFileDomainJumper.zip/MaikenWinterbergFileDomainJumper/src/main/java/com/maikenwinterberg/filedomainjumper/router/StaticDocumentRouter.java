/*
 * Martin Alexander Thomsen den 8 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.router;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import com.maikenwinterberg.filedomainjumper.FileSender;
import com.maikenwinterberg.filedomainjumper.documentiterator.IDocumentNode;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class StaticDocumentRouter implements IDocumentRouter {

    public StaticDocumentRouter() {
    }

    @Override
    public List<String> getDomainNamesOfRecievers(int index, IDocumentNode documentNode) {
        List<String> domainNameList = new LinkedList();

        try {
            String domainFileName = FileSender.getProperty(index + ".domainfile");
            File domainFile = new File(domainFileName);
            try (BufferedReader br = new BufferedReader(new FileReader(domainFile))) {
                String domainNameLine;
                while ((domainNameLine = br.readLine()) != null) {
                    if (domainNameLine.startsWith("#") || domainNameLine.trim().isEmpty()) {
                        //this is a comment continue;
                        continue;
                    }
                    domainNameList.add(domainNameLine);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return domainNameList;
    }
}
