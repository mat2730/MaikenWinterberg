/*
 * Martin Alexander Thomsen den 8 August 2024
 */
package com.maikenwinterberg.filedomainjumper.documentiterator;

import com.maikenwinterberg.filedomainjumper.JumperTask;
import com.maikenwinterberg.filedomainjumper.QueueHandler;
import java.util.Map;

/**
 *
 * @author martin
 */
public class QueueHandlerTouch implements IDocumentTouch {

    @Override
    public void touch(Map registriesByDomain, String domainNameOfClient, String serviceName, int configIndex, IDocumentNode documentNode) throws Exception {
        if (!documentNode.getName().endsWith(".tmp")) {
            QueueHandler.handleTaskInQueue(registriesByDomain, new JumperTask(configIndex, documentNode, domainNameOfClient, serviceName));
        }
    }
}
