/*
 * Martin Alexander Thomsen den 8 August 2024
 */
package com.maikenwinterberg.filedomainjumper.documentiterator;

import com.maikenwinterberg.documentiterator.TouchNode;
import com.maikenwinterberg.documentiterator.IDocumentTouch;
import com.maikenwinterberg.documentiterator.JumperTouchNode;
import com.maikenwinterberg.filedomainjumper.JumperTask;
import com.maikenwinterberg.filedomainjumper.QueueHandler;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class QueueHandlerTouch implements IDocumentTouch {

    @Override
    public void touch(TouchNode touchNode) throws Exception {
        if (touchNode instanceof JumperTouchNode) {
            JumperTouchNode node = (JumperTouchNode) touchNode;
            if (!node.getDocumentNode().getName().endsWith(".tmp")) {
                QueueHandler.handleTaskInQueue(node.getRegistriesByDomain(), new JumperTask(node.getConfigIndex(), node.getDocumentNode(), node.getDomainNameOfClient(), node.getServiceName()));
            }
        }
    }

    @Override
    public void commit(int index) throws Exception {
    }
}
