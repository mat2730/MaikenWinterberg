/*
 * Martin Alexander Thomsen den 7 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper;

import com.maikenwinterberg.filedomainjumper.savedocument.DocumentSaverFactory;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.Socket;
import java.net.URL;
import java.net.URLDecoder;
import java.security.PrivateKey;
import java.util.StringTokenizer;
import javax.crypto.SecretKey;
import com.maikenwinterberg.security.RegistrySecurity;
import com.maikenwinterberg.socketregistry.server.DomainCheck;
import com.maikenwinterberg.socketregistry.server.ICommand;
import com.maikenwinterberg.socketregistry.server.Registry;
import java.time.format.DateTimeFormatter;
import com.maikenwinterberg.filedomainjumper.savedocument.ISaveDocument;
import java.util.concurrent.Callable;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * @SEE doc/dieletter.pdf
 * @SEE doc/buildALanWithWallByDonald.pdf Changes to this file you must do in
 * coloboration with me see license.txt
 */
public class FileReceiverThread implements Runnable, Callable<Object> {

    private static final boolean DEBUG = true;
    private static String EXTERNAL_ID;

    private final Socket clientSocket;
    private final FileReceiver fileDomainJumper;
    //private final static ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(5);

    public static final DateTimeFormatter ZDT_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM/dd HH:mm");

    FileReceiverThread(Socket clientSocket, FileReceiver fileDomainJumper) {
        String doCheckAsString = FileReceiver.getProperty("useExternalID");
        boolean doCheck = true;
        try {
            doCheck = Boolean.parseBoolean(doCheckAsString);
        } catch (Exception ex) {
        }
        System.out.println(this.hashCode() + "useExternalID" + doCheck);
        if (doCheck && EXTERNAL_ID == null) {
            try {
                System.out.println(this.hashCode() + "looking up externalID");
                URL whatismyip = new URL("http://checkip.amazonaws.com");
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        whatismyip.openStream()));
                EXTERNAL_ID = in.readLine(); //you get the IP as a String
                System.out.println(this.hashCode() + "externalID=" + EXTERNAL_ID);

            } catch (Exception ex) {
                //amazonws is down or do not work -no check possible
            }
        }
        this.clientSocket = clientSocket;
        this.fileDomainJumper = fileDomainJumper;
    }

    @Override
    public void run() {
        String ipOfClient = clientSocket.getRemoteSocketAddress().toString();
        StringTokenizer tok = new StringTokenizer(ipOfClient, "/:");
        ipOfClient = tok.nextToken();
        if (ipOfClient != null && ipOfClient.equals("127.0.0.1")) {
            if (EXTERNAL_ID != null) {
                ipOfClient = EXTERNAL_ID;
            }
        }
        //TODO make domainCheck
        DataOutputStream out = null;
        DataInputStream in = null;
        if (DEBUG) {
            System.out.println(this.hashCode() + ": socket accepted of ip " + ipOfClient);
        }
        try {
            out = new DataOutputStream(clientSocket.getOutputStream());
            in = new DataInputStream(clientSocket.getInputStream());
        } catch (Exception ex) {
            return;
        }
        int numberOfFilesReceived = 0;
        out:
        while (true) {
            int index = 0;
            while (true) {
                if (clientSocket.isClosed()) {
                    break out;
                }
                try {
                    String fileName = null;
                    String attributes = null;
                    String clientDomainName = null;
                    String registrationId = null;
                    String path = "";
                    int filelength = 0;
                    try {
                        System.out.println(this.hashCode() + ": Protocol begin of client " + ipOfClient);
                        String utf = null;
                        //read synchronous key 
                        if (index == 0) {
                            try {/*
                                int size = in.readInt();
                                byte[] encodedFileData = new byte[size];
                                in.readFully(encodedFileData, 0, size);
                                utf = new String(encodedFileData, "utf-8");*/
                                byte[] encodedFileData = new byte[8900];
                                in.readFully(encodedFileData, 0, 8900);
                                utf = new String(encodedFileData, "utf-8").substring(341, 341 + 999).trim();

                            } catch (Exception ex) {
                                //ignore
                            }
                            if (utf == null) {
                                break;
                            }
                            if (DEBUG) {
                                System.out.println(this.hashCode() + ": receiving SecretKey " + utf);
                            }
                            if (!utf.startsWith(Registry.PROTOCOL)) {
                                throw new SecurityException("Invalid protocol " + utf);
                            } else {
                                utf = utf.substring(Registry.PROTOCOL.length());
                            }
                            if (utf.startsWith("encrypted=false")) {
                                throw new IllegalStateException("This channel must be secure");
                            }
                            if (!utf.isEmpty()) {
                                PrivateKey privateKey = RegistrySecurity.getKeyPair(FileReceiver.getSecurityImpl(), fileDomainJumper, false).getPrivate();// RSAUtil.getRSAKeyPar(fileDomainJumper).getPrivate();
                                byte[] AESSecureKey = RegistrySecurity.privateKeyDecrypt(FileReceiver.getSecurityImpl(), privateKey, RegistrySecurity.fromBase64(FileReceiver.getSecurityImpl(), utf));//((//RSAUtil.decrypt(privateKey, utf);
                                SecretKey secretKey = RegistrySecurity.toSecretKey(FileReceiver.getSecurityImpl(), AESSecureKey);// AESUtil.fromBytes(AESSecureKey);
                                if (secretKey == null) {
                                    throw new SecurityException("Security is mandatory");
                                }
                                RegistrySecurity.setSecretKey(FileReceiver.getSecurityImpl(), ipOfClient, secretKey);// AESUtil.setProjectKey(ipOfClient, secretKey);
                            } else {
                                RegistrySecurity.setSecretKey(FileReceiver.getSecurityImpl(), ipOfClient, null);// AESUtil.setProjectKey(ipOfClient, secretKey);
                                throw new SecurityException("Security is mandatory");
                            }
                        }
                        String encryptedAttributes = null;
                        try {
                            /*
                            int size = in.readInt();
                            byte[] encodedFileData = new byte[size];
                            in.readFully(encodedFileData, 0, size);
                            encryptedAttributes = new String(encodedFileData, "utf-8");
                             */
                            byte[] encodedFileData = new byte[8900];
                            in.readFully(encodedFileData, 0, 8900);
                            encryptedAttributes = new String(encodedFileData, "utf-8").substring(341, +341 + 555).trim();
                        } catch (Exception ex) {
                            //ignore
                        }
                        if (encryptedAttributes == null) {
                            break;
                        }
                        if (!encryptedAttributes.startsWith(Registry.PROTOCOL)) {
                            throw new SecurityException("Invalid protocol " + encryptedAttributes);
                        } else {
                            encryptedAttributes = encryptedAttributes.substring(Registry.PROTOCOL.length());
                        }
                        attributes = RegistrySecurity.textDecrypt(FileReceiver.getSecurityImpl(), ipOfClient, encryptedAttributes); // AESUtil.simpleDecrypt(ipOfClient, encryptedAttributes);
                        if (attributes == null) {
                            throw new IllegalStateException("cannot read attributes of file");
                        }
                        StringTokenizer tok2 = new StringTokenizer(attributes, ICommand.ATTR_SEPERATOR);
                        while (tok2.hasMoreTokens()) {
                            try {
                                StringTokenizer tok3 = new StringTokenizer(tok2.nextToken(), ICommand.EQUAL_SEPERATOR);
                                String attributeName = tok3.nextToken();
                                String attributeValue = "";
                                try {
                                    attributeValue = tok3.nextToken();
                                } catch (Exception ex) {
                                }
                                if (attributeName.equalsIgnoreCase("registrationId")) {
                                    registrationId = attributeValue;
                                } else if (attributeName.equalsIgnoreCase("fileName")) {
                                    fileName = URLDecoder.decode(attributeValue, "utf-8");
                                } else if (attributeName.equalsIgnoreCase("clientDomainName")) {
                                    clientDomainName = attributeValue;
                                } else if (attributeName.equalsIgnoreCase("filelength")) {
                                    filelength = Integer.parseInt(attributeValue);
                                } else if (attributeName.equalsIgnoreCase("path")) {
                                    path = attributeValue;
                                    if (path == null) {
                                        path = "";
                                    }
                                    path = path.replaceAll(ICommand.SPACE_SEPERATOR, " ");
                                }
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                        //domain test
                        boolean acceptIpAsDomainName = true;
                        try {
                            if (FileReceiver.getProperty("acceptIpAsDomainName").equalsIgnoreCase("false")) {
                                acceptIpAsDomainName = false;
                            }
                        } catch (Exception ex) {
                        }
                        DomainCheck.validateDomainNameOnServer(FileReceiver.getValidDomains(), FileReceiver.getInValidDomains(), !acceptIpAsDomainName, ipOfClient, clientDomainName);
                        System.out.println(this.hashCode() + "domain ok");
                        //max byte test
                        int maxNumberOfBytes = 0;
                        try {
                            String maxNumberOfBytesAsString = FileReceiver.getProperty(registrationId + ".registration.maxNumberOfBytes");
                            maxNumberOfBytes = Integer.parseInt(maxNumberOfBytesAsString);
                        } catch (Exception ex) {
                        }
                        System.out.println(this.hashCode() + ": reading file " + fileName);
                        ISaveDocument saver = DocumentSaverFactory.getSaveDocument(registrationId);
                        boolean save = saver.init(clientDomainName, registrationId, path, fileName, filelength);
                        while (true) {
                            long size2Read = 0;
                            try {
                                size2Read = in.readInt();
                            } catch (Exception ex) {
                            }
                            if (size2Read == -1) {
                                break;
                            }
                            if (save) {
                                byte[] encodedFileData = new byte[(int) size2Read];
                                try {
                                    in.readFully(encodedFileData, 0, (int) size2Read);
                                } catch (Exception ex) {
                                    break;
                                }
                                byte[] fileData = RegistrySecurity.byteDecrypt(FileReceiver.getSecurityImpl(), ipOfClient, encodedFileData);// AESUtil.simpleDecrypt(ipOfClient, encodedFileData);
                                saver.append(fileData);
                            } else {
                                in.skipBytes((int) size2Read);
                            }
                        }
                        if (save) {
                            saver.commit();
                        }
                        //write result
                        String cmd = "status" + ICommand.EQUAL_SEPERATOR + "ok" + ICommand.ATTR_SEPERATOR + "numberOfFilesReceived" + ICommand.EQUAL_SEPERATOR + numberOfFilesReceived;
                        System.out.println(this.hashCode() + ": writing command " + cmd + " of client: " + ipOfClient);
                        out.writeUTF(RegistrySecurity.textEncrypt(FileReceiver.getSecurityImpl(), ipOfClient, cmd));//AESUtil.simpleEncrypt(ipOfClient, "status" + ICommand.EQUAL_SEPERATOR + "ok" + ICommand.ATTR_SEPERATOR + "numberOfFilesReceived" + ICommand.EQUAL_SEPERATOR + numberOfFilesReceived));
                        System.out.println(this.hashCode() + ": End of protocol of ip " + ipOfClient);
                    } catch (Throwable ex) {
                        if (clientSocket.isClosed()) {
                            break;
                        }
                        ex.printStackTrace();
                        try {
                            //write error
                            StringWriter sw = new StringWriter();
                            PrintWriter pw = new PrintWriter(sw);
                            ex.printStackTrace(pw);
                            String sStackTrace = sw.toString();
                            String cmd = "status" + ICommand.EQUAL_SEPERATOR + "error" + ICommand.ATTR_SEPERATOR + "errormessage" + ICommand.EQUAL_SEPERATOR + ex.getMessage() + ICommand.ATTR_SEPERATOR + "stacktrace" + ICommand.EQUAL_SEPERATOR + "\n" + sStackTrace;
                            out.writeUTF(RegistrySecurity.textEncrypt(FileReceiver.getSecurityImpl(), ipOfClient, cmd));// AESUtil.simpleEncrypt(ipOfClient, "status" + ICommand.EQUAL_SEPERATOR + "error" + ICommand.ATTR_SEPERATOR + "errormessage" + ICommand.EQUAL_SEPERATOR + ex.getMessage() + ICommand.ATTR_SEPERATOR + "stacktrace" + ICommand.EQUAL_SEPERATOR + "\n" + sStackTrace));
                        } catch (Exception exe) {
                            exe.printStackTrace();
                        } finally {
                            break;
                        }
                    } finally {
                        //RegistrySecurity.removeSecretKey(FileDomainJumper.getSecurityImpl(), ipOfClient);
                    }
                } catch (Exception exe) {
                    if (DEBUG) {
                        exe.printStackTrace();
                    }
                } finally {
                    index++;
                    try {
                        in.close();
                        out.close();
                        if (clientSocket != null) {
                            clientSocket.close();
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    } finally {
                        FileReceiver.COUNTER--;
                    }
                    if (DEBUG) {
                        System.out.println(this.hashCode() + ": done with client request");
                    }
                }
            }
        }
    }

    @Override
    public Object call() throws Exception {
        run();
        return null;
    }
}
