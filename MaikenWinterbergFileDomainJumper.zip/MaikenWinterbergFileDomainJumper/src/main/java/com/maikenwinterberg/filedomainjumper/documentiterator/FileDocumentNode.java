/*
 * Martin Alexander Thomsen den 8 August 2024
 */
package com.maikenwinterberg.filedomainjumper.documentiterator;

import java.io.File;
import java.io.FileInputStream;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileDocumentNode implements IDocumentNode {

    private final File file;
    private final String path;

    public FileDocumentNode(String path, File file) {
        this.file = file;
        this.path = path;//path.trim().replaceAll(" ", ICommand.SPACE_SEPERATOR);
    }

    @Override
    public String getGroupName() {
        return this.path;
    }

    @Override
    public String getId() {
        return file.getAbsolutePath();
    }

    @Override
    public String getName() {
        return file.getName();
    }

    @Override
    public long getLength() {
        return file.length();
    }

    @Override
    public byte[] getBytes() throws Exception {
        byte[] byteArray = new byte[(int) file.length()];
        try (FileInputStream inputStream = new FileInputStream(file)) {
            inputStream.read(byteArray);
        }
        return byteArray;
    }

    public File getFile() {
        return file;
    }
}
