/*
 * Martin Alexander Thomsen den 8 August 2024
 */
package com.maikenwinterberg.filedomainjumper.documentiterator;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.Date;
import java.util.Objects;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileDocumentNode implements IDocumentNode, Comparable<IDocumentNode> {

    private final File file;
    private final String path;
    private String sortAttribute = "size";

    public FileDocumentNode(String path, File file) {
        this.file = file;
        this.path = path;//path.trim().replaceAll(" ", ICommand.SPACE_SEPERATOR);
    }

    public void setSortAttribute(String sortAttribute) {
        this.sortAttribute = sortAttribute;
    }

    @Override
    public String getGroupName() {
        return this.path;
    }

    @Override
    public String getId() {
        return file.getAbsolutePath();
    }

    @Override
    public String getName() {
        return file.getName();
    }

    @Override
    public long getLength() {
        return file.length();
    }

    @Override
    public byte[] getBytes() throws Exception {
        byte[] byteArray = new byte[(int) file.length()];
        try (FileInputStream inputStream = new FileInputStream(file)) {
            inputStream.read(byteArray);
        }
        return byteArray;
    }

    public File getFile() {
        return file;
    }

    @Override
    public Date getDate() {
        try {
            BasicFileAttributes attr = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
            FileTime fileDate = attr.lastModifiedTime();
            return new Date(fileDate.toMillis());
        } catch (Exception ex) {
            return new Date();
        }
    }

    @Override
    public String toString() {
        return getId();
    }

    @Override
    public int hashCode() {
        return getId().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final FileDocumentNode other = (FileDocumentNode) obj;
        return Objects.equals(this.getId(), other.getId());
    }

    @Override
    public int compareTo(IDocumentNode o) {
        if (sortAttribute == null) {
            return getDate().compareTo(o.getDate());
        } else if (sortAttribute.equalsIgnoreCase("size")) {
            return Long.valueOf(getLength()).compareTo(o.getLength());
        } else if (sortAttribute.equalsIgnoreCase("path")) {
            return getGroupName().compareToIgnoreCase(o.getGroupName());
        } else if (sortAttribute.equalsIgnoreCase("filename")) {
            return getName().compareToIgnoreCase(o.getName());
        }
        return getDate().compareTo(o.getDate());
    }
}
