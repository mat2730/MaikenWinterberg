/*
 * Martin Alexander Thomsen den 8 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.documentiterator;

import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IDocumentIterator {

    public int iterateDocuments();

    public void setTouch(IDocumentTouch touch);

    public void setRegistriesByDomain(Map registriesByDomain);

    public void setConfigIndex(int configIndex);

    public void setDomainNameOfClient(String domainNameOfClient);

    public void setServiceName(String serviceName);

}
