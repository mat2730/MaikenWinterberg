/*
 * Martin Alexander Thomsen den 8 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.savedocument;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface ISaveDocument {

    public boolean init(String clientDomainName, String registrationId, String path, String name, int sizeOfFile) throws Exception;

    public void append(byte[] data) throws Exception;

    public void commit();
}
