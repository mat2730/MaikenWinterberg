1) install java

2) You can download the AlwaysUp application and use it to execute the bat commands bin/startFileSender.bat and bin/startFileReceiver.bat: 
    https://download.cnet.com/alwaysup/3000-2084_4-10439107.html

3) Open port 4445
