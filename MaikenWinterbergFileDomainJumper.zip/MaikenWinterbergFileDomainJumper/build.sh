javac -cp ./bin src/main/java/**.java -s ./target/classes
