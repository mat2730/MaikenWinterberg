echo installing service...
sudo systemctl stop MaikenWinterbergFileReceiver.service
sudo cp MaikenWinterbergFileReceiver.service /etc/systemd/system
sudo systemctl daemon-reload
sudo systemctl start MaikenWinterbergFileReceiver.service
sudo systemctl enable MaikenWinterbergFileReceiver.service
echo done installing service
#Ssleep 10s