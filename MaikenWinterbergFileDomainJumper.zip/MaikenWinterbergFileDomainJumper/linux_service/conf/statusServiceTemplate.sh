sudo systemctl status ${serviceName}.service
sleep 10s
