echo installing service...
sudo systemctl stop ${serviceName}.service
sudo cp ${serviceName}.service /etc/systemd/system
sudo systemctl daemon-reload
sudo systemctl start ${serviceName}.service
sudo systemctl enable ${serviceName}.service
echo done installing service
#Ssleep 10s
