This FileOrganizer will organize your documents into folders by date. it will try to find a date inside the file.

This program requires that Java is installed on your computer. 
Java can be download at: https://www.oracle.com/java/technologies/downloads/

Update the fileOrganizerConfig.properties with the folders that you want to orzanize and install the service - look in the windows_service/readme.txt and linux_service/readme.txt
