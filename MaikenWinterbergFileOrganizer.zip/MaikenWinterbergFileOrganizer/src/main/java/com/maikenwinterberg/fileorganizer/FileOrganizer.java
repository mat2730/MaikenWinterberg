/*
 * Martin Alexander Thomsen den 21 Juni 2024
 */
package com.maikenwinterberg.fileorganizer;

import com.drew.imaging.ImageMetadataReader;
import com.drew.metadata.Metadata;
import com.drew.metadata.exif.ExifSubIFDDirectory;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

/**
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileOrganizer {

    private static boolean DEBUG = false;
    private static boolean INFO = true;

    private static void copyFile(Map filesAllreadyHandled, String year, String month, String day, File destinationFolder, File sourceFile) throws Exception {
        if (filesAllreadyHandled.get(sourceFile) != null) {
            return;
        }
        filesAllreadyHandled.put(sourceFile, "");
        File newDestFolderName = new File(destinationFolder.getAbsolutePath() + "/" + year + "/" + month + "/" + day);
        newDestFolderName.mkdirs();
        File newFile = new File(newDestFolderName, sourceFile.getName());
        if (filesAllreadyHandled.get(newFile) != null) {
            return;
        }
        filesAllreadyHandled.put(newFile, "");
        if (sourceFile.getAbsolutePath().equals(newFile.getAbsolutePath())) {
            //dont copy. they are the same name.
            return;
        }
        newFile.setLastModified(sourceFile.lastModified());
        if (INFO) {
            System.out.println("\tcopy file to " + newFile.getAbsolutePath() + " from " + sourceFile.getParentFile().getAbsolutePath());
        }
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(newFile));
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(sourceFile));
        int available = bis.available();
        while (available > 0) {
            bos.write(bis.readAllBytes());
            available = bis.available();
        }
        bos.close();
        bis.close();
        //update createdAt
        BasicFileAttributeView sourceAttributes = Files.getFileAttributeView(Paths.get(sourceFile.getAbsolutePath()), BasicFileAttributeView.class);
        FileTime sourceCreationTime = sourceAttributes.readAttributes().creationTime();
        BasicFileAttributeView destAttributes = Files.getFileAttributeView(Paths.get(newFile.getAbsolutePath()), BasicFileAttributeView.class);
        destAttributes.setTimes(sourceCreationTime, sourceCreationTime, sourceCreationTime);
    }

    private static void moveFile(Map filesAllreadyHandled, String year, String month, String day, File destinationFolder, File sourceFile) throws Exception {
        if (filesAllreadyHandled.get(sourceFile) != null) {
            return;
        }
        filesAllreadyHandled.put(sourceFile, "");
        //opret destfolder if not exists
        File newDestFolderName = new File(destinationFolder.getAbsolutePath() + "/" + year + "/" + month + "/" + day);
        newDestFolderName.mkdirs();
        File newFile = new File(newDestFolderName, sourceFile.getName());
        if (filesAllreadyHandled.get(newFile) != null) {
            return;
        }
        if (INFO) {
            System.out.println("\nmove file to " + newFile.getAbsolutePath() + " from " + sourceFile.getParentFile().getAbsolutePath());
        }
        filesAllreadyHandled.put(newFile, "");
        if (!sourceFile.getAbsolutePath().equals(newFile.getAbsolutePath())) {
            sourceFile.renameTo(newFile);
        }
    }

    public static void traverseFiles(Map filesAllreadyHandled, File destFolder, File baseSourceFolder, File sourceFolder, char command, boolean withFolderTimeReset) {
        try {
            File[] sourceFiles = sourceFolder.listFiles();
            for (int i = 0; i < sourceFiles.length; i++) {
                File sourceFile = sourceFiles[i];
                if (!sourceFile.isDirectory()) {
                    doFile(filesAllreadyHandled, destFolder, sourceFile, command, withFolderTimeReset);
                } else {
                    traverseFiles(filesAllreadyHandled, destFolder, baseSourceFolder, sourceFile, command, withFolderTimeReset);
                }
            }
        } catch (Exception ex) {
            if (DEBUG) {
                ex.printStackTrace();
            }
        }
        if (command == 'M') {
            while (sourceFolder != null && baseSourceFolder.compareTo(sourceFolder) != 0) {
                if (sourceFolder == null || sourceFolder.listFiles() == null || baseSourceFolder == sourceFolder) {
                    break;
                }
                if (sourceFolder.listFiles().length == 0) {
                    sourceFolder.delete();
                    if (DEBUG) {
                        System.out.println("\tDeleting folder: " + sourceFolder.getAbsolutePath());
                    }
                } else if (DEBUG) {
                    //System.out.println("\tSize of folder: " + sourceFolder.getAbsolutePath() + " = " + sourceFolder.listFiles().length);
                }
                sourceFolder = sourceFolder.getParentFile();
            }
        }
    }

    private static void doFile(Map filesAllreadyHandled, File destFolder, File sourceFile, char command, boolean withFolderTimeReset) {
        try {
            if (sourceFile == null) {
                return;
            }
            Date date = null;
            if (withFolderTimeReset) {
                //get time from parentLocations
                try {
                    String day = sourceFile.getParentFile().getName();
                    String month = sourceFile.getParentFile().getParentFile().getName();
                    String year = sourceFile.getParentFile().getParentFile().getParentFile().getName();
                    SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
                    SimpleDateFormat df2 = new SimpleDateFormat("HH:mm:ss");
                    SimpleDateFormat df3 = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
                    String folderDateAsString = year + month + day;
                    df.parse(folderDateAsString); //test
                    BasicFileAttributeView attributes = Files.getFileAttributeView(Paths.get(sourceFile.getAbsolutePath()), BasicFileAttributeView.class);
                    Date creationDate = new Date(attributes.readAttributes().creationTime().toMillis());
                    String creationDateAsString = df.format(creationDate);
                    if (!folderDateAsString.equalsIgnoreCase(creationDateAsString)) {
                        //update date of file
                        String createTime_hhmmss = df2.format(creationDate);
                        Date newDate = df3.parse(folderDateAsString + " " + createTime_hhmmss);
                        FileTime FolderTime = FileTime.fromMillis(newDate.getTime());
                        attributes.setTimes(FolderTime, FolderTime, FolderTime);
                        try {
                            //update with drew
                            Metadata md = ImageMetadataReader.readMetadata(sourceFile);
                            ExifSubIFDDirectory directory = md.getFirstDirectoryOfType(ExifSubIFDDirectory.class);
                            if (directory != null) {
                                directory.setDate(ExifSubIFDDirectory.TAG_DATETIME_ORIGINAL, newDate);
                                date = newDate;
                            } else {
                                date = newDate;
                            }
                            if (DEBUG) {
                                System.out.println("\tGetting Time from filepath");
                            }
                        } catch (Exception exec) {
                            //ignore
                        }
                        if (DEBUG) {
                            System.out.println("Updating time of File: " + sourceFile.getAbsolutePath() + ", to " + newDate + " from " + creationDate);
                        }
                    }
                } catch (Exception ex) {
                    //ignore
                    date = null;
                }
            }

            if (date == null) {
                try {
                    Metadata md = ImageMetadataReader.readMetadata(sourceFile);
                    ExifSubIFDDirectory directory = md.getFirstDirectoryOfType(ExifSubIFDDirectory.class);
                    if (directory != null) {
                        date = directory.getDate(ExifSubIFDDirectory.TAG_DATETIME_ORIGINAL);
                        if (DEBUG && date != null) {
                            System.out.println("\tGetting Time from drew");
                        }
                    }
                } catch (Exception exe) {
                    //ignore
                }
            }
            if (date == null) {
                try {
                    BasicFileAttributeView attributes = Files.getFileAttributeView(Paths.get(sourceFile.getAbsolutePath()), BasicFileAttributeView.class);
                    date = new Date(attributes.readAttributes().creationTime().toMillis());
                    if (DEBUG) {
                        System.out.println("\tGetting Time from nio");
                    }
                } catch (Exception exec) {
                    //ignore
                }
            }
            if (date == null) {
                try {
                    date = new Date(sourceFile.lastModified());
                    if (DEBUG) {
                        System.out.println("\tGetting Time from lastModified");
                    }
                } catch (Exception ioe) {
                }
            }
            if (date == null) {
                System.out.println("\n An error with the Date in file: " + sourceFile.getAbsolutePath());
                return;
            }
            SimpleDateFormat dfYear = new SimpleDateFormat("yyyy");
            SimpleDateFormat dfMonth = new SimpleDateFormat("MM");
            SimpleDateFormat dfDay = new SimpleDateFormat("dd");
            if (command == 'M') {
                moveFile(filesAllreadyHandled, dfYear.format(date), dfMonth.format(date), dfDay.format(date), destFolder, sourceFile);
            } else if (command == 'C') {
                copyFile(filesAllreadyHandled, dfYear.format(date), dfMonth.format(date), dfDay.format(date), destFolder, sourceFile);
            } else {
                System.err.println("Unknown command: " + command + " of file: " + sourceFile.getAbsolutePath());
            }
        } catch (Exception ex) {
            if (DEBUG) {
                ex.printStackTrace();
            }
            if (sourceFile != null) {
                System.err.println("File not supported: " + sourceFile.getAbsolutePath());
            }
        }
    }

    public static void main(String[] args) {
        new FileOrganizerThread().start();
    }
}
