/*
 * Martin Alexander Thomsen den 30 Juni 2024
 */
package com.maikenwinterberg.fileorganizer;

import com.maikenwinterberg.config.Config;
import java.io.File;
import java.util.HashMap;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileOrganizerThread extends Thread {

    @Override
    public void run() {
        String sleep = Config.getValue(Config.Group.fileOrganizerConfig, Config.Property.fileOrganizer, "sleep");
        long sleepTime;
        try {
            sleepTime = Long.parseLong(sleep);
        } catch (Exception ex) {
            sleepTime = 60000L;
        }
        while (true) {
            int index = 1;
            while (true) {
                String sourceFolder = Config.getValue(Config.Group.fileOrganizerConfig, Config.Property.fileOrganizer, "fromDir", index);
                if (sourceFolder == null) {
                    break;
                }
                String destFolder = Config.getValue(Config.Group.fileOrganizerConfig, Config.Property.fileOrganizer, "toDir", index);
                String command = Config.getValue(Config.Group.fileOrganizerConfig, Config.Property.fileOrganizer, "action", index);
                File destFile = new File(destFolder);
                File sourceFile = new File(sourceFolder);
                if (sourceFile.compareTo(destFile) == 0) {
                    command = "M";
                }
                FileOrganizer.traverseFiles(new HashMap(), destFile, sourceFile, sourceFile, command.toUpperCase().charAt(0), false);
                index++;
            }
            try {
                Thread.sleep(sleepTime);
            } catch (Exception ex) {
            }
        }
    }
}
