/*
 * Martin Alexander Thomsen den 23 Juni 2024
 */
import com.maikenwinterberg.fileorganizer.FileOrganizer;

/*
 * Martin Alexander Thomsen den 23 Juni 2024
 */
/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileOrganize {

    public static void main(String arg[]) throws Exception {
        FileOrganizer.main(arg);
    }
}
