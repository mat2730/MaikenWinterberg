echo installing registry service
java --class-path classes Install MaikenWinterbergFileOrganizer ../bin copyFiles.sh
echo done installing registry service
#ls -a
#sleep 10s
