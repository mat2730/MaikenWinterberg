This program requires that Java 1.17+ is installed on you computer.

Installation on linux in 3 stepts:
1) Install Java onto your system if not allready installed
    sudo apt-get install openjdk-17-jdk2
2) Update the bin/config/FleOrganizerConfig/fileOrganizer.properties with the right path of the folders you wich to organize.
3) Execute the installFileOrganizerService.sh file
