This program requires that Java 1.17+ is installed on you computer.

Installation on linux in 3 stepts:
1) Install Java onto your system if not allready installed
    sudo apt-get install openjdk-17-jdk2) 
2) Modify the paths in the moveFiles.sh in the bin directory to match the dirs of your choosing
    change defaultImageSource path
    change defaultImageDestination path
3) Execute the installFileOrganizerService.sh: 4 files are being created to the folder

