1) This program require that:
    - Java version 1.17+ is installed on you system. Java can be download at: 
        https://www.oracle.com/java/technologies/downloads/

2) execute AlwaysUp.exe: 
    https://download.cnet.com/alwaysup/3000-2084_4-10439107.html

3) Open AlwaysUp and add bin/startFileOrganizer.bat
